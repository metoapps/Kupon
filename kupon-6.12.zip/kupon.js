// @ts-nocheck
"use client";
import React, { useState, useEffect, useMemo, useRef } from "react";

/* ============================================================
   KUPON — haftalık skor tahmini + sezonluk takım portföyü
   ============================================================ */
/*
KUPON 2.0 — GitHub Pages için tek HTML.
Mevcut kpn:* kayıtlarını kullanır; şema sıfırlamaz.
Bu sürümde: Merkez, haftalık özet, ikili rekabet, istatistik, PNG kart,
işlem geçmişi, arşiv indirme, tamamlanmış maç kontrolü, fikstür aktarımı.
Sonuç servisi: https://www.thesportsdb.com/docs_api_guide
Maç durumları: https://www.thesportsdb.com/docs_api_data
Tarayıcı açıkken 3 dakikada bir salt okunur kontrol; kurucu sonuçları onaylar.
Sunucu kurulumu olmadan PIN/RLS, gizli seçimler ve güvenilir sunucu saati
koruması tamamlanmış değildir. Publishable anahtar gizli anahtar değildir;
service_role veya özel API anahtarını bu HTML'ye kesinlikle eklemeyin.
Güvenli sürüm için: sunucuda oturum ve üyelik doğrulaması, kayıt sahibine
bağlı RLS, kurucuya özel işlem yetkileri, server-time deadline kontrolü,
gizli tahminler için kontrollü RPC ve değiştirilemez audit kaydı kurulmalıdır.
Bu kontroller mevcut veritabanı şeması ve izinleri incelenmeden uygulanmamalıdır.
*/
const SB_URL = "https://ovryjrniokyxiwesfsqw.supabase.co";
const SB_KEY = "sb_publishable_Az3DBJigt3wDr_2hFktmoQ_SHULfUxi";
const SB_BASLIK = { apikey: SB_KEY, Authorization: "Bearer " + SB_KEY, "Content-Type": "application/json" };
const MISAFIR = /(^|[?&#])misafir(=|&|$)/.test((typeof location !== "undefined" ? (location.search + location.hash) : ""));
function misafirLigOku() {
    try {
        const s = String(location.search || "").replace(/^\?/, "");
        const h = String(location.hash || "").replace(/^#\/?/, "").replace(/^\?/, "");
        const q = new URLSearchParams(s + (s && h ? "&" : "") + h);
        return String(q.get("lig") || q.get("grup") || "").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20);
    } catch (e) { return ""; }
}
const depo = {
    async get(k, s = true) {
        if (!s) {
            const v = localStorage.getItem(k);
            return v === null ? null : { key: k, value: v, shared: false };
        }
        const r = await fetch(SB_URL + "/rest/v1/kupon_veri?select=deger&anahtar=eq." + encodeURIComponent(k), { headers: SB_BASLIK });
        if (!r.ok)
            throw new Error("okuma hatasi " + r.status);
        const d = await r.json();
        return d.length ? { key: k, value: d[0].deger, shared: true } : null;
    },
    async set(k, v, s = true) {
        if (MISAFIR) throw new Error("Misafir görünümü salt okunur.");
        if (!s) {
            localStorage.setItem(k, v);
            return { key: k, value: v, shared: false };
        }
        const r = await fetch(SB_URL + "/rest/v1/kupon_veri", {
            method: "POST",
            headers: Object.assign({}, SB_BASLIK, { Prefer: "resolution=merge-duplicates,return=minimal" }),
            body: JSON.stringify({ anahtar: k, deger: v, guncelleme: new Date().toISOString() }),
        });
        if (!r.ok)
            throw new Error("yazma hatasi " + r.status);
        return { key: k, value: v, shared: true };
    },
    async kosulluSet(k, v, onceki) {
        if (MISAFIR) throw new Error("Misafir görünümü salt okunur.");
        const yeni = onceki === null || onceki === undefined;
        const ham = yeni ? null : (typeof onceki === "string" ? onceki : JSON.stringify(onceki));
        const filtre = yeni
            ? ""
            : "?anahtar=eq." + encodeURIComponent(k) + "&deger=eq." + encodeURIComponent(ham);
        const r = await fetch(SB_URL + "/rest/v1/kupon_veri" + filtre, {
            method: yeni ? "POST" : "PATCH",
            headers: { ...SB_BASLIK, Prefer: "return=representation" },
            body: JSON.stringify(yeni
                ? { anahtar: k, deger: v, guncelleme: new Date().toISOString() }
                : { deger: v, guncelleme: new Date().toISOString() }),
        });
        if (!r.ok) throw new Error(r.status === 409 ? "Kayıt başka bir cihazda değişti. Yenileyip tekrar dene." : "Kayıt tamamlanamadı (" + r.status + ").");
        const d = await r.json();
        if (d.length) return;
        if (yeni) throw new Error("Kayıt başka bir cihazda değişti. Yenileyip tekrar dene.");
        const simdi = await depo.get(k);
        if (!simdi || simdi.value !== ham) throw new Error("Kayıt başka bir cihazda değişti. Yenileyip tekrar dene.");
        const r2 = await fetch(SB_URL + "/rest/v1/kupon_veri?anahtar=eq." + encodeURIComponent(k), {
            method: "PATCH",
            headers: { ...SB_BASLIK, Prefer: "return=representation" },
            body: JSON.stringify({ deger: v, guncelleme: new Date().toISOString() }),
        });
        if (!r2.ok) throw new Error("Kayıt tamamlanamadı (" + r2.status + ").");
        const d2 = await r2.json();
        if (!d2.length) throw new Error("Kayıt başka bir cihazda değişti. Yenileyip tekrar dene.");
    },
    async list(p, s = true) {
        if (!s)
            return { keys: Object.keys(localStorage).filter(x => x.startsWith(p)), shared: false };
        const r = await fetch(SB_URL + "/rest/v1/kupon_veri?select=anahtar&anahtar=like." + encodeURIComponent(p + "*"), { headers: SB_BASLIK });
        if (!r.ok)
            throw new Error("liste hatasi " + r.status);
        const d = await r.json();
        return { keys: d.map(x => x.anahtar), shared: true };
    },
    async getMany(keys) {
        if (!keys || !keys.length)
            return [];
        const out = [];
        for (let i = 0; i < keys.length; i += 50) {
            const chunk = keys.slice(i, i + 50);
            const listed = chunk.map(k => '"' + String(k).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"').join(",");
            const r = await fetch(SB_URL + "/rest/v1/kupon_veri?select=anahtar,deger&anahtar=in.(" + listed + ")", { headers: SB_BASLIK });
            if (!r.ok)
                throw new Error("okuma hatasi " + r.status);
            const d = await r.json();
            for (const row of d)
                out.push({ key: row.anahtar, value: row.deger, shared: true });
        }
        return out;
    },
};
function okuJSON(v, yedek) {
    if (v == null || v === "")
        return yedek;
    try {
        return JSON.parse(v);
    }
    catch (e) {
        return yedek;
    }
}
/* Takım listesi — "gp" = 2025-26 sezonunda toplanan gerçek puan.
   Yeni çıkan üçlü için tahmin (geçen sezon çıkan üçlü 37/34/30 almıştı). */
const VARSAYILAN_TAKIMLAR = [
    { ad: "Galatasaray", kod: "GS", gp: 77 },
    { ad: "Fenerbahçe", kod: "FB", gp: 74 },
    { ad: "Trabzonspor", kod: "TS", gp: 69 },
    { ad: "Beşiktaş", kod: "BJK", gp: 60 },
    { ad: "Başakşehir", kod: "IBFK", gp: 57 },
    { ad: "Göztepe", kod: "GÖZ", gp: 55 },
    { ad: "Samsunspor", kod: "SAM", gp: 51 },
    { ad: "Ç. Rizespor", kod: "RİZ", gp: 41 },
    { ad: "Konyaspor", kod: "KON", gp: 40 },
    { ad: "Alanyaspor", kod: "ALA", gp: 37 },
    { ad: "Kocaelispor", kod: "KOC", gp: 37 },
    { ad: "Gaziantep FK", kod: "GFK", gp: 37 },
    { ad: "Kasımpaşa", kod: "KSM", gp: 35 },
    { ad: "Gençlerbirliği", kod: "GNÇ", gp: 34 },
    { ad: "Eyüpspor", kod: "EYP", gp: 33 },
    { ad: "Erzurumspor", kod: "ERZ", gp: 35, yeni: true },
    { ad: "Amedspor", kod: "AMD", gp: 34, yeni: true },
    { ad: "Çorum FK", kod: "ÇRM", gp: 33, yeni: true },
];
/* Beklenen puan: ligin ortalamasına doğru gerileme. Yeni çıkanlar zaten tahmin.
   Fiyat = beklenen puan - 26, yani bütçeyi tam harcayan her portföyün
   beklenen toplamı eşit. Fark, gerçek sezonun tahminden sapmasından doğar. */
const LIG_ORT = 46, GERILEME = 0.7, FIYAT_TABAN = 26;
const beklenenPuan = (t) => t.yeni ? t.gp : Math.round(LIG_ORT + GERILEME * (t.gp - LIG_ORT));
const fiyat = (t) => Math.max(1, Math.round(beklenenPuan(t) - FIYAT_TABAN));
/* 2026-27 Süper Lig resmi fikstürü — takım kodlarıyla, liste sıralamasından bağımsız */
const HAZIR_TARIH = ["14–17 Ağustos", "21–24 Ağustos", "28–31 Ağustos", "6 Eylül", "13 Eylül", "20 Eylül",
    "11 Ekim", "18 Ekim", "25 Ekim", "1 Kasım", "8 Kasım", "22 Kasım", "29 Kasım", "6 Aralık", "13 Aralık", "20 Aralık",
    "17 Ocak", "24 Ocak", "31 Ocak", "7 Şubat", "14 Şubat", "21 Şubat", "28 Şubat", "7 Mart", "14 Mart", "21 Mart",
    "4 Nisan", "11 Nisan", "18 Nisan", "25 Nisan", "2 Mayıs", "9 Mayıs", "16 Mayıs", "23 Mayıs"];
const HAZIR_MACLAR = [
    [["GS", "ÇRM"], ["KSM", "TS"], ["KON", "RİZ"], ["GFK", "ALA"], ["GNÇ", "FB"], ["IBFK", "KOC"], ["AMD", "ERZ"], ["BJK", "EYP"], ["SAM", "GÖZ"]],
    [["ERZ", "GS"], ["RİZ", "SAM"], ["ÇRM", "KSM"], ["FB", "KON"], ["TS", "IBFK"], ["EYP", "GFK"], ["ALA", "BJK"], ["GÖZ", "GNÇ"], ["KOC", "AMD"]],
    [["GNÇ", "ERZ"], ["KON", "KOC"], ["GFK", "RİZ"], ["GS", "GÖZ"], ["EYP", "ALA"], ["IBFK", "KSM"], ["SAM", "FB"], ["AMD", "TS"], ["BJK", "ÇRM"]],
    [["TS", "GNÇ"], ["KSM", "AMD"], ["IBFK", "GS"], ["RİZ", "ALA"], ["GÖZ", "GFK"], ["ÇRM", "EYP"], ["FB", "BJK"], ["KOC", "SAM"], ["ERZ", "KON"]],
    [["GFK", "FB"], ["EYP", "RİZ"], ["ALA", "GÖZ"], ["AMD", "IBFK"], ["GNÇ", "KSM"], ["KON", "TS"], ["GS", "KOC"], ["BJK", "ERZ"], ["SAM", "ÇRM"]],
    [["TS", "GS"], ["KSM", "KON"], ["IBFK", "GNÇ"], ["AMD", "BJK"], ["GÖZ", "RİZ"], ["ÇRM", "ALA"], ["FB", "EYP"], ["KOC", "GFK"], ["ERZ", "SAM"]],
    [["GFK", "ÇRM"], ["EYP", "GÖZ"], ["ALA", "ERZ"], ["RİZ", "FB"], ["GNÇ", "AMD"], ["KON", "IBFK"], ["GS", "KSM"], ["BJK", "KOC"], ["SAM", "TS"]],
    [["TS", "BJK"], ["KSM", "SAM"], ["IBFK", "GFK"], ["AMD", "KON"], ["GNÇ", "GS"], ["ÇRM", "RİZ"], ["FB", "ALA"], ["KOC", "GÖZ"], ["ERZ", "EYP"]],
    [["GFK", "ERZ"], ["EYP", "KSM"], ["ALA", "KOC"], ["RİZ", "TS"], ["GÖZ", "ÇRM"], ["KON", "GNÇ"], ["GS", "FB"], ["BJK", "IBFK"], ["SAM", "AMD"]],
    [["TS", "GFK"], ["KSM", "BJK"], ["IBFK", "SAM"], ["AMD", "EYP"], ["GNÇ", "ALA"], ["KON", "GS"], ["FB", "GÖZ"], ["KOC", "RİZ"], ["ERZ", "ÇRM"]],
    [["GFK", "KSM"], ["EYP", "KOC"], ["ALA", "TS"], ["RİZ", "ERZ"], ["GÖZ", "IBFK"], ["ÇRM", "FB"], ["GS", "AMD"], ["BJK", "GNÇ"], ["SAM", "KON"]],
    [["TS", "EYP"], ["KSM", "ALA"], ["IBFK", "ÇRM"], ["AMD", "RİZ"], ["GNÇ", "GFK"], ["KON", "BJK"], ["GS", "SAM"], ["KOC", "FB"], ["ERZ", "GÖZ"]],
    [["GFK", "AMD"], ["EYP", "IBFK"], ["ALA", "KON"], ["RİZ", "KSM"], ["GÖZ", "TS"], ["ÇRM", "KOC"], ["FB", "ERZ"], ["BJK", "GS"], ["SAM", "GNÇ"]],
    [["TS", "ÇRM"], ["KSM", "GÖZ"], ["IBFK", "FB"], ["AMD", "ALA"], ["GNÇ", "EYP"], ["KON", "GFK"], ["GS", "RİZ"], ["BJK", "SAM"], ["ERZ", "KOC"]],
    [["GFK", "BJK"], ["EYP", "GS"], ["ALA", "SAM"], ["RİZ", "IBFK"], ["GÖZ", "KON"], ["ÇRM", "AMD"], ["FB", "TS"], ["KOC", "GNÇ"], ["ERZ", "KSM"]],
    [["TS", "KOC"], ["KSM", "FB"], ["IBFK", "ERZ"], ["AMD", "GÖZ"], ["GNÇ", "ÇRM"], ["KON", "EYP"], ["GS", "ALA"], ["BJK", "RİZ"], ["SAM", "GFK"]],
    [["GFK", "GS"], ["EYP", "SAM"], ["ALA", "IBFK"], ["RİZ", "GNÇ"], ["GÖZ", "BJK"], ["ÇRM", "KON"], ["FB", "AMD"], ["KOC", "KSM"], ["ERZ", "TS"]],
    [["ALA", "GFK"], ["TS", "KSM"], ["KOC", "IBFK"], ["ERZ", "AMD"], ["FB", "GNÇ"], ["RİZ", "KON"], ["ÇRM", "GS"], ["EYP", "BJK"], ["GÖZ", "SAM"]],
    [["IBFK", "TS"], ["GFK", "EYP"], ["BJK", "ALA"], ["SAM", "RİZ"], ["GNÇ", "GÖZ"], ["KSM", "ÇRM"], ["KON", "FB"], ["AMD", "KOC"], ["GS", "ERZ"]],
    [["RİZ", "GFK"], ["ALA", "EYP"], ["KSM", "IBFK"], ["TS", "AMD"], ["ERZ", "GNÇ"], ["KOC", "KON"], ["GÖZ", "GS"], ["ÇRM", "BJK"], ["FB", "SAM"]],
    [["GNÇ", "TS"], ["AMD", "KSM"], ["GS", "IBFK"], ["ALA", "RİZ"], ["GFK", "GÖZ"], ["EYP", "ÇRM"], ["BJK", "FB"], ["SAM", "KOC"], ["KON", "ERZ"]],
    [["FB", "GFK"], ["RİZ", "EYP"], ["GÖZ", "ALA"], ["IBFK", "AMD"], ["KSM", "GNÇ"], ["TS", "KON"], ["KOC", "GS"], ["ERZ", "BJK"], ["ÇRM", "SAM"]],
    [["GS", "TS"], ["KON", "KSM"], ["GNÇ", "IBFK"], ["BJK", "AMD"], ["RİZ", "GÖZ"], ["ALA", "ÇRM"], ["EYP", "FB"], ["GFK", "KOC"], ["SAM", "ERZ"]],
    [["ÇRM", "GFK"], ["GÖZ", "EYP"], ["ERZ", "ALA"], ["FB", "RİZ"], ["AMD", "GNÇ"], ["IBFK", "KON"], ["KSM", "GS"], ["KOC", "BJK"], ["TS", "SAM"]],
    [["BJK", "TS"], ["SAM", "KSM"], ["GFK", "IBFK"], ["KON", "AMD"], ["GS", "GNÇ"], ["RİZ", "ÇRM"], ["ALA", "FB"], ["GÖZ", "KOC"], ["EYP", "ERZ"]],
    [["ERZ", "GFK"], ["KSM", "EYP"], ["KOC", "ALA"], ["TS", "RİZ"], ["ÇRM", "GÖZ"], ["GNÇ", "KON"], ["FB", "GS"], ["IBFK", "BJK"], ["AMD", "SAM"]],
    [["GFK", "TS"], ["BJK", "KSM"], ["SAM", "IBFK"], ["EYP", "AMD"], ["ALA", "GNÇ"], ["GS", "KON"], ["GÖZ", "FB"], ["RİZ", "KOC"], ["ÇRM", "ERZ"]],
    [["KSM", "GFK"], ["KOC", "EYP"], ["TS", "ALA"], ["ERZ", "RİZ"], ["IBFK", "GÖZ"], ["FB", "ÇRM"], ["AMD", "GS"], ["GNÇ", "BJK"], ["KON", "SAM"]],
    [["EYP", "TS"], ["ALA", "KSM"], ["ÇRM", "IBFK"], ["RİZ", "AMD"], ["GFK", "GNÇ"], ["BJK", "KON"], ["SAM", "GS"], ["FB", "KOC"], ["GÖZ", "ERZ"]],
    [["AMD", "GFK"], ["IBFK", "EYP"], ["KON", "ALA"], ["KSM", "RİZ"], ["TS", "GÖZ"], ["KOC", "ÇRM"], ["ERZ", "FB"], ["GS", "BJK"], ["GNÇ", "SAM"]],
    [["ÇRM", "TS"], ["GÖZ", "KSM"], ["FB", "IBFK"], ["ALA", "AMD"], ["EYP", "GNÇ"], ["GFK", "KON"], ["RİZ", "GS"], ["SAM", "BJK"], ["KOC", "ERZ"]],
    [["BJK", "GFK"], ["GS", "EYP"], ["SAM", "ALA"], ["IBFK", "RİZ"], ["KON", "GÖZ"], ["AMD", "ÇRM"], ["TS", "FB"], ["GNÇ", "KOC"], ["KSM", "ERZ"]],
    [["KOC", "TS"], ["FB", "KSM"], ["ERZ", "IBFK"], ["GÖZ", "AMD"], ["ÇRM", "GNÇ"], ["EYP", "KON"], ["ALA", "GS"], ["RİZ", "BJK"], ["GFK", "SAM"]],
    [["GS", "GFK"], ["SAM", "EYP"], ["IBFK", "ALA"], ["GNÇ", "RİZ"], ["BJK", "GÖZ"], ["KON", "ÇRM"], ["AMD", "FB"], ["KSM", "KOC"], ["TS", "ERZ"]],
];
const HAZIR_FIKSTUR = Object.fromEntries(HAZIR_MACLAR.map((maclar, i) => [i + 1, { tarih: HAZIR_TARIH[i], maclar }]));
const KREDI = 70, PORTFOY_ADET = 4;
const BUYUK4 = ["GS", "FB", "BJK", "TS"];
const TEK_SAHIP_CARPAN = 1.25;
const GIRIS_GORSEL = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABMNDhEODBMRDxEVFBMXHTAfHRoaHToqLCMwRT1JR0Q9Q0FMVm1dTFFoUkFDX4JgaHF1e3x7SlyGkIV3j214e3b/2wBDARQVFR0ZHTgfHzh2T0NPdnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnb/wAARCAJiAeADASIAAhEBAxEB/8QAGgAAAwEBAQEAAAAAAAAAAAAAAAECAwQFBv/EADcQAAICAQMDAgUCBQMEAwEAAAABAhEhAxIxBEFRYXEFEyKBkTKhFEKxwdEjUvAzYuHxFSRDNf/EABgBAQEBAQEAAAAAAAAAAAAAAAABAgME/8QAHBEBAQEAAwEBAQAAAAAAAAAAAAERAhIhMUFR/9oADAMBAAIRAxEAPwD44BoDTJUMAoAChj5ASWQSKQUBIFUFATQFABID5CgF2AdCAQUMAEFDABUAwAVANgAgGACAYqAAAGAAAAAqGACAYAIYAAgGIAAOwAAAAAAAAAABQDAAEAwAQAAB3AAAAAAAADuBQAhhCoYFeAFQ6yNIaQCodFJDoCKCi6CgIoGi6FQECZdCaAkVFNCAVBQwoBUOh0KgChUUwAkCqCgJoRVA1kCQKEAgoYAIAABLkChAIBhQCDuMKAQAAAKsDABAMAEAAAMAAAAAAAAAoAAABD7iAAAAAABAWADCBclUFFRQAkWojjGzaEL7AZKJWw6I6L8DelQHNtFtOn5bJcMgc7iJxOhwM5IgyaJaNWiGiiGhcFtEtAIKHQUAqCiuwUBNDoqh7QIoKNNotoGdBRe0GgM2hGjQqAhoVFNBQEg+RsQCAYAIBiAA7AHYAYh9wAQdx9xPkAAAAQDABAMAEA3yIAaAbEAAAAHcQw7gIb4QgCjuAABo8DQcjSCGkaRWSUjWKAqEco69DS3VSMdONs9PodO5olHRo/D5aiUlFuzPqOkcJU0fS6UFDTjGPgnX6eGqluXHcy1j5h9M1Hgxej6H1cul0pR2uCo5YfDIW3Jtq8F1MfNS0q7GEoH0HxHoFox3wvaePq6dWImOGSIcTolEzkjQwaE0aNE1gCaCiqCgFQ0hpFqIEqJW00jApQAx2htOj5Ynpgc7iS0dLgS4Ac9EtGzjkhoDKhNGlCaAzoCmhASIYcgIBiABDABAMQAAAAAAdgEA6ABAN4EAdwAAFQDABAMQAHcAAQDEAAABWqLRK4KQRcUawRlE3gBvpLJ6vQQctSMV3weXpPJ6XRavy5xl3TszSPqIR2xSu6Ik5/NrG1EafV6M4bt1Pwx6evDVk0seLI20nJQjdMWm90blhi1JxSptZKoDi+JakXp/LTt3n0PA14ZPa69J6jo8vWjksZrzNSJjJZOvVjk55RNMsGiWjWSIaAlIKyUlkEgBI0jESRrCNhVQhbOnT6dy4QtCFvg9/wCF9JGUd0kml2MmPGfStLKE+nd8H1Or0mnqQpRSfoQug0lGq+41cfLS6fLwYT0mux9RL4ZFt28dqPN6/oPkZ5i+40x4MoGTjk7taFHNOOCo52iaNWskNFGbQqLaJoCayItiaAgCmiQAKAdATQDEAAAAIYAuQF3DsAADBgDAQDYgAAAAEMQAAAACGHYBAA+yA1KRPcpBFxNoZowTNYugrpgzq0p1RwxdG+nID1dLWe2rOiGtVZPL050dGnqXRnB6PzbZr/EyUa3Ojzo6lFR1LIrfVnuOXWyaSnijOTLEceosnNqI7Zq7ObUiaRzNENG0kZsCGgSKocVkBxRvCPBnFG8MMDr6eKtWe/8ADW9rqtp4Gi6Z7nw7qIxjsk6vuYrUejKTSwrsb4uskfP000k7NHJJXaoKhVJXR53xOpxUEuMnpxqUbWUcHxBpulygPn+o0ji1NNo9TX72cWpHk0y4JRMnE6pxyYyRUYNEtUatENYCs2hGjRLQE0IqhAJokpioAEMAFQBwACAbEAAAAAhiAHyAdwAA8gHYBCGIAAAAGD5AAEN9vYBAbdykQNMItGkWZFp4A2i8GkJOzBMuMgrrhqYdG0NTJwxlk1jLIHctQtahxx1C95MHV8wW851ManyMGrd2YzplbsEy4CMZoyaNpGbRRFYBLwU0JcgXA2jyYI1i+AOrTlWTs0tTjJ58WbxnRnFelDW4ydEde1yeXHUxZrHW+nki67/ntJ0zn1NW3kzWrhmM52waWrnk5JqzdyvkznRYjk1FV0c8onXNXZhJUaHO0Q0bSWTNoDOiGa1khoCKBrA2hOwJBDoKCFQmsDACWAMQUAAAIAAAENAwF3AHyAALsNiABAAA+QAAAAABAAAajQgQFplJ4IQ0EWmWngxLTCtUy0zBMtSA3jItSyc6kUpUBupFb6ijnUit2AN1Mrd6nOp2Up4A0bIYnIm7CG3kdYwQnkrdYDRcWRYWBtGRrGVtHPGRcZU+QOlTwaR1DkUx78kV2RmKT5ycynktztYAJTpibxlmUpeoRneAKk8GU+C5SIbKMpLJnJcm0jOVAZVhkNGsuKIYGbRO00ZLAkTHeSWEAg7iACWOxBQMSAArn2EUmqZLYAIfIgDsDYdhMAAHyHYBAAAAAAAAAAAgEBohoQ0A0UQhhDGmIaAqxpkDTA0T4KTM7GmFaWNsz3D3AWpFqRimVeANNwt2SEwvIRo3lism8isDXdhDUjK6HeQrZSKUjBSKsI33BuMNzGpBW+7KKc8HPGY9wGrkEeLRlZUZ0gG5ckuRMpZsjcBblZEmKyWA2yXxYmxNgEmTL0CxMCWwBsVhAyWUyWAgQDSCgVjrJLABDEAAAdwAVD7gAg7ADAQAMBANCAAAAAAAC3yNAgABiGAMLGNIIRSEOgGPuKh9woAQ0A0yrITyXJ/W/cAQ7JGEOwsVgAwsVisKqx2RY7Aux3kgEwi1Ipsz4HYFbh7qM2wvAVW4TZINgVeBNkpjATE2O8EsBEtjEwDsSxiYQmAxABSWSR3hBVOqM2O7RLABDABC7ldhdgABAAMGAAIYAwEAxAAAAAAAwNeWN8GeR2wKSKaIToe4BpFUSmNvAAPILI7VAAwtBywE/QFyOhIgdA3kEFAF4HYgAdgICh2F4DkQDsYhEF3gSFYFRVhZNgnkKq8ivIrDsA7CyQbAqwvBNgA7yJsTAAsBWGAF3BgwAQCfIwEgDsCAXAhsFwAgAAEADYCEAwAQ0DAQAAAIAAAAAAAAgt5BCsd4KDgaVsVjsCqChbrQReQLS/cQXgSeQGVDLdk2CdAXLDFZNgnghqlI3jBSo5rLjqOPDBGuppqKwZqqCWq2iLIuqvI20RY+xoUmDoFVEdwKAcOclSaa5IiVyIVZHYQAWqoi8lUAJMGwAGy4rBE+cECbHeCR2UFhYmwYDsXcQ2ANCYXkLAcRPkVhYD7Ejsl5AYCBAMkAAAYAACYwq2Ah8sTQANiAQAAAQAAAAA0m+EWtGbfAti5agLCgoqBFdyaKALwCYhgOxksEBVhYgAqx1ggpMABMTBYf2AaeQ7CAB3Q7JsdgVdAie4AW2FtrJAyChWIGUUpNKrFZKAChWCEBabXDJsQMBtisBcgOwYmABwFgIB3kXYB9gEuAATAYg7gAAAAILDuHcBiGJckAF0wEUNuxABAMQ6b4TNIaE5rCFq4yGk3wjb5KjG+WPKWEkZ7L1rKOlJ84LWnGPOQbd2VzTZnWpxNUuMGkZq8siKXkKM1pgIfDGd3EkgGuS1ptqyKihItqsMnuEFBwNAAh9wWCqwBLBYKSF3oBDWRpCaoGG13JrBWR1gCGBWGFAwkDeR8MOWUCEUDATAKyDQMIBsQAHcB0Au4hvkVAAwqkNAJi7FE0Ahoa4DuAmHYHkKwAgXJSQqAXcGh1kOAJoBtAkBIFUDRAqEUotulllrp5vn6V6ktxctZAk26StndDoXs3ytwXLNJOEfl/JhHC8ZbM3nPxqcXD/D6ikouO1vszSOhGD/1LOvW0JuK1pttvD8pmMIarrfBzi8Iz21qcZGWF+hKhpT05Wnz2Fai2msjlG4qW5O8LOSBrVknmJDum1XsTlPNmig5QlJRVLDzkvwZpN5o0jTxHD9SN1XVoKtuskGjcUsq2+4oxTVttEKN4dnTHR26acp2nwllkquOSwKKY+xS4O7liaNlNKPGTJZZUlSJSJk7ZNDoZUJGiVoNuCU65JqirkDdFJpciSuxolNglkdZNFD8hcQ8cByVXkIpIahJCZTeSeWAkCHQJFCeQTKSuwrIEjRoo4JqiaJQXnI2KslAwawCQ6CIoYOx1gBcjQJDayFKhcFrgloBByFFJAS1SEacoisgIJDoGsBCQ2JOgToA4AVOw5QUDigoaA36XpNXq9VaehpynN5pHT1HwuXTf9VSk6yorC9Ger8B6jT+F9OtfWa26zadZlS7HR/F/D+qlu09bW6XUlfLuJx5cv46ceP8AXzlpN/Kio12RDTlzLPqfRz+Gy19NbY9N1cV30ntmed1Pw7ShPa56nTzX8utG1+UZnJrHmfMcWs7l4OjT1a0m0opvCX9w1Ph/UKDls+ZBL9Wn9RyuOXtTdLKZfKnsdOv0+rHSWvuuMny5dzJ6klpwj81UrwnwZpyUaalXi8EyadcMuGtN8Xp507z+rv7GUlDspX6jlOMYpLTqVLLfItynF20pJYVc/cuIuLrEl6V5G1G62vTfDJjozcVJxltfesClNxltT3pPhqrIraWnGH/TnulwhVFS/wBRbXxVGctid1KN+tlKKkk4tSfqRXRJx3xvssOJtpN7HHTqK/7nmyNDSmtNz05QjJrlyJ09TU1pS03qQbVv66p+zMfWvjz2gNflOjPUi4s9TznF0Ep2ZgyYuriVS5M06Ku8DDVqVCawhQVs7I6EXC8D4fXFyVwsD1IqMibKmndMvfgSjaJlhkw7NoQ3KyJ/S6HDU2xoiTcmMC5HGIkjVLgqIrI9t8DapmkGqqiVWKVMV5NNRZJ29whKTXcTZW0TiNCeUOMX4KUfQ6NNKsi1Yw2NLgg75qOw5JwyQZUUo2VsKSouoxaaDlmklbFtGiUhuOB0x1gaMmqY8lOLY1EaHow3yorX0VFWgjcHaHOTnVjV1z0xtF7QcWNRi4hRtsFtGjMKLcaE0kXRJpoaT1taGnHmTpEuksnX8Pi1DV6irWnGk/VmeV8a4zar4pr/AOtHRX6dFbEcW9q0pPwRrSbm775DcneMHPG9dej1c9GnCTVPlYs7tH49rym460oz06pLWW5L78njwW9pLBWs5JRh2SwidYuvodLX6LUdxhq9PPmWpoS3RX2/A30T6hOcJ6HVpK6vbPwr9WfOKTjHm+xa6vUVOT3P/u7ffknRez0tb4bCLe5a3Ty8akbX5Ryavw/WhDfGMdSP+7Td/t2OjpfjmvoQUJTepD/Zqrcv8nR/F6Gq/r0Nsr/6mhKku+UPYvleM47X9TuvCIkkr201xZ7zhpa8JS09TS125uo6iqfJydR0GjF01qaM1zGX1Jfcs5JY875u2/l7l6brBSct7lav/t7/ANjaXQ60VuhFakau4OzBwcHbtPwzXjPpL9VUilabuGP6BGLaa+n0wUpycFGTk4x8vj2A30+smoKMI6SePqayPW1ZSlLc98mv1JVf7GMY87ZxazyqNtn1J4k/WVmLkam1l85Lky1JbuCKDuehx0JYFWS1wCQRFZGilEe0CU9rN468ttGW2ylGkSrETdsFgpxyNRCBPBLWTRRCsk0SouhqBaRSoaJUR0Wh0iaM9llRgaUqGqomjJwDYbpINqGjDYPabbULaNGSgWoU8FDTJommHyy1Qxoz+UJ6Zt2FyNGPysj+Waik0uXQ0ZfLF8s1WpF8O/YievCLyX0T8sNoT1qhuVGUesW7KHo02BUVyzDV197+h0Z/MxTeS4uOmUoR5ZnLXgjmc1w3YnBNYZcMbvqU+BPWe2znUW37FTbapZLgp6snwQ5PyRmPI36MGLTv1PW19vS/DtHSgmtWX1Tzz4PP+H6Hz+r04v8ATdv0R0fENd63Uzk22lhP0OfL7jfH45tanJPyRHK5zZUksZJawvK/cotJxSlFXT5spVOS9fJMN0sQtu+KK0ptTTrKdp+CVTkqck2l3Ty7Mo137Guq25Nv+hD/AFXhiFQ7sVuPdYK4lfObyS3beF/QqNYa8k05PdXnwdfT/ENaLUPmNw5amty96PPfsNJ1hXXJLJVle2up6fVf+po1fOpoyvHPBfyo68U9PV0uotfo1FU7PCTp2nx3Lhqzc99tyrlmbwa7PR1ug04tKWnqaUuXf1Iw/gdSS+iUNSs/S8r7HR0vxPW0v9J6l0sLUVxv+3+SOs3qLlPTjCaX8jv9lwT2Hium+HanUtR09KW5Yra2n/g9PS+E9P0ST+IasYRq/lp7pN/2PC0PivU9N9OlrTjlrEiJ6utr/XKTUc5/qOt/V2MQEnkVnZ51rgZF4HYFoLIsaZBaKTM7HYFhZFgmBomF5JTH3IKspEDTAqx2SNAWmF5EoSfCdCTXdpDBopD3EQlpb6nNRXknV19LTm1F7l5GDZMDmfU7ZK44NdbXUtOMtDnuh1Gu30OrT+H9TOCnHT+l92zi0uonPR2yg9y4aNofGOq09P5cpPauKwXqq9Xpp6F/MpUZaWppSTbnVdjHU67V1nt1Fd+WXLT0otKKVvwOob1E1aWPJzz6l5oWrKSuFtoz0oJv6u3ZlyAfUzvkjUm5v9YtWK3Whw0NycrSZcGvTTcG1ttmPUy/1LvJrCOpGO61jg5dTc5tyWRBcNWX6XbRepsvGDDc7wKU2+QK7+Q2XxyRwPdjDKKenJK2Z2yt8q8ji4vlZAm2uGNSaynkuShf0i+U1TxTAUp3yioRi1nBEou8IIxk3SIr0+iitDpNbXvMvoj/AHONybTd8s7es/09DS6eLTUVbrycNNOuDnPfWxfarFdPyq7GijtdWvsGoo7Mc8BMLRUnu2rhXa7FO92MNIzgnB3uX2Y54nhp5wxTWiknpq26vKM15t2XP9Kx9Lz9zPmxFJtdmOndY9R4cb3LdyKCV8per4KicjjazXA2sPiNZVhBZStLy2BL49Coq8J+wqvnsCzX9QNXvW2suWfU7Jzer8N+lJOH6rfPj+v7HE7SjuzHs+69Dsi7+G6zdY/Jm/jUeTC3Nd22devJx/0k8QxX9TDQju14pK8oerPfqyk1y7N31ieQWFiCisHY06FQ0m+EwGFgotsuMLVuSQEoZp8tRl+q4+UdOlo9PPTSv/Ub7vFBXGjVaOo47lCdeaZ2qS6bX26fTxm69z0Oq+I9b1Glp6HyIQtfTsjbYwx5Oh8P6nWTenoyaSt3g26f4T1GtJr6YUr+ph/EdbDUen/ESg62tVRo4yhpuHVye58T3cDDHHr6K6fVlCc068Dn8iOjGcHKT7mfUaqlB6UalTxLyY7npJwmrvt4LiKfUqMltjfuOc9WcfmbahfKMZzhtpQzfI5a0paS01J7V2Cqn1GqsRlijJO7cmyVcc2W3HUf0pqQCk93C4FubSsmVp1mhpPbbyUaOe4005QS+q0vQwhnEsGnzFGKSimu4Gsuqajtg6XkiEk5fXN0ZSlvlUI/YcZqMktSOALTudybryaXDTne614FqT0270bSSwmYKW500rCLnrNyuOEL5zm02kOOk9XUUFjHcio6U6eWgKj8ttt2ipxi9uzUtvsyPmxqlFENZCujbqxdRqQamnOUN0oNUc61JRacW0arq9ZKtya9SDCacezROG88G719818yNr0Gl07muUijOMVONJqyGsUjeehBQcoasWvBmtJtXyvQDJ8VY1L8lbau4htajYCafuG9pc5GnLPcjvwBfzHtOz4ZpfxHVwSje36peyOGrWDt+H60+mjrOKVyhtz4M8viz6XVT3685LCb4JitzXpyyfmb1Tpdi1hulaOf43+tNu1N0n2szlFwbd22Wm5Ukk/cuKdZrau9E1cc701PMFmuCpackm5O4tYksopNx+pK7wmsG1xaUJJbnhp4oupjPTj8uFzVV35/Yy1YbJ3H9LOx6ctNS05Q3xvs8pEw0dBxanGW7hJJW/Z/3GtY43GnVrPcSi5cVzWTslpzgktTdSuMZPKT7HLqw2yadbk6dO7LLrNiaxbafp4Fu8v7my05O2lF3H2Ijoy3xSSbfFefBUEotOpdnz6kvi/ANWscD5w0/cCoJz+mOfQ6k6+Ha6lGrrPkw0NFzjKWnKpx9a+5rKV/D9VtZcsy8krUcfSr/wCxHNd7Ib/Jt0v6pvmoOm/YwNMNnGEUnbdlx2Re75e+Nd2YP7tG2mm1Wm69GbZTpud/TG2OO/Sncq9im9R/RFrHeyI6epPmKfqwKlW61n0RS09N6abntfdUZym0qckkn2E9raala8AaRainWqq8UXGMU3P9T8IzUIbsp+zHqT0lFfKjKMly7wyGt4dTrKScG4+VR3aWpHT03rQ61x1oO1Fo87Q0eq1pf6UJSrwQ9Oa1cwdp1RR3y63Vb3y0lOep/PLucnU/XqpOe3zWTXX0moRjqaT09SsZ7GEVa+lqLjnIQkoaLdytXigberqNr6nXJctZLdKext/y0ZNy2WoqK9ApS0JOScc+gtkVF26mmXp6soNuF8Vllw1tPa1qaKk/KZBlGEvlSk4qXZGanJPCplz1NOcvoUo+llVGMHutN5QHO23mQ01tz+wVKVPkThJP6otFFtp6fH3Jin9hP6a9SnNqCio15YFxe174umu6JbUm7d+4rSapJ47B8uluYQ9TYtr0r4zZU3e29vHY36bpJdXJrp9OW6Kt28Ex6LWn1MdGcJRk5VwTVxjrTUnHY3hEU5Z8Hs6/wHUhCtHUjJ901R19P8G0Y9Io68U9WV3JPgnaL1r5tRb7CcX3/c+s6L4Xo9I5STc3JV9SWCet+HaGu/mayaUFzHGCd16vlbdVVoWLNNWMY6kvlyuF4bIdTqmbZKSzjgW3lWFPKV2JNp45AqSlFJcCTcXh59AlbdsEqzwB0Q19qS1c/YWpPTk/9OFe5jF085LapJ82QTurlNI1046MnmdL1RMNRr6aT9yJSi1TW2vAVvPR+lyhOLV8EbZRlhP3Rk3GlRroQlqQm421HkhqdScU0l9Xl8ZHp6lfplz2ZlNK/BFNDNNdfzJKf1J5NtBveocqXL5wcEZtNd68mkNanhuJm8WpXXJpTalNUnSr+pv0ujCWrevcW1uWcV6nFGSe269ykluVaiaad0Ysal9en1fRKTctFu5LhPGDn6OWzXXzVGWnXDd8+xGlNalxlqTcUnUZPB19NHS1nqOaaWNrXb7Gfkb+1WtDZF3jNNSTaaviv+M59bTuW7X09sG8VmX3Z6cNfSalpOt0Ull8+om4T2pJOL7J/gzOWLY8r5DSpKM48Km01fjtZjqac5NSUW4rGU8V2Z6+ppR0tSbaUrf6krVGerpW5Yct2Grpr1Rqc06vL+Wmt8dSMV2TMtkk8xpr+WX/AD0PQ1envTkoRe5q91YVecHLqS1J381uVRbyrNysWMVujPfBpVydGo5L4fKM6tyTXn7nNDlqux09S1/BJYTlNOvRItSMNBP5Wq0n9MbvxbRzvn3OnSX/ANbWkml+lVX/ADwc3L9jSVvH6GtrjbznIat1mavukYul3t+wJW8ujbC4N3cV9TK1dV6jvUVNKsGVO/72VFSeFkBOGLTTBPOWk/Qf1Sq19inoyi8qkuQIvLd2/BpGe5JbdqXNclQUNOnOpXlJP+pG7fNuX2VBHS9eUNVx6Z6kYyqtzz96N1LqopLUUVtynJpHNoz046c4/JubjicpVt9j1PhWv0HSTlqa/VTc9uNuiprPbPcK8yfUa6k39Lcl3zXsVBRnp3KT+a+IpD19StZKE9JJ8SS/qRLUnrSi5NSUVVRSWF7BKiUpx+mW2Sfp3M5fRqVJOq4eCptU1Dbzapf3FNy/VPv4CicIttRknfD4M1FxdtOvJppaWrrycdKE9SX/AGrgWtpaunq7NRSjJY2saYi2sxlXgcNXUg2rz65PVn8A1Y6SlCalqf7Wq/c2+H/Bnc59bBdlGKl+eDOxcrw3JuuLNVDWjC5uUYy7yWGe8/gPTPW3Kc4pO9q/yelqaMNVVqRUo/7WrROyzi+X6X4drdXoS1YfL2ptK+7NOg+Faut1Khr6Opp6avfLj9z6aGnDTioQjGMVxGKKpKNUyXlVnF4ur8BhKS+TqfLS7SVnorotFdLHQcFKKirbXPqdKX2G+FRnauRzdN0eh0u5aOmlu5bN4xXp7lVfL98hXgKVW23wOuMcDrIcq+SKVY8EtJ3fHqW19kJr9gjxPi/SaOn06el01zk/1RXB4O35banF34eD7mu+Twvifw3rOq6qU4/LemsRzTSN8b/WeUeBJyTrh+gp9n37mkk4T2tW1jngTSaSlJJfk6MIhUvpB1e13g1WnvlWlJOkRLT2uprj1AmNVd8dh3eF75FLYl9KdiUXl+AKlOlW1J+SKvgrdjPYlc2AJ14O/wCFaUdfV1NGctjlB7XfdHElBt3a9TbotT5PURk/qRnl8WfUakUrtYurM/ly27lweh8S0Fo6rUUlGVSirvDONRdVwiS+LjLaTRrLTqWMk7Hb4wa1EpuLwylqu74flE0IYa6Ial3xKzq6fq3B3GTUvD/yebkpTa5yZvFqcsevpzjKTlJKOpJO5J1/6OiOq9JzktZO+FPs/CZ4kNVrh16M3WsniS2uqtHO8W5yeiupnGMnOOoo473n3+x06MtScnPYmmrpPNHmaOrqR2yU5SSd1Fs6dPqL0pRhGDT5TbbS8mbxaldWrp/MbStJRxtff0/8nPrwz83ScZNxdxccv+94/YqPWNab3JuV1cfb1OjR6hyUcW6csNP7E9i/Xlx0XKDioOMubebRPWKum0240226v7HqynDTWpLbbayk7TWLZ5fXy36em07ty555NcbtZsxilXw6Uq51Er78HKdk1Xwy1dPV4+xypYp4OkYoaal9Sd+pfy3eKon5klL/AHP1yLfLddtHRzW9qf6XjyPc9uJRTXhGTbtt5TB8YeP6gW9Vuk1hPsLDbpyp+SVVPH5O2XwzrNPT3fKdd4p2/wAIDmUVhJqRLbUmljtg7vh3w3+LnN6kZ6cIrlLl+M/c7dT4C7T0NWl4n2+6JsXHi7c5uuE2bacJa01p6eW8Ko5Z9N03RQ0OmjovbPH1ScV9TFofDOm0Nda2nptTXFybSM3kvV4Ov0Wv0udTRkoSXNKX58GvQfDJ9bpT1ZS+Wt1Ko847H0qjt4tDS/8AFk71esfOy+A9RHU26c4ODf6m6r7HrT+GdLPS+X8qKS/mSp+52WvcOe3BNqyRy9H8P0eijP5W651bk+y7HQ9OO5NpX2dFV5Y8Vjgil245B44Xfljq8A6Tzj3ASTBLHOWFp5WfUa9WAYpf1Duv6B5aQwD7fYGrrngWKuxrnh+3ABV1WAdq+/sF12C1xx7kCq28X7sEvOPYr1F3f9wDu8WGe/Am159cArfZhQ8ojU01KEoNYkmnk0++BPlvuB838S+FaPSaDmtadt/TGSu/Q8Zxdp0j7jV0Ya+nt1YRnHxJWfN/Genjo66ho6DhGrtJ1I6ceX452OBTiobaqT7kTipNuOfbOSWm3WR7JRadV9zTJJSUlePQbct75a9i1JQalJb3fdYZU9Rpt2lGX8scFGW9TeY58ov5FRtzj92Ray4Ra98kNuTd8gVsVfqXOPUcVU1t5Xl02TFWmu400uVklV6mvGMun09Srk1VeGedN08nboanzumloytuK3Q+rC84ObWi8btqXoYnlavrOMsOla9i4bbzntRKSUlsk37FycUltgs+pajKcHuaisGb02jpjtjLMmk+6G9dSW1xTrjtQ0xyNUwSs1k0sNN/2IcGo2ro1qYgak13Htw3aJ9gNIarUrTcfY6FqbopSrH80eTjpgm1wyXiuu9aijWycmv9rdJGsNaUZW5RhLusU/dHnLVd/VkuOrJJJO1zTM3i1OT1lrLVjLbLDSjLau3/ADBy9e18zTguIwVWZ6GtGO5RlLTlJVzgrq1v1VJPdUUvpWODMmVq3Y11oL/4vRaw3qO1foqZw1Sy8tnfP/8AndOlF23J+lcHFJ6a5dvwv8l4pUP/ALTfo+nXU6r03NwtNp1ZjKK7XXnsVo6i0teM6dQaeHX7nWuT1tT4JCcV8rVcWlnfG7/HB3dB0EOk0dn0zndubj+3sa9D1C6rp46iTV8q7OpRxx+TltdJI4//AIzpZaqm9CG771fsdigrv7lpJBj/AIyCaxmx7cj+ySJmp/Ttk/XAVaQJ269CHGcrTkkn2XgPlq8uTwBTlFPa/ahxkpr6Xh+AemqUaqK/cpelhBXnkXKy+CvT9hf84Ck+e43d/wCA4DACtvtXuxhkK/YBJZwFxjl0DeavtZKcVw79sIBttPCbTyCbbxS/cEnfGSs+n9QJdrhflhT7tL2BvzJjVLKX7AKljLlkpCdvHFCunl35QFX4oVX5+4ne3GPcP0rLRBX4QnjtQrT4bfsgV9lS9WFVyHt3M3j9Uq9sDWMxi/dgNrvfYmcW00nTrA3b7pBT7v8ALA+X6r4f10Jz1Xp5zJyg1+Th0pTTe1wk/D5Pr+s6f+J6eWl8xwb7rsfN9f8AD5dFCLlqQlbqlhnTjy1zsxxxbUvrh/YiWUs58NDcmn9LlS8gpJSxWedyNMlsdX24DbUcr/Jv83Tknv0UlV7ouv6iX8PPn5kX24YGLcFVRb8h+qWMX6WXPSgv/wBYy74TyEdFuN6bUmuy5KHpTUFibTvxwbdRGWrprU3R2rFLD/Bj8uUWk1sfazrXT7YXKSk5LKbuXJitRw3WG2/UajPd9PbmjScLX0La/Uz+XJZkkk+/kCZt8W6EsdrZW5JcW/PBcVFpySz4sCVUpfVaZemnTt2Yu91rBop5dq7+wFOCp7lT7GXy3l8pePBtKe/LtYBr+ZJJSXkSljmz2uh/Ttqs+5u9NJ2q/BnqafdJp9y6YxDKKa8r7hVcMqEpsv5tNOLaozrNc+wDF1o9aezZve1cIzAKsI3TlHCYt3YVulivUpRlJd36lR7XwPUhGDlqa1SvaotpL/2e6naVZPiNNXNQk9qbq32Preg+XDp46WnrfN2921Zz5TPW5XXfOQ44QemK9gTdWzLR9mqsHXft6ivPkpen7ALda4uxpurwv3DPZoT295fe/wDAA13cqx7AqT7tr7hhXUX+B232S+4Bbd1F/djVtfq/AnF1l1+wns45fjkAwruX7jaXiTBOniLX7B9Tz9K/cAtvhflg8LMq/YNvmT/NBtSzGIE0pZjlrhlJ2k0ufI8t5r+omtsuMSfnuAP1dE1FW0r+xWE8L14C2+1e4DV1jAe8khNcbpf2FSVNK2AJR4Scv3C3WFFe47fdpBuXuAs1mT+2AUY5dZ8sFUv5bGrrsQDWPBLVct164Kq+W/tgX0p9gpKl+mLf2/uONtZVBfo/8Atz717IAr14H+RNJ8/V75DhVgik0+3Jx9b8N0etlGWpuU443RfY7Hni78rsYdT1cOm2rVlF3hJNJ/hiI+Y+IaGj0+vKGjqufKleKZybUotvnwfSa8fh3UqetPTUpJZw08f3PntZxnN/KjUW/p3PNHXjXOxle5/qr3E2kynFq8fcmrXn+xtlUW7Xp5L+bLbalGNPhYM7SjnN+Owkr4Apas2/L7G2nq6idNNeiZjt2pNc+xeldxzXreTNajZ62ySUoxlWL8mk9fTnGKrbFrujldt/LWUZptPHIG1Rbe17l2Tqyd9WnHbfLoyTafgpyt5yEaOUofzKS/3JihKFrD9iUpNblleopRinVgdO7SSS21ffOCHBNU5xaXqZJzS2q/NJDcXtW67IrZTWmqjbl+SJuTbk2tz5RCtK0+fQak7bxfGBim5KVRaWPCp/cFpJtRbcXmxRd+6wCTWVd2BnGDTuOaJdPtk6tLT3OVRfF8ZMJe1O+CypiNrWGmhV4dlOW52279Q7WrzyVGjXCbVP8IVriOPdjpq7jz5Qlhqo55wVEyt5wz1fgUNJar6jU1lBwdKLdXa7nnOs3DKXHBmrbSb2pvklWePuYtNJqmivvRx/D46ej08NGGr8xx73/Y60cmz+48+aXsJfkbinV0/sFK493fpdjTpfTFr9gTilykhPUj/LcvZAOpPwv3Ht4+qT/YpZ7sS/sAtsfCb9clV+F4BAAJfv6CbSfawaT5b9rBY/TH+wBfhMVyvhIM96/qFWstsAb/3Sr9g+mUaSdV4GlGL7JhuXZNgJW003lCbj/ub/AOegO19SWVyvI28YpqubAFjiIZfP7Cb5+pIKV8W/XIAtrfn9wk8vCT7WNX6ENyT4SXqBV47uvsDb70iZJz8/YNlvNffIFVfLbDdGLfCfoG1Vlt+7HSS8EC3eIv74F9Xdr7Idrsm2Fv0S/IUV7ysFjI+wlzyAd+xwdfpNTXUQjGb7pq/+eDvZnLKaf3J8M1loy6H41pq5PputhhS4a9H5R5vW9Jr9M3pdXoJX/wDrppbZetf4orrOjUpqUHs1P5ZI5+o+M6upCPRdbKUtOKam06fpn0NT1LMePq6aiqjOMldWjOmuVg7Oq6KWjH5mlL5mk+JL+5yX2/Y6uZVT8ovF2rjb90C+rvFVngbnGknBY5aw2BK05Ps3fdMqEVB/XxbVJ5E5pu90s+SLpNUmgN5ajlFJyfiq7CWnuu+O1GKlT4X3NYqMsylS8sgmUHFenklRz5LnqJxUY/pTu+7Epbo01mwpZi+6vwNStpc57lrTb/WqXlkNJOUdt+tgN4e5NqyZTt8MbXZPjtQlJ9ngBqTS/sJPhqgpt3f3KUoptKLfqAstpZHJzwpSt+4Sf2fgjvloDa5LSdvLwsmUqbStppF6kovTrc8cLlGDebEKdd3+4X60VU3FUm17D2JLL57BDT2PNqufQSl9X0uq7lLm5ZxyE3Fv6Vtx+5pCTiou3brgiWa7G21zW5tNKlyROr+nC9QPS+B6cZdV8/U11Bab/Tf6rR9MqaW3N+D4dbm9qdKTPrPh2i+l6WGj8z5klltcZ8GOUbldq9RtJqmsdxJ+EGDDQUIriK/BdJYIX/LKckll0A+AI3p8Jv2Q90nwq92BYdiMvmT+yBxTeVb8vIDco3hr7Bu8Rf3wCqsfsDvtQB9TXZA1jLf5oKvlt+2BKMV2X3AE4r9K/CHbvCx6sd1yTvVYz7KwGrb5/Alh12fAbm3hc+WCWM19kAKv5U/ehbvb+pUtqpyoV4+lAOsZYJJdqJ3Zq8+mQy1VZfnIFbl5bfoJyxhVnuCXl/jAPbHmgEpO2s/bAJN9l78g7dOKtru8X6AnuSzzxggbSay7+4KS/l/YT2rmvuG5Pi2A027xQ+Pcm212X7h2yFNtLyRJJpv+o3i6pGcnXt2Aw1UpWmfOfEOnlp68/mJ/U3KMvKPpNRbrOLrNPfpuM1ceSzxm+vD6brNTpZVzB8xfDOjV6bS6uHzOj/V303z9jn1tLY3F5RjGU9GalBnVhLTg6aeBqnxVnctTS66NalQ1v93k49bQnoyqSAX03zkTw6dP18gnu5/8j4VUn4YCajzwvA97eKT8Ilq39WEOLrtj3AUk1m0/RDi3vVYaJbXax7bAuWpf0y8+BxlCeJYflELTdWxbs8AbfKwnF7n4jmiKpJ/S/JMJyUvowzecLTk7Uu68EGDXGcDUcYYpRphmLxWO4U3fdux4aePUIycpPFuuRprCbbfgCZJtLHJLpdslyTm/pSsiMfq5XoWIpuUYpNuueSeXcfwJ2u+Ck7VNV7AafTqNZp8NUxSknSTbXq+BNNxwhrSkprc1BeZFRWsuFFLHLUeSIpPEuy7Fauq5YjJuKwrd4M6fPf2Ae7mKVJWeh8Hh1Gv1q1IalRg05tvt4ruefTea9yoaktP/AKc2m+aJVj7aLvsN9s5OH4VHqNPpK6p3O7Sbtpep2p34o5Njnu39xpJPCJc4qWWvuL5iknWGFae43JLlpe5mk3+pt/sNJJ4VAVvXq/sG6T4SXuyfq70v3Csu22BdpL6mvvgW/wAJv7CSS4SQ78ZYBcn2S9w2vvJvzQOSXcW9drAe1Xxn1H35dURl9qCvLAvcr5z4QlJvhNe5OEucBuV0uPYBxbknbrtjsD28v9xN7XfnDBxX38gPcuFbS8CTxwkNO2ADXltiT8fsgtLl/kTlfCb9wKT9KJeJXeHzXZhn0DnDdoB/Sn2sLvhfklOsd/6jf2RA1x6hfoyXOOWnfmuxEtS1UeX4yUaMzlKN02vUacn/AC17sWyK4S9O4GTknaq2nWFZlqx3HVV+PQzmuwHi9X0+5PB5s47XTR9Jq6W5M83qelu2kalZseO4tO4nVpdUpwWnrq12ZnqQcXkylG88P+puVlrr9NtW+H1Q8mKl5+5ppa8tJ0+PDNJ6UNVbtLD8FGKavi/QJxTpx79lkh3F0yk0yBJVm6RSadtJ0hNvK4x3B1t5t+CinJPCjVepm026/Y0Tiotyab7KiLe61jBINNPbHltvxQnak2pvznuRbfcO+coDXlbnGk8Epx5uvcrRlucoLCq7vgcoxTdKTASpZzXamS1JulbS7DSuL25pZTRKaWJJp+URVbtmYzq+yM21zx7IcnJvtLtYRnSzFNfgqDdm7f8AWx3dtJehOMv9h0nVNfdEG6qlSc+74wjNySlcLj9yYr/da9h3clXL8q6NII01Sg5M0ioxhuUm75jX7C1o6sFUpXG8U8GW6nTWAK1Z7224qN9l2Iail3bKlFOnG/Up6eytzWVdWQd3Qdd1s+o09PSbmsJxfFH02LfJ8f03VavSTnLRdblVcnv/AAnrdTq9GctWKW10pJYZnlG5XfJPn9T8PgLm+Gkh3ldg7ZMNDftvc/XgPmWsKTx3wGF5HXt6sBqSa8BufhguQvABb8r7A/WRLtvlfgNt8tgViK8huV4V+yFSXC/I284QAnL0VE1/un3Gk8WwqK8AEYx7K++clkblWE37IbaAb4aq0JSdNYtdxX9vcOcpAPnlv7Dbolq+7D6YrFAOLzxkd1SJu3/cLx49wKT58ifv+Sb937Dd+EgBrdxdp4Y1JSVr8EU7rn3G3td9nz/kA2xxi/Flc+onfn9hOuLt+GwG2lixNt8KhX4X9gd8X+AB85f4JaS4WRtL8+R1XsBk4XZhq6adnVbvwZzj+QjyOp6ZO6WTzdTTcWfRammnyef1PT3br9jUqWPIkk+SYylpu0zp1tJxbpGLXZmpWWqlDqFUsS8mGppy03klpxdx4Noa6ktuplFGSkuGUkk03nw0Vq6O1boZiGjpampucVcV+pvCFGTznkausfg6F0m+ClpzUn3jG3tzSswlHa6la9KGmE1hOmvQKznAnx3BPz3KN4Se2otbXzZm90JbXb9LJXisFtPUbfNc4IE1/MuH2Ibd5uzSKe6SpcZsNba5JpbX3QCVY8ilHHpzY1uqkiPsA0sjdexSunmr9aJzVJgNy2/jkne8ehdbappsGsU1kqFCLm1S5EpOD+n/ACXGThaiueWu5EV9X9wHudcK33HSq1lkN5zyaJqHhvgCXJyk8Hq9P8Zehp6enLSi1GKTaweY53/Kl7GvS6kNLqoy1NNSgvOe2CWLH1cZKUFJJ01a7FXRw9F8Q0urnthuU0rpnbux3+5ybUnx2Yd2qJ7Me7GEgGKUsVwD7IXPj+oUKV+R570hLz/UqL9/8gFd8v3BOorHInXb8sWGwKtd/IL9xYQXSeAG+aBu/T+pL4dL3DvjigH2zm8j+yJtL17saxxYDSa7+os2nf7A/dUDd8XkA75dsMPGMdgvPIYsBvPfkG0hN+aYd+f2AE3XYLvuJptr+4Y91fYBJ5281wV54E1aruu/gIytf8wA7wHev+Ilu+MeQfN2A21V4FuTzkTivuKVt4VeoFNrNEyzz2FtbWXgdYAiUfJjqae7nv2Oh+hEl4CPN19BO8Hn62hTwe5OGODm1dFNPBqVMeG40yZR7rk7tbQ9DknBo1KyrpHu1VGe7Z/NXNenqfQa+j03X6MpdNGOh0nTQzulSlLul7d3yzxNPTf8OpQ/XOe1UVpaj0tZOrjpPCksWvKM32tTxWpDU0ZKedKluXZ12foY6up0+pH6VPf3Xb7d/Bv1fWv4j/1WlNcdrfl+pwamnLTlTRZP6WlWfpyhVT59mhp3zh+Ru6rBplPHkatKyoxu7a+7L/04wf6s/uBM7eY4SXngVuSSWGgjJp7Y0k33Jbzd/hAU5NqndL7k07xmu42msxtC+6sBy+rivsLCw8DVLswcGstWgK3KUqzfCG05R9uUhuoUrSfehabqSbeL7lQn9PFhvuOYphN5pZZGe/BQ4x33tHtrmgV3in2BwazTAbXe06E7Sp5sXC4vHca2uK8rx3IPW+EPpdGHzZTrVbcc9vY9tSTinHKfFdz46EN84wi6t1l9z6rpNP8Ah+mhpbnJxWWY5RuVu+cv7IEF85C7zwl2MKpP7BfHkle//gFjuBTf7dguvIs2sIG74sA3UFt1kSeMjde7AG8Yb9x2l6i5q7C/PkB364Dm1n3EnXAcYz9wHhdwfkV4wFu8oClb7iV/5EuF/VBup5YBaQ79Mix5C6f2AbfkPQX7eoOuXyAnJfd+Rpr0FbXYE/OQpvnJG5Kba+5XCE0rdyfsggU7u8e479eTK3K9t/buUrjh172Bd/kL+xMXix2+1APsL2DvjsLP/sBpEvgff+iB+EFZtZM5RT5N2r4IcVWKCOHV0rvBxa2h3o9eUEzn1dPwWVHl6cnpT00/0xlfsRqqK6XT/wB8m7Z2a2h3OHVhJJLsma+n45mnF8nRDXjqR2av2ZkyHGso1rLXV0XHKzHyZp1h5RenrOOJZiVPTUlu0+PAEbntrmPmiXm64Eri/BVXmPPgfBK5qrQ6TrKxyPnhZFXhlQN0/p4FeOB1tXKaKWXW0BRys2l2fYpfSuV7eRukqtP7Eu5pSeHwRXT8/RlGtrjS/VFKznnn9KtdmEo7VTpM00FGO5ZlqNfSu33LiMaavz4NJpOKusd6yaOpp7Y/X75MZLKdZfYBXFcP8oITluTeRSVNr+w/luMbp5Aqe3c2pfgjblU8+KNtPRSi5ajquy5B6sYpfKSVemb9wIcVCOacvTsdnw7W6rV6tbJSau5eEjilnLdPlvya9N1Wp0rnPT4ap2SxX1PZ+PcG3XBwfDetfVwk5KpRefU7k/8A2c8bUr8CsP8Alhz7EAuMsd2yeR3XgB3XA7z7ErC8Dv1YDxeRXQr84D9wKffyHIuRfj7AVfoFq/3Fut8i7YApO0hLjtYryssLv7AU/wBwuuHkV+Mha57gGOKsd+aJvDrnyK784CqusdwsS8UH2CG64YcPsiX6jvn+4U16fhEvPo12G3fBMn3rPj0AI9v7lXl8YJV4zgfbgBv9g7XRKfDQ7tc2A26vj0EuFX3EmFgN5rwJ8LIchwvAEy8YM5xvg1b/AOMl9wjlnDnucutop45PRkrMZwxk1pY8TW0XF2jE9bW0U03RzafS6ep1OnDVn8uEnmaV0XWccMo3wENSUHj8HZ8R6CfQzSlNSUuH5XlHG0n3LLqWY0+nVVrEjJpxfgWYs1U1NVLk0iE1L9Tp+QqnUlQTg4sIz4jLj+hPijaleU12Ha4irfGRSi48Zi+6Jq+AG1XFlRn6Y9CbcZchSv8AwVFR+p+nkVqLUk7djtOPGfQ00tPTcmtXUcFXiyioSUWtaLynlJcBqzWpqJqoN+RtRgv9KVr1QopcNJybsgnUjKM0l37kN7J0nx3Y25OTl6kv6pNrC9QG5ylau2R+mVJ/dDdOkmgVLCy/JQm0m6d+GUouSbbBQSdtlXhNWvJB6fRfEdDQ6fT03HbLvSPWhNTipJ7k8pny2lprW6iMJPapOrPpdCMdPSjpwlaiqMWNytrtrIlbvwF4YXfijKm35eX2C+yJt3xTH/L47YIKTS4xkLdZolPt4DKVgVavAJ0sk3jHPkH5oCm/UMJE34QLPNFFW19gbqsUTigvhuyCk/LDdfKJsLAq6fHCDL9BXeOwXV+AHeeUg3epN1wN4Adr3C8WTeKQMB3fj7hkTfoD4AbfAcCbSyLd3YAnTq1kp/kyk1Xt2Y1Jt8KijS+LqhX+CVfkdkFMQvvhBdPNBVeUhetiT+6C8JADaQO/Ud49AfN+QJ5ZLjj+xfvyJ+lV6dwOecLXBy6un3Syd8lm+TGcVnBUc0dXT1dD+G6q3prMZLMtN+V5XoeZ1vS6nTTUZJOPMZxypLymd3WRjpw3t0+zRho9fFRej1EPmaDfHeL8rwyzZ8S+vPuueB13R1dZ0XyYrV0ZfN0JcTXb0fg5Lp4Ny6zVxn2fASh3jwTyOMnEqCE3B08rumXLTUo79N2u67olpSyhRlKErXJMUuXwFfk3ajrZh9M+67MxpxlVZ9RKY0j63ldiGrfkb2pYb9g+Zt/Sqxk0gSpOlj1NtLWjoybaU21RhOe520l7E5A60o6m3b9CXPcz1ord9D3eyJhNQ02ndviiPmNyvP2IFnusgkrWaRtFwkncG67mTg23XADdO8uvI4yX6abvgUVFd8lKW1XB57lEtOD72jr+G/xGp1UZRbcU/qZybnLFm/TdXPpVJRzZmrH0e677iOL4d1j6nTluX1RO1t3l/Y5tmn3/AHFeFTFbeGNP1Aq8MTeGLm8heUBXK8IMvBKb78D9QHeAWF3F3uwvADu1gL4yTbfPAXQFp4wxXgm/UE7XAFXQeosWgvvlgO69A8E9xp5bYDvwHBN4HYDvnyJMQXXcB3gLX3Ff3DP2AfHYL8ITx3C2wHa7Bb9RWH7EDryHqIP2AeaY7/AsceQXPigpp57h59SHrae7bvVv1Mut6j+H0HqRywNzPV19PSpzkkebofGM1qr70cPXdSuo1d0LS4NTjWde89eD03OM4tVjJ4X8brrUctzs51KdNJuuaCnHNWjU4pa26rq59RFRcUkcppNNrcuCKrsXE109J1k+mk0qlCWJQlxJGuv0mnrQet0duK/Vpv8AVH/KOEvR1p6M1PTk4td0Sz9i6zGs8nfKGl16uO3T6jx2n/g4tTTlpycZpprlMS6lhW4sq1L3IT88Dqso0DMWbxnHWW2eJ9pGKlfINVwSw09rStCUXTYNtPIP0ZpCr0yO85E75sbeOAEn6DyKsD4VVkg1g90NnGeSJ6coP/At721wXHVSlf8AUozq8gm8pI3UVOWHtT5JcFBO2QRfdVgKcspF6a02+Gb6y03p7ov7eAO7pOp6bQ0Yxi0m+Tv3KSuPD7nzOnpS1dRQWG+59F08PlaEYN20uTFjca3XLsVrHYV+BWzKr7YzYXXOPYm2gtAVecWF+5O6lQ9wDv8AcK7UTfcLxxkCse4r5FkLsCn7A+xN/cLsCr+wJiv0FefIFO8ZD0FfqJV4Aq28hfqJvgGA7D2EwvADv1C8CC/AD4C6FyADDv5JclGLk+Eci+J6LntfnkYO3jIbk+KZx9d1CXTS2TW58Hj6fWa2nLcpfYsmpr2+s61dLWLbJh8R0Z6W6Tp+Dxeo6nU6l3N8cGK9S9U7NNTVk9STjN1eCp9Vq6kdkptxM2mnimKuDWIVNcDz2RUXXbgTlaaKGpbbVW2vwJW3yK64wxxV5SV+oQ7afKDZuzFZXJFWOLp92AqvFCo0+mfapf1Ia9AojJxeGdkeo0+phs6nlYjqLle5xtUxexLCVrr9PPRecxfElwzLg6dDqXCLhNb9N8xYa3TJr5mg3KHjuibn1c/jmq8jT8iDnk0yfPId8By+AXOChuvuLhCayNrHIDcr5DtzkVAs4AO+QSzjJSj92XpablNVgCtNbVTvcbS0FqRUm6fqLUnDTjVXMxnrym1eEuEQRNJSpWqHdYvBTe+NvsZu1w8AVGexqUXlHV0nWa0uojG202cVYtHX0HUQ0ZSc0r7Mlix7gKRhodTDXVxZqufQw2oL+5Nqx3WSBh5FYu5RVhfe7F9sAA78B7C4FfZEFZ8hdE35HkB8+wXyTd8Bf5Aofeib8IOF6gNj8WybACufZB3E8mPU9THp4XLlgb9yZ6sNP9bSs5On+I6eral9NHB8S11qa96csUWRLXtqcXG4tNHjdT8Q1Y67UXST4OWHVasIOKk6Mm3Ntt5ZqcU16U/irlo7duWqZ5vqFMp2qa5NSYmlcpOm2wcaBeoqsQOLrP7A13/YFgbzlrLAL9grdwuBJWuOB1WbCHmKrsxXnhFWm/qWCa/ACVtMcml+l2NuLj9Kfqya2sAtXjgHG1ceA3Pxlg7T5Ae2VWUk2qdejIcnhMFJxeMgElTzyLFcFtprPBMlngCTTS1p6Uri6IryIiu2S0urdxS05+FwzN9N8uM46inv/lpHNGTTtHT/ABeo01KbaeMmcsVz+ouWVTfCEvDOjJr2snkq64ElbAPRMqGnKWV2NtPRV/V3ByWncUQPT2qkssWprKqUaa8GTk7dEXRQ27dti5YIclWEA1WVdE8YoXBdpxruAk8A3aE1XsNvGEQer8L0dkHqOSz2O/J8/DqNTTjti6R6/R6k9XQUp8mLGpXSF5yLNAyKdheBWNsB32F9hcsLAb7B7Csd12APcdtkt+QQFX2QdxX2E2oRcnwgK44YPGWziXxGG/a/I+r6iD0JKMsg10R1tOUqUkR1mu9DRclyeFHVnGSkm7L1ep1NVVJ4L1TXTofEpxn9eYsjresXUpJLg4x8GsTRVcCKVUPZi0VEglfBS21kSWH5AVDtNZ5FlvI+OMlAuz7gnlvuLvgpxrvkgTeKoak0qux9s4YlFXbYFRpSW5WvAOnJ1hEy/VdsJVtVPPcCo6m3Ee+CWnbtiiJ3YBdMbqTtBmr5BJrIAm2wxQ3XYltPsUHPqGB20sIXNXyA+PULxVCugyQNprvgllJ9uwUmsAKsCKaomrYFt+BbZS7FLPCNopr9XBRlp6dvPY0nGKVo1nqwhHbFcnJOTb5A0lqUl5MW23bdhh8jpUAcommO6GpALsNWmhuNq0xJ+QB/qsVUy4VF21YpS3MgFKk8AlawTWS4PYwEltkm1iz2NLq9FRjG0jyJO3YacJamoox5ZLFlfQXdNARppw04p8pFGGj9QvIr7ABViyHcGwAMnPqdZpwltKl1EPluSl2A0epBOm0VOSjByPA1dabm3u7ly6vVcNt4Lia1fX6i1G+1mut8RjPR2pZaPN5Y88GsTSvv3G5N8sa7qhNFBgFlgDoIawHOMBVsTwyh7aWQi2hPJenkCabzQO6yNyqVrBcn8xJVkDO8UhtWuS1ppfzZIbcXkBYGvfIrt4Q3LHFADlb+pA8Kw5pVke2S/VwQReRvyVUckN9uwArvBUYttpuhZrA+I5RQNpYE34Hti4+GKmnwAn5QJW8sddwVN5ATxaHmrBvsKmAS5BZaB8eoADw/IWHHJUa7ogTWMcE0aJ29q4B3F8AVGo5wEtS+5DdoKdFBKW4lj7CAVhY+RANIB9gv0AVusDTTVCYAPsJBYWBcFuYSVPkhNjt+SAvsXpTenNTRCaQK2B36XXylqJPhnop7kjwtCK+dG2ez86EVV8IxWo0wu4WeT1HWSeo1F4RUfiElp0+R1Na6/XuGo4rsWuvh8rPJ5c5Ocm/JJrDV6st+o2LfKqt0SU1SKiQGl5DljEHuGBt26YJUUUuH5JlbDPI7SWUBNUGB3aJ5wA/YddmgSadFNOL5yAbPpQnGuGJyl3FudUA5M0g6jfDM0r7jppAJ3dhuvnI1lZQqoAdP0Cs8ioaVgOqaoJSbBtvHgSdckCHz6A13BrwAdxywlXcnKY3LCRQiot9yew23XADbslgCWQEOwfI0AmAPkL7AHYaTYjTTaTpkCT28IqU1qKuGKdNvsZ00A0aLgAKIfJD5AAHEbAADsHgAAGIAAAAAH3F5ACAKiAFDh+tGk293LADNWMJcsQAaQDYAAdxvsAAJ8gAANcj7ABAdgYAUSxrkAAruS+QAAlyC4AAF3KfCAAHH9JLAAGxIAAPIgABvgqPAAQTIHwAACCXYAKEwQAAMO4AAMQAAxoAAcuRy/SgAg//Z";
const PATLICAN_GORSEL = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wgARCABgAGADASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAAMBAgQFBv/EABgBAQEBAQEAAAAAAAAAAAAAAAABAwIE/9oADAMBAAIQAxAAAAH0AAAAEEi+adU8xkPZHjOmehACDinV4nHoXXMrWZArMHvEHm5F4rOtTZqgrNxU6WJjNjTpee7sYXMns8TVkZs09TI3W0yM2NMLNtznTanmiK6G71Oh7uiWMCsyASGWuiRLbgBJEgAAAH//xAAgEAACAgMAAgMBAAAAAAAAAAABAgADBBESIDAQIzFA/9oACAEBAAEFAv4mZVlmdWsfOtMORaYMi0SrPPjZYtYuzyYzs58ydS/OAjOzn0XXLSt+S9x+NeOjOTLbBWMtttErLE6WE/AQwJOZwYKoTsk9MmLqvJYq+oK4EnECzmcQJHTsLj1gs25Z9li1wLOYEgScTmam5+y4MYqcwJAkCzma8Nan5NExUgWa8yJxAsA9Opr1/wD/xAAXEQADAQAAAAAAAAAAAAAAAAABEEAR/9oACAEDAQE/AYgtg//EABsRAAICAwEAAAAAAAAAAAAAAAECABEgITBB/9oACAECAQE/Ael5Iw9gazrEIYNc/wD/xAAnEAABAwIEBQUAAAAAAAAAAAABABEhAlEDIjAxEBIgQWEjMkBQgf/aAAgBAQAGPwL4WYsssrLC95UYlS9QP0vUWTYYbysx0JTYUm6eovovUVam2lcnYJiXPfSlGoom65q/wLl4SoHDboZ2CBbbgauysttCU1Ihefrf/8QAJhAAAgEDAwMEAwAAAAAAAAAAAAERITFRECBBYXGRMECBsaHB0f/aAAgBAQABPyH2SWU9xRUbnCl7F/8AOO58gShQMrbD2JSEyJw1vWBJc7EI20Jckz9RJiW66QQQW2fBcuWR5vAuiUjgUViaklWdLQSKeUDU8h/gSlwiCJR3FpKryS3KuiGr0ErqLFEnA5h94fQ55VsXLTfdZBLpcWd8K5P+mmLJ+BPATCbTqduWORAfJcky2qfgkkpYswRrAUrfJid31VBFFYEdQg5nKDonkTa6ghGylJCUjubaEYhG6fUwkejQj0v/2gAMAwEAAgADAAAAEAABDOOAFAeIDLcR9o2lKMwiGFJmBPMDLGIAAP/EABsRAAMAAgMAAAAAAAAAAAAAAAABERAwMUBR/9oACAEDAQE/ENEJlKkmKUoyXIn6PoP/xAAaEQADAAMBAAAAAAAAAAAAAAABEBEAITBR/9oACAECAQE/EOhCxSKILZbOE8irHwSE5//EACQQAQACAgICAgIDAQAAAAAAAAEAESFBMVFhcRCRIIEwQMHR/9oACAEBAAE/EP6Vbl5S4Ct8EdT01mILn9UgIB6Wn0x/TCVJ+KwRoXL6J9kAMWM3b8V8LGVfgHQFqaCY9cCuHo3HzvtXKhaWg2JTzE+UtS8Hy9BEFKcnH77fi1KZY5iUcsZly2Ipcw4QWWR4pzsFByv8DuPt5qsF8DoDXmKQWrQRRYDSqgmY68K0xK2uoW0K9E0oTli3mIcJ6IcJ/UcFAdGWIWNMvADR4I1dgyl1WcuvUaOGAo5vk+yJdNtqtf8AP3EV2Do2/ccKoO6h/wCEA4P3OOAHgqO5ueGMbFVefh6iOxVmSe1y/vC5eBGoOF9hvxfMqsCd8s7S9kytmeOVahGoBqCajCI1Ki09TUBRpsIBfPiKMd4N16jK3K7hGoJqEagmoCVKisHEzShOsOhKaxCHEM1ASvxscQHUE1A0gD+BtuCQBr+L/9k=";
const SURUM = "6.12 · 12.09.2026";
const MAGAZA_URUNLER = [
    { id: "lejyoner", ad: "LEJYONER ESCORT", alt: "Sezonluk ödül · 3 adet", fiyat: 2000, stok: 3, kisa: "LE" },
];
const LEJYONER_GORSEL = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIjJSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCT/wgARCAQ4AtADASIAAhEBAxEB/8QAGwAAAgMBAQEAAAAAAAAAAAAAAgMAAQQFBgf/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAX/2gAMAwEAAhADEAAAAfTeO9j47zdubh3YZTcppu6XP6UurQl6n570nm05aHpXKa2ay1i2ZpvS+aZsx9SHB0qOfbgIYkFdEFDgN2QuXC5LKu4DCsuioklgQxKE4VDAqXRVywJd0EuwLuiSxgIdUAkMWJQWJjQkQliUBuihVOCgl2CJKCKWDLgu5Ser8Z7Lx+88rFuxQ1gMl39Lm9M1vU8Z5v03mzko0Z1yMA9ZawDzXOU2aZ1eX0T02pHTueTzvSYZeJNiZUmUKKEVTKIJwWcsq7okuEklUUosCEqygMuklXFG4SBRiskgInCDLBqwJRwXRVA0dUAsEqjqBu7pZUQFQSwMSquipKJRw9T432fjN8+Zh24JdLFMl3dXmdQ2vS4b5v0nnDko0Z1xsA9ZawGZ01ydEp9Hn9CPT9Ti9neWLYWs8/B28+dcQOnjzUndlCcVdy0qFSwoYEMSodFUQkpgoNFahUIqjFBKrJRVQQhiVcAKQETihRULo6BEiBq4BRQGjEqjEFTwKliSioGFAaMT1PjvZeP3z5GDfz5XOS9d/U5fSjotToGeb9J5yuSh6JcbFnrLWqZnT3pbKzqcvrR1exh12NZmDU6NJfrKsu8ZeUrpZs3BelUojcIN0pEJlgYoVFBYnCUVVUuoglRKMAbKVBokESpRl0SrKFw6UKMQIQAy6LG6Au4DdQq6hF3YNFRUuFDcIJ0eq8Z7HyHTnx+f0edmu0JdLv6fM6Zu059Nh+Z9N5peXneiXGxbNZYwGZ05yHyt6vK6kel38vqazWPo5rJowaTWF3uAp1xjXsCXlr6ebNyAdTUMKGEtiVB5tnTnkOVufRR+adlPZj5jvZ1pqXLJLKkgNkBVEIN3ZQmMVDChljFCUF0SyXYrRUYsWQXJCqKC7IQLISxuioVHpvJet8l058fn9DHnTGrdG3qczpG/Vk1WN8t6vyq8xGhEuFq2XLWLZNNcpsrupzOrHodqdWsuQ5O5kcl+a6yDWWFl0VBKhSNKs3mC5eNLh0VgR4Tpjq8bJl7c+mnnabHZ87yGKY9l7X4v1sb+szHt5dBoqKopAUdASQuCS1UiVJa0BgLA6lurFBuQqwi1CoG4QujoESllS5KMMT03kPX+Q3z5GPbgmnNU2N3U5XVXbryabnR5f0/mF5SmrzcJCWstaps016Hyu6fM6J7DbzulvFZdybOexufOtp5tOsqtolXLspbaXn59ufGk8nV4HWcuAub25sSDLAbobGXVUrMo1kuqO19T+Ker57+iVU5dLq5FUYEEhAKEBLolFABIVCXChKpRkhQ3ChMAqkBE6KE6sq6sgEB6ryPr/H7xx8G/BnTmpfG3p8zrGvXl1WM816bzS8lLVS4ihXLTE5pr0PlbuxaT03a852bnpEh/XGbD0MeNBqwOjbUZvI2QlVLE87o+Vl8z57XweuKXXpDkd/0vW4ejzNemy8+viuP7jzXbhxE6cvfzyXRGBI+n+h+UfVuPUqg5tjBWxuijGi5BLqpAidA3CFiYrVWJYHRVXUsolkksobuypdFCVHqfHey8dvHIwbsGdNapsbuvyusbdObVYzzfpfMryUuVm4iEtRzFtzWPQ9WaM+hOx1+H1joa+czeehiYkU6nwbwPeYF0AVUYvm3sPnemPj9XkdOfS+m+M+k+X2Np1S5Od0+fjpysPWzR5Xgez4Xo83DOh7+Y7G5S+jfOOznX1YQZy6BRBLdUJcGgqGgpVQYwS7Gyquli2AFLqWhKkETWpjISXLKEhJVyPUeO9b5PeONh34c6Y1TTo9PldVdurPouXea9L5peQpqM3IYHqOYpkrHo0SnpzaTpdHDok655dO5R05DfTNypBsoSqKwdDgHmPJ9PldMo5XT52s+1994n23j92qs9WM5mbxR2OVr3XPDT1cRxeb6Xh9eOa6LrxsgKX6b3vmX0rl1uiDFg0K3VUXdCXa7LsYFa2FWFxVXFuUQEsYsZZAOlklJAMaglD0XlPWeT1jjYd+HOmNWw6HW5HXNunNqsd5f0/mV46nozcZgWpoNbZSep0p6c+o6jkaIbrxMs3auft1NZqPWWAQ2BJSr8r3fCp5pJI64DHoSnfazTx9Gz2Pz733LtwOX0sMs817fj9eXmO+/p41w+L6bjHl7MPX4jtbDR9M+W+zx09suw5bpZLLEZBxdLdLsdS7G2uwrGy6oZWwaCqWVJBd3RKll1LKlUen8j7Hx28cbFuw40xi2HR6vK6hu05tNjvNel8yvJz6EZuMhLWXtWedNelyteh8dTVm0DIJWN2c7WdM87+mGVRWAJVL5fxnrvnWohDsvTFpYo2eq43vOHo4vsKZz7eXy7+PL6dyOiuLnbuRnWHkdHmb58ZW8fR5eaxbenIOtzHS/VW8rq8eq1GqKgUWAhDImLoibGMSUOtRh2NqUGBEBEuoQCCIY3Qy6LG4eq8d6/yG8cbFt5+NOIWHR6vL6q7NObVY3zPpvNnHS5OdYiA9Ze1Tc1jkOV+jLqOtqy9GETUmxDAh0NnK1WdI8h7yY1Dxnz/wCifNN5oareQQ/LZ7f3/wA++g+P36lZETXJ5W7mG30vn+jLXH6PJly49ubfLkirn+jy21TOnJtDJfceo8L7Pl1inIzQXa4lANHQVK60kMdnKHkohpLNSsSCsbCqrBooVJCVYhS5HpfI+v8AIdMcfndHBjRsW06PX5PVNz82umee9B5046HozcBS9Ze1Z501+fQrNePWdfpcvqJoj6s5y9qJQIGDnZnWPtWXU8V4ffj7c4ApsFcrWer9S+M/QfP6vVdDjY/P6u1wgy7tZEbWOvy+pyuZOHdyemOJmZXr8QkVXNQGL2/YfPfd899XO1PPakmkoaAOLJSJRw61MhxoNdMWQ0hIKxshVQQ2JcoyDdEohPUeQ9h5DWeNz+hgzWNU06PV5PXNenNpG+d9H52uMh6M3CQFrOhqm50ehD5WaUOOr0eVts7bMezUUrQqMJNWpsQ1G+X9R5/U8P530XB7c0IbNZVGrsrvcOS/Zm+Y9R4Poc/nenmteUf2eZljzDiuZxtmfpy5BUPp8rFENzLIVZ6PzXXzr3asG3ltSGKUVwIuwoaaWynYWOYk4eaGLoJTYJgFV1KLEqLILKl2VV0em8l6bzGs8fn9DBmm1bDodXldVd2jPosf5z0fnDj53ozcJjes6GpdnRvS5W6M+k6GvJrk07OcyupSHagi0TPbFwyUVnzrzn1n5T1zydaNe8YNGYrKXoShfQPnMzv7onwHf8vt6nnyw40hWhesrz78tzwFasvq8clVrOlRVKPf4G+Xrek8r6vntCzzy0F1KMlBmopTMDgmrMa1Zq1qWymSyscEoKCRUkLksqrE7XnfTeaueNh34ZWGBnQ6nL667HJcmjz/AKLzlcVD1Z1hIS1h7FNztrk6BmjPoN2tD4Ni22OZnOthZn2AJ0WVKsyfLu753pnDTM+8KuDZry6Ewurmof0L5173h362Xol4/Z5xfUrU52Tp49Z4PP8AQcn0+bDCLrxCwiH1eQc11PW+f3c99BRBmgBBLVVA7WUrTC4cxTVcSjHmBlmBhSrIQESrEMhsGFR3/Mep8tc8fFuwStIGm7r8jsrr0JejfOeh8/XFS9ObhIS1HOQ7Nc/M9XaseqOm5GhDuSjICGuU2woJUrxPT8tvOZVh0xkwtqwVMXZpS7MUQGk9h5D1vLt616dXj9mItQS+fQ92887mehz7x5LJ7HJ15eXXuw9vOMKWbO/5XqY36W87ue6WQyhJRZgUriUcOYhg1qnK01sDuoHJZckJVwKpYNlZ6HynrPKazxsG/Bmsapi9Dr8frpuch1jOD6DgLxktTnWEgPWHNU6aa5T5T059MdJyHDal2WwDGMU2w7oq+dhv830xjp6d5TlcqxazlmjI5BZiZfr/ADXruHf0G7L0fL6gx9LmmEmIpZ1xNY6vk8GX0+YaOduI2UKu7C3c4pfRaPKd3l01DdY0VjcptWcMNbg2qbTWJbKbAIOCUXYyrMThZXdVJZ6Ly/qvLazw8G/DmmxbF3dnjdZOhozabGef9BwF4ampzrHdFrLXpdKx6Hyt05nnS0ZtEMMTspgMCYtlhsXepzvmn1r51qcCIDpgs002ZGMw2Qw0onUoZr13o/Jd3zertP4g46einleZc+14fiU9uHR5l124jCqyS4VcskuixsASWMeoPmdPh2uwuaaxLIexJw5qmK9ijRpKYpEJBSoFdEXBtCGrX03l/U+X3jgc/o8/GmtU1dvW5XVN2jNpuXef9B55eIh6c6wmBaw96HZ016HK92fUb9SNCGQmRizoyq7GXVJj+d9HzPTOVLR6Yosw2VVnYDwuJQtD1ZdQk7YTNIVLlVJCVdEuQl1CQbIBAAJCa/QeV9Jy6Oqr57YxLJXMUwa1LJdLENGMWSMsCU4NhEMCuxJdWen8t6ryuscLBvwZ00wM39bk9Vd+jNpuXec9J51eIlqc6xXV6w9ymTTX53yv05tR0NWXQjio6WQsCYJpeHbzdT51k6HL64yXV6yh13YoSUMC4lnZVXR5/Ul2cHbiipc1Klwqroklkq6JUEo1sBGrBEhK7XF3Y12rEuPUjCxrc7JXsURqbmdD35GjoFhkJqVjYyqiXJS+o8r6vy2scLndHn50xi2Lv63J6pu1ZNdy7znovPrwlOTnWC6vWNDkummOS6XRoy6To6smseVSwGLYMMDstbcNnzbldXl9cVDVrOSGsGrKy2FdlFLKu7Kq4VLsqrhVSEkEuoJQ0ITUMAOiAEqBYu49NEN49mWN5pGsjQaGS6WoM0tQ0YazgzAyyq1sqsEoR6by/qPLazw+d0OfmuNZnQ6vK6y7NKH3Ojz/AHuGvn1sVnWAqvWHvQ6ac1TJX6cuk6OvJsRpUVJapgbAKwPMet89Z5bz3QwdcRis+srKBZT7OwbuFXLJchUuEq6JV0VV0VIJFWsuqqDujo6ugRMAZJHY2c/ocupWN50RAUMahkuludpqJRmgllDTFiwhsbBshVZ6by/pvM6zwuf0MGaxizN/X5PWXe/Ppsbwu9584KXKzcNy9ZexTZpzVNlfoy6jpbMe1HC0aQYkMatlheG9p4LWfNZupzuuMrrKzJotusjRQGXCS4VLhUuFSQoSEqrEgWBQwYg3VG9LiwKigMQJJHR6XM6fLoVhedMsClIgKHOztl0sQynuSyHEsldUgbVmFBh6XzfpPN6zwuf0Ofmm1TTf1uT1zbpy7Kb5/v8AAOClyc3DdXrL2qbnT2partObUdDfh3popkrLcgxgWl+D9d5TeeBzuz5/rg6ZVjxMNZGroqXCS4VRUSSEqUVUoobEoLEobqKq6pjkOKKoDRCBJI6HS5vT5dIYFnRQblI1nBtU1XOScaGJaMaohxCSkxRDhEj1HmfUeY1ngc/oc/NY1TV39XldY268uq5Z5/0Hn14KnKzrBdTWHvSyae1LpXasuiOn0MHTs1iYWZRIVNgFYzJrZZ8s896Hhd+StOLo2ABBZKqgoMCgwKDAqGF1VEqCQLEobElSRVXQTVNpizogmAuSR0ujzujy63UmadiUtkJBsUyV5qZD2ocNNZLoNZhkDCjlHqvMeq8tvHn+f0MGNG1Zrv6/G7Bv1ZNNy/z/AH+AvBS5WdYJV6xoaps01yXSv0Z9R0+hzt6baErM0qKdidjDWdnynjdLm+jjl6GDVZayWXQiHBgUGFyoFVUFVUWMEg2MSpRJIVV1VvQ8hiRQGAuSR09+Hdy63JM0iApbOoEwCla/PohjVMGmDFcS2DCWQyVZ6zzHp/Mbx5/BvwY0ZURu63I7C79OXVcs4Pe4S8BZrzrnkN6xoYp005yXyt1ZdJ09uDam+1Nsy3KUyo7LMF2fIcmjP6eCZec3JaoGpRckJJCSQlXRKlEqVFSUSpCVdVKui3KaMkhQGIurqOtry6eXU7Es2yA5bISCITlY9DYeYMU2LMaxZjSAyFInrfMen8vvPn8WzDjTWLNd3W5PXN2jPpuW8Dv+fXgLarNwXRby9qm503Qh8rdKHnR24tyaSh2ZClhkDKvD0ONrPy9TkejirNoSNfj1CSB4EbBUZBcZBcYIAmAAmMDV0VJKlXRKjDZn63JzTkmpBuhUlR2nrbx63cksujWHLgrG5WuQ+HMAhrUuUnJaMIbLKiPWeY9N5rePO4d+HGjIDXf1+P2DdozaLnT5v0fAt8+pi8awEJaw9qXzTNCHSv05dB0tmLemw6KzLJAyo6LzXpvH7z4bO5HfitTFC9OfUG+6BEhKkolVCxkBEhBEhKq6Kq5FVdFdPm+imlcrs8aCq63mDdC6IY7rVO49bsblswuVhAUWQErHKdDWLcpME0NgErCog7WZ6vzXpvM7x5/Du5+NNITXb2OR1zboz6bl3B7/AJ+uAtgY3z7l6w5ynZ0xynK3Qh50ehg3pskqzPLpWmN2N+f+/wDmnTHn0Nz9uVKYsX0eb0w6iQ5YlAJF3KJUgI2JQ3RVXRVXRKuof6LmdTnvNx+5w9S5c3kRIQKuR3Sq+PYrEouxJSMCg5RSm5TIe1TFaxTRhSxhiRclnrfM+l83vHnsG/Dz0ZLau7rcfr10H59Fzo8/3uFb59LV41gIb1jQ1R51oahyv0ZdR0d2Dem2DdiClDDE6nyX6V8j7c1hYdOdLMSteTqGVzM4WaPAYSixqyVYgjYlVdFSSKq6Kl2eieVcuqOL3PP7wwYe8rpgC6kjvkN8ex2JRLq5SKiiEMVzVthzEtVrFuCatgR1YdiR6rzXo/Obx5/Dvw40TFNXV2OR1zfpzarl3B73CrzqzDG8Mk1hzVOmmPS6V2nO8378G9N10Vme6Mtq2annvmftvEd+Sxgazaio1NKGaaoBVqKE7BqwIJCDRQEToGXRQ3RNeTVHpAMePVPC9D57pg5L3kFtWKIWx27G+PYrEohUS2YHF3RQxqWzTXKaNNbBjBYFYkHco9T530vmt44GHbgxphrYuzscfsm3Sh9y/g9zhV59bFY1hl1rL2KbNPch8rtGfQb92DoJtuisQQENNa9T5twNGb0cFgYVTU9EYkxAo6F0wQboRlLEaKxG0qhtKgygoIZRNePdHohIOPUeH3eLvKruumBUxYt+fVm9exLl1u6KLISlK6uCKiUmgcMcpqsYsxxrMYwCLITPV+Z9N5rePP8AP6HPxozW019njdhei/PpsZw+7wrPPLNWdYwKay9gMzpr0OldoRqNm/FsTea22ZbuDeD3vGdM+KQ5PfioSE0a4JVSi6ugaugaKgaOgKKgKKiqKiqKgaIQbqR62YdvLqPG7PG1kKsemAWxQGrLszerdXx63dWEaylK5cEazVjkNlaxbRjFmNahwRyhliZ6vzfpPNbx57BuwY0bBJdnY5HYTdryarG8Hv8ABrzqmBjWC5NZ0NWyaa1TZX7Mmk3bMepOg3O2xdSDPm/0n5H254UtT15r0ZumWshBE4VJQNXRUkIN0UJCVVwqXRKuihMAasTo9zyvqee64nb4ZBsemAWxUDvwdPOt9y+XSiq1hiUWVWEQnKbkulNi2DWqaGxZBmJlsWZ63zPpvM7x5zB0MGNMITXZ2eN2U3a8eyxvB73CrzYNTnWKxLWXuSzOnOQ+V+nNoN2zJqs1uQ1BurpPyX6X8z7cs6mp6YPehgA3CpISpRKgl1UJUolSiVISSEkhQGANXRO/5/qZvV4vZ48tAS95FRhFdnj93O23V8t3ci0UuCISizA1PRnfKwwYGxbBhiZbQMK7h6zzPpvNbx53n9Hm401iyN3Y43YOhrx6tRnD7fEPOqcrOsF1NZ0MWzOm6cz5dGjPoN+vLrRzUusoquvNeA9d5H0cUpZWs71sSCN0XBgQyiVKJJRJIUJUVLhUllSQoSEESErVluPS8no86aADXrILMIL0PD7vPdXJjdyWXdFLdwohCSscl0Mao1cxTBliwNiXByQ9Z5v0fnN489y+nzMaca2G3r8rqm7Xl1WN4fc4deeU1WdYZJcvYDJpmnM+V+nNoN+rLsscxbC7ks+d+e24fTwS7NusJRAUNwGFRVXRUlEq6JJCpIVJZVFAZcBohBExBko6ylMgFMVQiQxt7HN6PLpLkzq5clhVYclxdiak9D4YwGKbAMcxTSmCQd0R6rzfpfNbx53m9Lm401qzN/W5HZNmrLos0cDv8CuAs1Z1iuiuXNSyac1L5XaM7zobsOyzQYGl4dvD1Pn+LQj08M3W528BcEglAbuiVKJUolSEkoupCVcKhWBTYKpoACYA1dGtlQADUDUuOzqA+PWWJSlUikQlBWJy0YGMap0NYNqbFsHGswyEgiq09b5n0vnN58zi24sajs+k2dnj9k2asurUZwe/wDgKNedY7G7l7Uvmjelkr9GfSm/Vl2WPKoH4z2XznrjiYtGftydsztAC4BTaF3YhUNBDIVJCpdgQ7F06CY6CY6hcMRYmANXZtEgAA1gtVtzevJOXW5JF3JLDEizEpblEG9ToddEpMW4M1sCIbG3Yp63znofPbz5nHsw40GrPpNvZ43XNuvHqsfwe7wq88pys6w3Jcvap00T0uldoy6jftxa7NBAdk+UfR/mnbnmx6M3Tn04QixKgLug7RB1LIlFYoXQRHUJp0ExsFRtibfBNNAWJgC1WgepigVkETqcvt51pl1y6S5ZZVcsuQsqKBatital0NNZhtS1TapoRCYyio9V5/wBD57ePM83qYsas1mbetyOqb9GTXZo4nZ41eeS5WdYqq9Ze1Ts6Y7O2V+jNps6OnLrTQYXXn/Bep8r6OOfO5es9RTViwYIEKiSQEWWJF9CrMSEuh1oo0TPDREWOi7LGhIu6B2ZNwKmKBGxL9Fw+9z2MKue7uiIVFLLqy7q4IhJWOS2GsUxWMAwmrMMxiMkh67z3o/N7z5zDtw40RCZr6XN6Rv149th8jscWvPqYvOsV1Ws6WpdnRtU6U9WXXZv2c/aaCWSeb3dw3Xw3jPrPz3pyygxffzrogCi6G0uBwSKl2VLolXCpIXKgUkIJAUs1ggYj/Rdr1XD0fJsH1bz014ce3zOvB/Y5vRxaq5nUKoWYFKUuRCAgio1NyHSsMLGsWxCaLFOpdllVx7DzfoPO7z57Buw40cqG3p8vpm/bh2WP4vb4ledWYZ1isb1nQxbc6axbJWac+izZsy6DTYNNEajPfL4D3/gOnPlAYenxhIIUGyxKxYuoTT6FWdFSxCsIHAgcGyDYggQFdXk+8xv2EJfk92DldLnZ1yMm5PXjlOTpwklRd0RRS5SkkXdEpEBQx6WhmDVIwYGyoHdMS5cOnxsOeiw7cEMuQ19Pl9E6O3BusfxOzxq88BqzrEQ3rOlimZ05qXSs0ZdVm/Rm0jNmPoKWXLhz36Pzj23h+nLLQ36fGNXAaOC4cBuqDtUHRVjKqFyoS6hKlAiQAjYxf1z5b9V4+nYrJr4enmYN3Ojmi5e+eS6nXz3VXF3REIblK6uIY2tmBwbVtUmLYNalowxIOxJCIDXi1YxOfu59j4MNfS5fSrobsGuzXxOxxzz6nJzccl6j2Kbmual0rNOXVWzTl0j+ryNk35/m7OJevqvN9/ka4+RZnf6fINQQrCDIBF1cBhQCjgEOwLuFSUVViUFiUN1HT+keF9h5/Yrved62OvLHnac3Gq065qknTziUoIgIu6KWyq4hCSwxKDcl620CGsBgZgYdwkhSHGAly1z93O1H2u01dPldJeju5+1NXI6nJrgKcrNxyr1HOS/NNyWyt05tFbdObQjNuHS3w/Pev8devpeT6rgMeC05Nfq8Q1dEooBTKAKCGSYPiSGQLCqUSpRQ2JQEJVSo9L6fidHz+3SzZw8bwNBaRZr1gautcZJC7olsgOCsSll1cEVQY1TVNqzGmtowgMOxNLYszz2MnVlVsxodrutXR5m+Ons5m038rpc2uGswzcJCWo5qm5riW1T1ZNJu05tCNIGKvwvvME9HK8w4O3Dl6RLr5aqxq7qy5ISXAaOC6ZBdnAYUBEhBqxKAhKqxj02fge5x29J5Po8jz+vVnILzoSrfEbq0qSgrq5SISCurlswuIdEW5bVaQGG1LQ2LYEYkhSjPNCoaHLuJMDd+iudt3aoy63PqsTuNGZbFS4pJqaDWzNcxLlLVk1G3Rm0o1yWDUNO3z/lfo3m3Xwz9Gb0+OqurmoUKuoFYQZAsKVZVyFSUCJCCJCDViVV1G73viOrx9RNS7NXLG8qGxJJCXULISljFmFKkp3Liyqw3pcpMUwNgMCasgzA0Oxo82/obK5ujqOswN6DrMTcPCXu8TFM2AQQa2LMcq9R5rZmm1LFdozaDa/NoTQ1TqJizDJZ15Lx/vPCduIUVbzUlkuQupCpdlQqJdWVViCJCCNiVViSSRLrSvpGMXx6qEwihKipCKlyUSqB2JQVXFIhKLuiGNU1SYtqG0DWzAxhCSFYWdDTpvplJ8jzkek87huWXAlMaMGFIi2JMkq9xprZk1qHStchxsfm0Gl+V1OJZjDUw5Hz36R837cgqTpipcJYwODZcllS4VLooSEESAobEqpIklk7PG9PnW1TF8ugCQFVcBksl1csl0Q6Iu6KW7E4hiYbFsGGtqmYWjCogzlgnCGebxlqFUqUhowSuwbllSSKS1NZqk1ljFlmuYpsrjWZrfl0mh2dpoJR0xudxl+afTPmnbkqirpirkJJCS4Sxsu6slWJQ2JQEIIkJUkiXUGey8/6Pn0UBhjSxMQasSpIQhKW5VlkJQRDJSMWFMEgiExjFGNIGBsWYwlkFYWeZG61IYlLdwQrqFyoSiGKS1VZZVay8gLNYxZyuYli6tOPSmhud9NYlo1iWBeA+gM3n5HXv+Pp5idbHvGaSaxLkJLokuFVdAiQAiQg1YkkkS6s9L0wPj2UDFwujAqrEoShRVct3LiilrCo4h1amUIpgsS2DYbFmGxRjCWyisbjzI2VVLhKKiXVxJISrEpLFWZqq9RpgUrGKPNY1LV1Nzus0NQ0e1LRppMexLLEC1HL01g6a89OBg9Dh1jz+ftZOnLlr2Z+nIK+gas6+aj9E5u+fix9Fz9Z5Ya0aymipKkMBzezNdhbF8ugqMAVsGAqxIJUWVXLcoohVAyWUrDAw7kLMGKZCQ25ZZCxCurLuiPM3RVdVZLqiEBxJKIMGohqkzSpqNNZymQFK5iTjW7M80GltPdncMNZj2JZR8/fix1cNXy758e7LXNw9TDrHMtmvePa6VO5dSUxGpmyasmbjybMlmVGlWsJpg2a9cnTgCjGxINXCxMARKiVIXKKWXRRd1FsqKGGBBmBlkJqZDY4lsLuElkFh3KPNyrq5Vkksq5CSoDV0CpybMtXVjTWcpkBSsNZRofncaHZn05+do40sHsSym5nrlSSG8PYObSizFi34rOf1eZ39Y9A5TMbpDs9ZsunHLmy6MlwtRL1mjXt1jati98Viaxa2qAEwBqwJLpYYlEKriiElKUyCITCMSCKopsAg2LJIwDUoLEsqs81KlXJCEMCqUXBsobpBU1VZLk1DMTzbKrgzWxXtSyHuQ2tDENHGoxzUMHGo7Oa4B4exymiuHFvw2YPUeY9fZvMClDM7KIyPyQjI7NrILIbiuxye5vmtbF75qBggKcqAWwCgICSUp2NxZDIOxtSNbIYYkWYmFdEWdUNgGEQkGQEMg2ebl1UqUHVWXVQklFBY2RTFmeqvUYxZZp3LgjWxWtS0c5DRrVMGmpg5qGjWKZZmydLl8/RukvHXFz+hz6w+18d7FH3VCsjskqcjsliM7U6wElXOvpZ9O+KlsXrKxYAsDCAEgBGxKq4t3dQV1cQoSwxuHWBhlRBEJBEJkYJF2Jl3RF3JXmpdFSWQ12XJRJILq5YKXKrNJdywhuUzApSNbJWmpg1qWGhiHDGpMexLB5KZTeT0+djo887efpx4NPN1lvrvH+vh42oz43YpV5GZrlajHWIBlZ2YYdOC1NCxVEMLU0BYMAAbi1LqIQ2WVFFkMUyFkXd2EwCDlWGwSClWWxZhSHUsSjzV1KuVCikKkpJUoqqlRLFVnsbuWks5TNbJbNZSsNZj2JaOahg81GOYlg5iTpuTSrOs71M5evBx+7ydZX7HxPs01ZtGGazYnY4Wg16wF3LkNOXfrHQW1e+ILYugBi4BTVALYsGrpakkXYkEQFEKorGKOG2DaIhIhCQximFyVDLqhpLumWJHmboiSqLksobqyVKBqxKUxdmeSWMNZymQFKd0QRrOHMUxWtzsNBpYOYoxxqOmjclyU7Py9iebtxazl9r4n3EjuZ0OTNZsrsyAMK5gsXYrq8ntb5OAw1yBbF0KzABTFQsDAqrFZKssgKLsSCNZykQNCIWBWNjLCxhrYHKIlywrqw7CzzcuWSSpSqUQbqyDdA1dWCowEVJYwhKUjC1MhKDNZjGJOHNS1WsSwcxLBxqZTDWwQu64+zIvVirB7PxPr0dznpzrn4tGPWDMGpFtTYnu8Hvb5GBhrksGLoANYCmqhYmAFXRJUW7EospcQwNbKoNNbAjGwrowiBhDGw5IGQEFdWeZsSsklLdQUIZRKlVBukWDFiJU1GkBZpGBKRBcMJZDSWcOYho81mrWpZTjSxHMUxVp1K4+vHzejhrn+gwGnUyvxzeJegbgHLcCh6GUdflaN8+sJBviAmulgYAKaqFjYgS4oS4l3VykQkQgKDMCVl1YwgMIwIJijDISLksKSDLAzzNSWXUhKghDKKlSyVYgrYqkSrsYQHBGspTsbDsSlNimBtS2HGpo41MVjVMpxrMKwfw9fLTrC3Ni3YbnpDn2qjJuwlNBkikuVrK1uVc9y8WzpwBbFWAJBAAxQsbECiEupCEFqdgcQxsYYHKZrMM1mHdWWYwYazDlWHUIhQjy8ksqSixuqqrpKkolSilMVSJV3LCEpSIblOxIshJSMDhjEMh7ENHsSdPYpg41sJsxbePrxo15JcmLdj1mutwvSGPD0803j1A9MSnKuAW1dh9XhdzpxFTV6wsSXFKMAAIARKiXUJJZZCUt2JhmBymVEkYBlmN0diSsqiCsDCuoMJcjzck1mDISpCpIDUhVSFKkrNclyZySkUkFJFIpC2SS2yQYcgxsg45BzJCtknH1LwyLlzSWK6sla88mNpZImJEmsAuSxfUk3zauTXJapKpUkCuSgqQlyRJIXckpHIWcgRyDGSS3JKM5C7kIcgypArkj/8QAMBAAAgEDAgYBBAICAwEBAQAAAAECAxARBCAFEiEwMTJBEyIzQBQ0I0IGFSQlQ1D/2gAIAQEAAQUCqedf/ZZ/v8opkCNka/8AsEiXlWVlamjlMbFZGP08bPjfgxvwPa742531DXf2ZH+/yikQIiF4139hjH5VkIQjTrJ9PpKjgcMdrF1f43fHZ+N7W9jPN0Ys7YHkRnbWNd/Zkf7iKREiISNf+djH5VkK+m8xj0UCdEnTw8GN+DF8GL/Hfd8bHsR87HfPTdm3m9Xzr/7DP9xFIiREra/84xisiN9N7UupAnEnTJQOUwYMC/RSs1ZbMbHsZ1tjsPa9qjbBHqMqedf/AGGf7iKRTERH54h/YYxishCEUPOn8RMZHHI4E6fXl7SMfpPe7vZ57Muyyr7cQ/ss/wBxFIgIVuIfnJDFeIhFE08sEXfBOJKBKJjZ42IRg+ex5eLPvsxbFnuXUatkYt1U4j/aY/f5RSICEI4j/YJDFZCFah1VPoQl05jInblJ0xxHE8CMXYr/ADf5uxXasrvY9mLu+B783aFuqHEv7TH7iKXiBAj5RxD8xIYhCEK2m6EIZIxwSQpELIkOJKI4Dj2V2vi3jsLuO3g8XRizs9lU4j/aY/eNqZTIitxD85IYrIQraYpdUojiNYcWJ5u+o4ZHE5Rw6tY2J3+NmV2UtnxdDEO7HZ3e352u8/HEv7DJfkQikQI2RxD85IkKysraYpEHaaPDgxXfUaGhxJQGtitzJFfiFGiVeMzZU4jqGLXVU6HEotf95RhKlq6Vddp3xtxd+bYt8tdLvsz9eJf2WP8AJ8lIpkLI1/8AYGS8qyEIRpiESD6kh+Y2yZ2PqTGtiNTrIUFqdfVqjqJH1OYdXq5pHl5aKdepSej440UqsK0L/PeY/GB+Nrs7/G2p68T/ALTMfd8opECAhGv/ALDJEyNkIQjSEF05bSZ8xszJm7Q10mupgxg1msjQjW1M6jlkaYpYc3zU85KeCdsmi11TRz0mqp6ulufadnsydcId3f521fXiX9hjf3fJSIkSNuIfnGTFZERW0nmj4Q4kkNCYrOItjRNdWra3Vx08Ksp15TqRgOq2c1uooZMcicr+Dh+vloqtKrGrDYuxjY+hiztju/BU9eI/nY/f5KRAQj44j+cZMVkIjbTPrRfRW5SStGXYmho1OojShXrS1M69UeLKLZHTtjoSioy5SfUe3g2v+jNPofNn2Xtdsnz3Z+OJfnkP3+SkQIkReOI/mJEiNkIjaiUJEH0VpHhoT3yK0uVcQr/VqV6vKm8C6lPTtlDRM/i5P4mDUabDcOUksbYs4RrHqaFn23ve9bvkn68S/sSJe/yUiAiNuI/mJEiNkIjal5ospzIvNpk+toyFukcU1X0oSliM5ZaWXpNC5FDQRR9FI+mTgVoZNRTcSTv4vw3WvSaiLyti/T+d6vLxxH87Jfk+SkUyIhHEvzjJCshIjaBSZTZGZGeRkvPykR3aieDiFf6tfUS6S86Kl9SppdNiKp4XKMqFREqeTU6VEo42o4NrHVo9x3+D57K3y8cT/sMf5PlFEgRIi88S/sEiRGyEK1MgU2NdKbOYfnlyQiJWd5PlWvrKMJvmlV8s4RT+6j0RgmicSUSUcFZGoo5GrZvwzUfQ1FOSkrPZkbFZDe35u9jsj5t8+bS8cU/ssfv8oo+IECNuJfmZIkRshCtTIlNisxLqkY3amryLi03ShFlTz88HRSXQRPBXq06Sr8Ugj+VqKxOtWOZVFVpHi/kRwrVfWoZyj5z3nbOx3Xm/zaTOJ/2GP3+UUiJAifHEvzskSFZCFan5iRISM2j2OtbV8Tr/AMjUk3l/78HwowqRivrZOb7dZqXThV+rXnR0KROrCmnWUyUU3KJXhyyzs4XqPo6iPjZkzbNsmb/G1+Oy7vzxP87H7iKJAiIRxH85IkIVkK1Ij4IvqnaLM7GZKlT6cNXX/h6WXWWTPSXnT6XUun9HUp6R1YSgueOtfKUOqVWo1qKladROpCdKDkpwwaqHS3m1OXLLQ1uem7MZkyZMmTJ8J2zd3b7aGM4l+dj92IokCIhGvX+QkSEKyFakQsjJFkBCZnZWfNU4hX+vPmwp9KcvEilreSn/ADuaNDWc70TcVxPrLSx5oUo/xo1dPDNPQ9fpcirIqrKkuuzhFflWR2ezIxMyIyRPkdl3mjiX5mP3tRIEReEcS/IyRIQrxtTIbIsgxbtXUbhxSajVkyqTJkIuZLTw1FLSaSKlShymv/JT6On9y+kSSiVJFVkyUf8ALNffJC6o0VXkKUuaAx2yZMjsngyfOcCZneum5iu/HE/zsfuxFEiR8Ij44j+YkSFsjamQ2wkRe59dXqqnPWSwL7py8zOHw53S0ycadJQSeHrYkKuDS/dFoqsqSJsmNffypEiHhlF4nw+pz0DI2ZMjdsnMZM7c9nylul44n+Zj/I/KKJEgIRxH8wyYhXj4KZSEhxGZIshITuzJxHNLUV5c1eo8KP2pdXNnBl9tOJ4UZwS1tWPPGdOUdFVal9TMajKrJMkTlyupWhgh5n5XnhM/tzkY7ZM3zfIrK+e9PxxP8zJfkflFEgREROI/mJExCFaNqRTInKSjZCeCMhSOayOPSUI+FjmJsf2QOAyTjTn0nNzlqaFTn1WjnJ/xOSVCkqZzdJyyqvnBUNQ7x8y9kaCT5YS54sYxjG7p2yJ9t2d2K0ziX5mT9/lFAgIiI4l+QkTEIQhWolJkDyNE4dbITEzJk/5BqPq6iTy39q8E5ZZw7VfxdTCplUnmeSdWnnUaqnKb1lM/nR54QyqvmSKhXeZK0fP+xw+aU9FPNJkmSY2ZMmTJkzsTtne7/Pw7z88R/IyXv8ookBESPQ4l+UZPzEVkK1IgUyJJEl1ktqNXWWn09X6lSLcYHNknPOzhNf62m6041NTUrEqGpmv4EoxlTp501CMD6nR+ZsrzwpiRIXtajPkloJZo/DJD7C6GRec2XeqeeJflZP3+SiQIiInEfyjJkRWREwUvMSlIgxnKOI7oRxjmrVdQl/1k/f42cI1P0NSnlTgpxnOVNT+pVFpmhx5U+g2VJlR8zn5iLqR9kIh54XqeSWRknZmbZMitkQr57CHswVDiX5WT9/lFEgIVuJfkJE/KFeNoECDKcxMdmjFlbitNxnX6UKkOSfkSyNdcWRwvX/yqUHlfRUj6MUTWCoypUJVCWZEl0n7Jn+kR+SLw6tLllpNR9eDHZ7FtV13pdTiX5WT9/lFEgRE7cQ9yRIQhWjamQERkQndjQ7yxJcV0f8WWp6yRCGJVPblVSMfLWHSqyoz4fxaGoI1Ok6r5q1Qq1RvNsE0VPPw/ERmOiKD+pQ0TdOvkdn2ULs/F3ZjkcS/KyXvaiQEK3EPYkTEIVlaBEXhMi8CkJ3dlbiGnWo01XOcffJ4JdXTlyyrRw31sng0HGKmZaiUipKozDY0YMEisuvwLz8Wp80YaD/JqmMfYVkKytm7F2JHEfyMn72okSPhW4l7kiYhWRG0SKI+EITMidndGv1Ko0a/3Tx903Z+faneEuSdL74KHNGdLBOBGBJEoleJJYF5ksNO+kmuTSZpkKinBj7CdkLtrpf58E/HEvysn7/JRICEuqOJ/kJE/KFZCtTIoQrZsmZHedRRjrtS9RKfVyXSQhlMd2aCfNSpEoFWJGlhVENFSnkcSUcNfcvDzaMsGhkvpw+yopZHd3V1ZMQu9W9eJflZP3tRKdonzxL8pImIVlZECIhXXSyd6k1Fa/WOu51XNSpOCnhL2sykOyJeeFv8AxpDXR00SjhVfPIShlVaPMpwwSpj6ji1ehV5ZNtqLyZMj3q6F2cC2VvXiX5WT9xFEpiEf7cT/ACDJiEIQrUyItq2cX1LUKND68JTxVk+lSTnLHKPwUvF31loftUOq+Eit0j7zcT6ZKnzjoZJaKJqOSL6ozbBQrPFN5p7ldCshW871tr+vEfdk/YRRKbEJi9uJ/kJFQjZEbwIi2I8bOMfm4hqYUaVMrp4lilZ29aQvJBZlpY/bp+seU5TV9I0KROHX2OVFSUKUdXr3VtgxsjOUCnraiKWohVHtV1ZCMmd/xsrenEfdlT2EUSPiN+J/kGVCIhC82gRFb5FsRx2g4y4h6Uf606hGHO5vqyCy6jtHz8aePXT+KC5acbV/vllompyOSRqOI06RWr1K8t6VubD09f6yutiFZWXcrfj4l7sqewiiQInwcT/IxkxCEIVoERMW1X19H+RQq/5NNp2muRctWp0S6YyP/GhIx1pQ+o9Po4opUYxS6EZCJYHiJqOL6ekarXVtV3YTcJRlzxuhbEKyYhbUPZV9OKe7KntakQInkS68T92MmIQhEbQIGNyuzVUlS1vo3PJCLqPkdQlJQPNo+J+1OThLT8TZDjGmP+20Q+M6RH/dqT1HGK83UrTqvv6KeVdCPiyE+9V9OKe7J+yMFIgIiI4n7kiZGyEIREgLseDUV/prW1/qVqr6v1j4nWY3m8X9s2K1T7mRjKblJRj23u00uWrsVlZCst2d1X14p7Mqe4ikQIiEcT/KyRMiIQhCIogLeiXRa/XOo5lX3qLBmy6vAkLx5dqf3qMHNykorufI9iIS543RkyIyIW3NlZbKvrxT3ZU9hFIh4iREcR92MmRFZCtAj4VsHz8o+UcQqfT0dGmqlWtP6lR5mVHlYFTxJrlmP1fRJX0Wjnra3FdNLS1e8h7dJLMNiFbJHero+bVfTin5WT9hFIiQFbifuxkyIrIQiBEQrLyK/Eaf1dFppE1kkxxKeUVJKUXLmMmRLZoddV4fW1Wqqayt3fiPh+dmlliptTshCYhOyshs+bZPJV9OK/kZP3EUiBAVuJ+4yoREIQhECBHYtlT01Ef49ScsPkwT+1ZHK6X6Ts/HiK2wfLLahCYhCFvT2VPx8U92VPa1IgQFbifuSKghCEK1MgIV0fKtq60KFLUyqV5ro5TUDllMl0MDIox+i7MZMW6lLmp7UKyFtWzF6n4+Ke7KnvakQIkbcU9iRMiIQhWgRREQ7RvLmZr6P1nxmUYSzyxpU+taQvubEsiX6OdnmT6y3ab8e5CYjxZWV1syVPTinuyp7iKJDxEXk4p5ZIqCFZCEQIEfK361xoanUOVatOS5nV5ST6esV1Ev0nsRGz26R9N8bJ2VlfNvN6npxT2ZU97USPiIrcT9iRMiKysiBAjd2V+MaxfXr86nLpaMcjzJxj+nkzf436XzvQhWTFZPfW9OJ+WT97USBEVuJ+7JExXQrQIdSIrMQrN9NLQ/m8Q4h92tl9yox5peIRj+wrPdpfbehCsjIrq/yaj14n5ZU9rUSBEjbifsxkyNlZWgUiIjAxCsyhVWhq62t9erTPx1l1MfsRFsd9J7WW5CsrKyYrZsjUevE/ZlT2tRIERCOKe7JEyNkIVoeYERdRklZWqvUSNZpXHX8Ugo6xvLqdSj1H+wj4Q7O+k9uwrrYr/CtX9eJ+zJ+1qJAiI+eKfkZImIQhCPmBApiWBkrKyK+nVWPFX/AOxrA30pr/G/2Ftd9J57KEIQrK2Nlb04p7MqewiiQERtxT3GVCIhCFaBTIWkStgVvji399o+V6P9hCGKzvpOyhCEKyFuq+nFfdlT2EUSDIitxT2ZIqERCEK0CmQYiRLzZCtxN51vwxP/ABv9hET5s76Xx2EKyuhWWyr6cV92T9rUSmREI4p7skTI2VoiKaIEPBIkKysvOsfNqCXmk/8AG/2ELwru+l9Ni2xuhWW6p6cV92T9naiUyB8nFPckTIisiNqZApuzGKyvVeZMmUpYb/YW13034+ytiEIW2p68W92VPZiKRAgIRxT2JFQQhCEIgRICY/EvKFetLloy8sfgzzRf66W13ofi2LYhCI3W+p68V9mT9mIpECPhW4mMZUI2QhCIECIt/EJcmhn5dpeab6Y+22DG3Bgx3Pp8ulW+j+LerKyvgWz5J+vFvZk/ZiKRAiREcSsyoREIQhECJAQx3VuMPl4fPyxkiD65/wAS6iX6lOPPPUfh30+kOyhCshMQrq1T14t7Mn7SEUSBEQjiCwMZMiIQhWgQIkRokKytx+eNLIYx2myEf1dHDrqfxbXaHr2UIyYsrLbU9eK+zJ+zEUSmIiI4p0GMqCEIRG0GUyJC0vKshH/IpdJDGMXslzS/Vow5KVf8W12h69lCEKystiJ+OK+zJ+z8FEgRFbivkZUIiEIjaBApiGSEIVv+QVObVDs7Q8DM/pUYc9Ur/iX6KEIVlZC2SOK+zJ+ztRICI24p5YyoIQrK0SBCzHZX4z/fbHZ2pr7HI8iRJmf0NFC1TrDZm0fPbQhWW+Rxb2ZP2dqRAiRtxS0ioRshCERKZEiMl5V3JRWu1P8AIrmLMp45uZswRiTmeRR/Q06xRKn4zmRzoyu+hWQtisiRxbyyfuIpECArcVtIqEbIQhECDIMQyVlbiCb0MoI5TqZtFfeYwTqGMijZvvRXM1HlTJeBRV3gzZdpCuhWXXbPxxXyyfurUiBAVuK2kTIWQhCIkSmRJD8oVuN150tJLJm7KMcJywNuQqYlgbG+/pFmvafqrsdorr2lsQjArfAmTOLeSfurUiCI+InxxW0ioRshCtAgQEPbx/VvnkzyYMsyRyodHdu2N2DBgxu0suWvfH3XdqX5OyhCEKy2IVp+eK+WT97USmIiI4naRUI2RGyIkSBHYrcV1C1GreTJlGUU488h4Zyn3GWc6OdGVvyZvkzbS0/q1b1Fird2o9anaQhWQhbp+eKDJ+9qJAiRPjiXgkTI2RGyREgQIjuivU+jRmx3wQjyR3YRyo5UcpymDBgwYMGDF9HLlr3qvNWzHbT/AJOyrIQhWVkZvPxxUZP3tRKZEjbingkTI3iIRAgQIDsrcaq/T0Uh3oxy3+snhxlzRdqnWrZjtp/ydpCEIQhXV6vjioyp7RtSKZEVuK+CRMiIQhCIIiRKdpCt/wAgq/cxjslyxf6+jnzUrVPyWY7ab8nZVlZWVldWqHFRk/YRSKZAVuKWZUEIQhCIESBE+JCtxipz65jtQjlv9jRT5atn1ld20vnsqysrIR421Dioyo/uEUSBC/FLMqERWQhESJEi7O+pn9SqxjIR5IP9iL5ZZyvGx30q6dlWQhCEIyLZM4qMn7MRSIEbI4p4GTIiEIQiJARGzEamf0tNIYykuab/AGtLLmoz9bu+nX+PtxsrK6Fb4qHFRk/diKRAiRtxTwMmREIQhESAiN0cXnyaCQxlBYizP7Ohl91TpTHZ3prEO0hbEKy2VDioyfuxFIgQEZOJ+GMmRsiIhESAhXRx+eKLGMxyxf7Wmly1q/4ruy69tCFZXVkK8zioyfvLyikU/EBW4n6sZUIishCIkBCujj0812MprNR/troV5ZpWd6KzU3LahXQrrzeZxUZU93akQ8QEI4p4GTIisiIiJAiIV+L1OfWsZQQ/3ObOns76Vff20Kyurq9TxxW1Xy7USJAiI4oMZUIivEREgIQrZK8/qVGSZSWKT/cpv7RjvpF07aFsQtqKnjingqe8hFEgQEI4l4YyZEQrIRFkCIr6+p9PRSJSMZPCe3PewYMGDG2n62d9OsU7K62oQhbELbV9eKeGT9mIokCFkcT8DJkbIQhECJEV+Mz5dFJ5b6FP7qrvm+P14+tneCxHarK6srqyur1fXinrLwusvkokCNl54lZlQVkIQiBHxEV+PVc1JdCTyaddXuyZ7+DG92dqa5p7FdC2oVlZHznZV9OKek/Efb/dFJECAhHE7MqEbIQhECBDZxOfPrJ9RlD1ZkzbBymP1orLHs0q/wAnYWxCFZbMbK34+KekyHt/+kSiQIkWI4p4dqhEVl5VoECPhWlLkjVlzORJ5KXSm7YOpzGb4MGN+TJk5mczMyPuPuMszan7Wd9JHp20IWxC2LrbUfi4p6y8Zw0hFIgREI4rZlQjZWQiBDxG+vn9PRTJWXSL2YMGTmOY5tmDBgwcpynKcpjfSHZ306xS7iFdCFsVq/4+KesvDX3/AAikQIiEcUsyoKyshESBEVuN1eXTyJHmQ9+DF8nMc5zHMZR0OnaprEXtisJ9xCurLdW/HxX1fiXn4RTIERW4n4JFQjdCtAgRFbjc86hkiHuPtYOU5TlOUwYt1Opys5DkRymLZPL20Y81TuoVkJ2TFtr/AI+K+pPy/CKZAgK3E/VjKhHYhECBEVp8OqaviD4NpEa7henhT5OStfJnu4MGNzvpqUq1eXB9WirpK9Ed9Ivv7quhWQttX04r6k/aXhFMgRFbifqxlQjZWVoESLFamPqamH26qP0qr2Ytkycxzfp8E4d9GmV/uK2mhMq6OKJ0nA0i6d1bULdV9eKehU9pCKTIkCNuJ+rGTI2VlaBEheKwvnUnE1jfgwcpi+TJzHMcxntcM038rWeBsrFbpTkipSjJRioLuoVlZCFtqyOJ/iKntLwikRIELcT9RkyIhWVoERCYurGaj14p6j2Z3YMGDBgwYMHU67/+P0OWiSKnU1PiftL17yFZWRiyRi81VlLV1edFT2n4RTIESNuJegyZEVkK0CNkUurqz5Y05fUjqfxa6X2rxuyZMmf0EnJ6Wh/H09OXMVT/AGq9ZPzL07qFdCFdbKlapVvP3l4RTIECFuJeg/EyIrIVoEWIRSWI6upyx4ZVfLrZyS1FN1lD13YMGL5MmTPb0n9uc3GnoKn1Cv4Xh9XLzL17yFZWVl2KntLwimRKZBi88S9R+JiEIQhESIiPnKxxGrg4VqObXcQ8Qh/8qn69rBgx3eGQ59fqny0uDVE3W6qrPkIx5ifu+ytqsrKyFZWWxlT3l4RTIESHW3EvQkTFdCtAiIRTeVr088If/wBTXTyqPXhVLxsyZM/p8Fj/AOnXS+zgJqJYnWnz1IVOWDeXJ576FdC7DtU9pWpECJTE+vE/UkSEKyFaBEVqBxSnk4L14jrYPGkX/np9jJkyZ7/BPyaqGIf8fpv6erniUPurVJcsSXfV1ZWV1djZUf3u0CBAiI4l6j8SEIVlaBEVqUsS4gunDZ/T4rqaMP4+ilCU4ed2DBjZkyZ7f/H6Km+J1vp0eGR+jw3UT5p6X1l90m/u7C3q6EI82WxzwPUJmKkz6cYjtBkCLIsicR9RkhCEK8CIhCZVUdTDVab6M58e59LzydRe3ZwYMd7hnEqWjoTqz4pqaklQoVp/b6089fnsLsKyFsxs+gjohk31bERIMiyMiEjiPgkSEIQrwIivjlNVQ+tCtQnSdKUYOooxr/tcC0v046yq5T9hvP6K2oVlubJTJKUjlYlISkQyQkRaINZ4j4JEhCEK8SIhXknF6mlGrFpZfSptyZM/paKh9fUVtUoxlLneen6S2rfzNnJk5TkFRI0SNEjRI0hUkVK9KkVtTKraRMjZCdkRIiEK9Smqka3CpKGs006E9uDH6fD68KNaprdPUlRkqqfcW9C2q2NiiKnkjRI0RURURUkcmCtradJVdVUq2dpEyNkK8SIhWQr/APIIbs/rUIclFj3YMdtCstyd40SNAjSFTFA5UVtfSpFbVVK2zNpExbURIiIi2I47HOl24MfqaeH1Ko9+ewtiFZC3ZtGiKmKBjlVbiVOmVtVVru+TBizKgrqyERYhCd1bjCzof2uHQ+9j/TVkIzZblAlimq3FqcCvqquoFs87WTEKyshEREDIro4ms6B/taOHJQ7i3qy2IwLbqOLwiVdRUrO+TzvZMQhCuiImK0TN9f8A0n+zCPPLGEP9JWQrKy252Z2Y3SJiuhWREQhCujW/03+zw+HNWH+guwhWV/Iti7TJCuhCYiIhC2InBVIavh9bTfs8Phy0R9/HaX6jJkbq6EJi2IV9XoqVWrPhKJ8OqxJaarEax+pRjyUn+mrq6/UYyQrq6EIQtidkVvKRKCZOiidMnQgyWngOjgcWreO7TjzTHZ2e5dlbUIxZfpSJiuroQroVkIRVWYRtJE4k4EokkSMczo6SLP8ArdNMlwPSyKnAIlTg1aJPh+oiPT1UOnNGL8rZDTVaj02gdOYx99blZC/VZParIQhWV0IR5UbMkTRNEkSRpYc2qguitIkSRKKJRQ4o5Ecpg00Lsf6C7C7We2yYtyEJido7FZE+lRDJEkTRJE0cOhzauN5EiRIkPZBcsLv9BWVlsV1ZbF2XdkxC2oQhWQrIV64rMkSJEzhMP8isyRIkSJDvTjzVB7n3VZbl2GLsysxkhbkIQhCsttVZpp2ZIkSJnC4/4lZkiRIkSHfTRHZ7H3sd1d13kS3oQhWQhCYhCsvtdpEiRI0EcaZWZIkyTJEh3pR5aQx/ortebK2Rdx3kSFuV1ZCshCvX+2onaSJImTNOuWkrSJEiTJDvFc0nuffW5XW1dx3ZIQtiEIQrKyEIV9Uswg8iH4mTJEeghkiRJkmSHfSxzNjs7sfbVl+27sluVlZMXUW1XmuaFMQyZMis1UIZJkmSZJjY76aOKY7Mf6asrIVvj9B3ZIW9WQjIjIhbfWaG+k2TZQ66hWkSZJkmSY7siuWI+zjuIWxdj47bsxkhXWxXVlZCFsre8WZ6VCcjSddUhEiTJMkxsd6a5qjs7Pa+4rL9l3ZIW9CsrKy3Vl1h4+KqKqNC/wD1JiJsmyTGx7NKs1XZ7GOz7SsrLatisv0GMkLsIVkIV1sqkDJPqVkaLpq4nxUZNkmPYzRrY7P9dbfmy7zGSstyFZWRm62T9X0eSTKrNO8amBLxUZJjHdjNIv8AE7uzs++tisrLcu47skK63K6shbX4SyPoTJR6JYqR6E/FQkPYxmm/A7u7763oX6b8jGSF2VsQrLbFkxxy6iwl1qokyaJ9BuysxlH8NnsY/wD+FnssZKy7ashC2vo2Mqs5sVOYciciq7qzGUfxbX+qt+Rd92ZLety2IQrIceZImyoxrJp6nPTZJlR9VZDGM0ks0bsdn312FfNvgXfZLuoWxCFaBy9ahy5OQovlnkqHJkaEIYxmlly1LvY+8u/Hvse1dhWWxXgS81SMSRIhL6kWhrCYrO/gjLnjZ3ffXZX6rJC7istiFaBIqox0mSNJaQxWd2aWX22Y7u77SF2Vd3XfZLuoyK6EK0D4mhkiRppcteceVsmiBgY7MoS5at3ZjH3ELtr9Nj7yEJisrx9kTGSJHh9KkOUqRIIY7u2crY7veuyrratme8yXdVkJismIyf7xKgyQxo0cs05ImQXWRIdnbTyzSGOzs/0FsW1bEj//xAAoEQABAwMEAgICAwEAAAAAAAABAAIwEBEgAzFAUBIhQVEEExQiMkL/2gAIAQMBAT8ByPTjI4kq/QhHAI4ml+gCOAyPRBHAZGPyXkr8UYjIwlyJwDuIEcBkYCa2waeGEcBkaDIlNb5JulZeAWpp4A8II4CUorTFm0CK1NP6qOEMRKaNP9VZE2VnHdWWo35qDwQjgJ7NQ29IpzSUxtk9vqreCEcBIasZ6ugEauXjQcEI4CQ0KZ/hWoESinPtUcAI4CQ1/Hf/AMrdeKN6OTt6jgBHARlGrTY3TXX9hedLpyO9RwAjgJDgx5amuDvdSnVCHAOAkOOgfdqlPbUIThHARnLS3qUQjpo0BnCOAjOBppDAkN3T9W+2F010oxEZxCa9i/Y37R1mp2ufhE3zEgRwEZPBZIEcBGcgjvE2QI4CM80I4CM8IRhHAc0RhHARlHgtjCOAjPCEYRwEZ4QjCPQiMYiIznARjERO2manThHAROmanTjERPndOMRE6UUdOOYKOqJAjK7gOqJBM+dqdUSCZ87U6rZAjK7fgOq2QIynhtkCMh6AIoRv24YlCKEb+G2USu34bZRK1ostVs7NG49o/j/ScwhNlCMup/mZjblCj9pzG3dALV2m0BV05jYnelrbTaA9Ie6OnMbN0/4Wr7E2ibNTdqP25Ys4J1/mZhLv6oousiZ7K0YNkXBydvLpOACOp9cG8zt+tdK3oHyt6Ai6/S74RY4RjodI+qFqOmEdML+Ov0uX63fS8TW3RaR91Kt7RqanomGxqUN8DR3SNNxQoYGj+k0jQoYGjt+k0t6FNqaHpWb0KZQ1dt0o3oUyhq/phRtDQp/TN2RQ9YFPHTChQKNDQ9KNqFDF/St2qMX8P//EACYRAAEDBAMBAAICAwAAAAAAAAEAAjAQESBAAzFQIRITQVEiMmH/2gAIAQIBAT8BKHmGMBEeCUIm0I8AoRCtlbeKGByCKGFsLL8CixW1TichkatZdAWwLNQ4nJqIza29b4ObplDA5NNChhZAJzrJ3IvyKY/Bw0jicwUUMG05Dc0KBTH/AN1cNI4mUUI/yV0BdXA6V0x1SNE4mAYCt3I9/UEHAJ7rphq7ROJkbVz/AOEcAgaFHQKGBhBV6Nq7/ZXoSggmtqdByGBkFedv8oKysKNQ6q7QchgYwhUi4siC0r7SyahU6BQwMjTg9gcnAj5UIVKdoDAyNGPMPlLoJjqlGcoTtGXL1UIFDkQo4TlCcZcpwDSekzit3hZObaUoYGNuJTmOX63IcTk3hH8oC2ZEjkMDG0aL5ChgYghkf+Jo+fYnSFDAxjdKGBiCGkYyhgYhpujKGBiCCGi7uMoYGMIaLu4yhgYxpO7jKGB3T3GUMDEO5xgYziYm9zOTcDGcTEzuZyZOcTFxidk5xMTOpTRk5xOuaMqZChK3ucplTIUMDDxzuTKukM3HO5Nq6QoSs60G1fIUJRpukKGBgb3qGQoI1MHH3pmUoI1MHHpulKEjOtN8pxMBcVxunfyWPxDm/tB4Kd3KUMDCzuZxsEUE2cSs7m5TUTiQJk3L2jQTiRqaLTPH1O7o3bHxCZ1h9QQGhdXkHxCXkBJX46FlZWpeNnW/dXlZ1K7wGSu8BrrL9wQeDGfBf3QFB5QeV+9ftC/NquKk+E+oV8x4R6qEekMR4h7oEUMW+I+pyHiPoE7EeK7qgTsR4pq7FvkOxb5BxHkDyzQI4t8U91OLdP8A/8QAPBAAAQICBwUFBwQCAgMBAAAAAQACEUADECAhMDFxEkFRYYEiMlBSYAQTYnKCkaEjQrHBM9GS4VNj8PH/2gAIAQEABj8CbonYXT0e3qjhdPR7eqOF09Hs0K6DC+n0ezQr6RhdPR7Oq+kYX0+j29UdBhdPR7eqOgwhp6PZ1R0wuno9vVdMLp4BvJX6bILMhdp7z1V5vjkVDZdDeo0bwY+EjqvpGEZ6+88FCOyFvVyg6q6qIJC2af8A5BbTSHDl4OOq+kYRnYb0b4k71l91us764tMWb2oUjMv48GC+nC6Y8cXidw4olx1KusBtW6ztXlh7wQe0xB8FCGmF9M2STki52S2RcLOSvUQQbXuHHsuy5eChDTCGmGMeK92Mm56rZC51ZLurKCzRuXJcrMQoOzb4I1dKhgDSa7MLslHei6oGAV4s5Ww79h7yuy8DYvpwhpMwXwjJQUKhbiLlC17txvb4GxfSMLpMuHV3+lHeUao47eau8CYvpwhpMFBh7z6hbi9wC/TEVFsV26NXKNocRn4E1dKxbGkwfKz+U4jLJBRqvWYWdXZzUSStqk/KuhVGFseU5+BdENKxb6S5cnwP6lI4gf2aim1bQB+6vQiar0XZp/umB72iJccgnfqlzeMIRUM8AHgm7/AeiGlQQtiXDNwTqX9l4o9N5RdUKh/aOzRvfAbROQgr4w5rtVOZtbLnb1Bm0OiiNmOiiRWbWzuz/wB+AjRDSsW26S72t71M8t6f/BGiZ+xoaFAZNQbUUOCZ2XAtEMtyhBx4qDRAAZVDAMKhVHymPRD7eADqh8uF0l3cKNjvynuO8xKv1Uawu0Tosocqoq/JRjaiiQLzY1uQ+XwAdU35fAXN/wDKBD73/hPI43KCjWDWdpEBHZc06Ii1Ers31moDp4A3qm/LUMAaS7aTy3jVRNfOpw3tqgg5j+zvChCK8uGartwio8Z9nVM+WsW2y/um3toRF2pUAua2jWHHum41Rq2tttyi1ty3hBrYmKieFg2gOMQoz7FR/LhN0ln0p/aPuU6kN9/aPNGF5NoRN7eyUSg1tG8ahd0KNLSQ0UAPuowRFqFnUz7Uz5ahgDSWZQAwAG2efBezQ3xPW3snu0lygUOShmoQhVdbJs+6dk7uz7Uz5cJuksz2gZAbLuXAp9BvbS7Q0Kvt7Lj+o3PnXlixQLbo3jVX96eCZ8uE0y3Hktpv+NwhohpU4HdVz3qFQewwIQa7sv4Yv5rLX5tG03mEWcDCeamfLglM0l3sO9bJzFyK6VclGw2ipe1wcslfhxqD93Hgo84zzUz5ahgMlyUXKNjSw13A4BtuY7LNCkHVAxjOtTflqGA3SWJJACiI7H7Vsr8YLdFBZWtk5iqFmC2NzrwuBnGpvy1CyKxpKxNyLQYUTc/iK2ybh+VA9858lHoLHVGwBgcCu2IK5X52L8lzF4KjONTdKghbZpK7Ld52R/ZW0YiiGXxIPFwZ3VtON35K/pc8AYWS2WX868qtlyB3GcbqmfLULcU3SVLfKA37lChZ3o/YIuzIEdEyMIkbRvXNRO/FiaoDLfVtPIaOJRZRdln5Nu5xC7UHBQFx4GaCZ8tQwGaSrqTc9kPsVQkcPyqeEO7CPVbe/cFtOyFiGFkuAXBQo/1HfgLapHR/rCiF8QmeqZpUMBmkq5nVbB71DHqnMc6Db3w4mCbE5XqAW1VDfYghcsrO2+DRz3KFH+q7lku06DfKMsUOCDhvmAmaVDAZLe0Ubsnt2hV/AUdyuyUG/eztNN6ax7BnmF2hSNOi77/+Cu94fpWzRUDifidBfplrQN4CjSPc88zIFnWYbqqPQ1DAZpKwaIuKdB0d0VCrkoCxpYD/ADfzvqgM1sMMY953H/qSb9pgKj0NQQtt0lIpzGHZ87v6UYQHBDmhaNj3fG9uqgP/AMWwzLefN/1KB3GXCo9KghbbKUzuDCmMd3P8j9P/AL+UXu3mNQqhXDeoWPdsMN8eCaCbn3whC8bzKkcJcJmlQQts0lKZo3sK9od/6xCqAUEYQPJZQIUbfvaKEcoFGlpTfuhkJWHGXCZ8tQQts0lCqSi57PRQQG8qNV8uLYPCYo9KghbZpKF7zABe/eNkPvGigBev5W0bgoBRlwoW2nlLBM0qCFtkn2QqKjLiTSON/BoVFQs/azILVRpOjeKhv4cFDwDrLBUelQQtslKKmf3WscE6kpLidyuvWy3PeVALWYjgOlmqj0qCFtkp7vdRX9Six4LYblpVyGfgLpZqo6ghbZKU73ftcfuqQjIotqA43lR8AOks1M61BC2yU9sY4w7f4Rfs7ActagPATpLNTOtQwGaScKNrfqKojSHb2zAmF0U5oya0fwoLa4qPgLtJYJnWoYDZTmLxqqQafwr0EPAXS7KghbZpK03zKNQ08BdLBM0qCFtkrTn4zW3TwF0uyoIW2StKeLjXp4CdZdlQQtslSa4cfAesvR1BC2yUpHcGmzHwASwTKhgUcpTn4LLgoy4PExwGywVHUMCjlKTmQPzOBvFfbAbpL0elQQt0fWUY3i+0BLF3RHAEvR6VBC3RylA3U2RLtCdgDSWCo9Kghbo5QN8rZtoqdPBUfWoIW2SlL0/i0JVz+lTtLYl+io6ghbZJlxuAzT6TzGzfLM0qdpPdFR1BC2yTp9nPYsX1Cu6SA4oDhUZ7oqOoYDJODLts7JPJbrO0ZVv3rOluEuFR1DAZJj2YC4do2hESrftYNpusuxUdQwKOTe5uQ7Is8hXcaspEcr7DhztNl26qiqFsqjknvP7Wk2oW8llVvWZWazwRzusO1tCXaqKoYFHJbPnMLO0d0vFB3Gt2toS4VHUMBklRUfAbVmExDy1u1tdJdqZhMkqT4ezY2uEzDzVnW0ZdqZUMCjknv8zibAEyCNyjxwCZdqZUMBkjSv4MNjSbHK5HSeamVDAZI0nxQFiPGbc3qnaW26S7UyoYDJGiZxdGwBNt+yM81UdQwKORY3gysToPG02YamVi3RyNJy7NZM7R2tBMNTKxbZIRO5Of5jGsTsLTjMNTKxbZrIUzvhhYh4GJmjrFtmshDzOFYnhaAmaKuHA22yFHReURrJ8DA5zPRUVbtbbZClPAwrJ8D0meio6inW2Y5dwvRJ331jwNxmeio9a4wztsx6U8oeAm0JnoqPU4TMdtH5nR+1Yls1nigcJnoqPXCZrjtb5W1jwNomuio8JmuPSupYiiu2SN6/xk9VFjCDqgJ1rGCLjku606OXboniwdJoKiwmayRujtXaTvv6Qdt+XIV3tC7KjuTjNNVHhMkgec41p7o7RtXiKgBCaaFRVDAZrIxnXUx/eYWGid24n+kxhLS5vlqCFtmshGoibDRmbkyi8osmc7b3OrGAzXGjVSUe8GI0qpXbqMbR+83Q/OKqT5v6qJqKM8ELUU3XGAR7JhyQowCAWmr2x28n+ITdCOcaqdu8OiiEAtpFGeCFtmuPkh8rkf9L2xvCP8TZf5RV7SfiArKjPhC2zGKJaSCr8yxwq9tZ8H+5ukGiiSqak3OfloiiNwUPAAhbZjlUR4u2fug7Z7RGZVNRx7TmC7pN0j3Rguio/lj96nP41Cd7ILledlc0KxYbrj53LaZEIMpKI7fEG4oUjTsnMQ3IzT6N4dtE5hMomXNJQoxuuR53IBFRnO2S5XCoIW2648WjVRaoELZpWFzOWY0VIGGLY3Gbf7Q9sI3N0WajuHgPFcLORqF6bIbTeoRc1FhRmmtOWZUB4DcFecHiVDJvCRgtsHadwG5MLxD3gjCa7ZgCIRRGQG/ii4NgI3eEXdoo3wErQu1E41vLwLKrKrs9sq83cBLsPB821vPwPNRc4QUGdsrtG7hYuV8o7k4Tbn8BDwKLiAOKhRgv5rtuu4TdNpH8zY+K/wHZohtHiV23E2b5in+SaDRvUB4/TfIZra8o9AOYcnCCy22eYTJd5j6CMWC+9dlzgri0ruHorxCUY3l6Caelm9gW8K51d+K1vE+gzyvwQOKvXaomq4Pbo5dind1CuewruR0K/xuXdd9rGRUAz7oPpHC7cPRlEPixS7p6FP3wByBOKB6FaemBSO5QxAPQx5X4DjxdiF3T0PDhbZzvxGjr6HjxtsHLDDePoiPAyRPAeiHDlaYOYxI8T6Oo9cQDh6OZhtHP0V0st64ceA9FBQsN64bz09H0Z54ep9FFGw088Nvo9vzDDZp6PaeBw2aeizZEcxdhQ8t3oso2IccLZ3O9I7WDEIO4+kHjrhFvD0gOdy5YI53eijaio8cIHj6Qhwuwhyu8F//8QAKRAAAgICAQQCAgMBAQEBAAAAAAERIRAxQSBRYXGBoZGxMMHw0eFA8f/aAAgBAQABPyFvyf2J+JGo8lZSEFZxRafJd/Cjw0YJYLeKY8VEVdnJEiRZIoQkJUbNEKRKB9hGsOBOHZPjCw0aZsUIGpwyROGQJQxKETgv+DmBycQPEYQkdJoSYtmuKyakYiDlEFLY6CcbIbIHjSKOXKH1UPQ3k6iYaChbeuK1mLpDQLiRP0dkREi2I8MSvHAlB4HgkJKl0PY0NCNEeCMJY35CdCUlPkVsggSteMMfYcGx1wTY7JgokUkEXZHYgas08NsHcnBTY5KRTAli8jgtCSk8ijhFPQxpnc/SPqrBiLENRYvQsQjtNk9jl8RZx1DCNBZEhIWg9+4tpqqFbw1RCE3yKMK0R2FPI7DwioFgZGGyCCPGFskbo0K6GrKIyk4Z3MhMhvY4HqhWvJFl3g6D/vD2Il+cOuCUjyVhqFse0aZDRaQmharMVt5LXCMHrFOTnHVC19BoU3N8kEIqhJUKIdJEymDgZQVhYEI2Qoy1qhK0LkqS1mMaY5eRK3JoIEsiyEQIQJVRF4bJdWJMTxyQ2xI2HsSNsexaHsTNxHEDVmkygnZMkSIldky4HC+SC4Kbx/4g1GFvBC6IiELeD9E0NTcexCFDywqLhLXogmiEKksUN0xinHGNDkuEc5OD2NQqFrDOaLNEWSK8xUC7bIwa+CTZBzoksLkdNeRpHqTY3GD0Na8jVUJSrHQoIF5KVwOhOVQ3DHyRU6IFo9bw+gat/mjQe5N4cB86hx+DR6D5w3FEhWbGuGyEIo0ToTSw5CW9H/A8JQX6IkY02JnPDDbKDQ1cnBFDw5BQEhIZMCRZyPZ3FBJycD0aGaYsigpHbK/IxtHIrGR2NLyNL+yYSsY/tYko3jnDN28D/S7Gp+sWDVG6EJylin5KMWjfFPBcELBQzf7N43sXOSRDSljRlzKSCixtY5I/RCYgliUHJv2xBs7DjEWIhMLBvgR12IhG8OSIWE5RGHooh7HA0IaPnDgcmrJme6EjYmNh2mJR5JlZQg0ss08x/tdsW+ot5FxqElGcoxjw3KdDsKioQkpE9DoonoknsehBJF9shbolYgmEJiGiCwxEKTjFsix1YoNaG2QaaE8vbG+MQ2hO5RpScIaoSQ1PoaPA9jvZTFNbICUCRsRQ55EGo9YdsOaIxWnCF/Q6MQtGhwEgRoDNTc4iw2NzkSh4EIJ0aJYpzWFbuRB2hCOfBEJGhsi9HOKZ5xqRxiCidxK/JwRA3TFoltjWH7wvcDWIewlGJs2x0IOh0PQn2MlJ3Y0qDYxSHItvwckGmQzaGoNQU0baIL5HlzCR8ZofoOOGuK6NM0THn1UeyxtihBYJDQh2iRTZFEpLQsDSPQkIOU7B4jcMVEZoOh7Dj2ULfYLZKqF7s2qr7O/yTxeU29NFS/TQ4U6WgjqKScYaw4bQx0bxI0QtkHBA/wCDFQtlrH4HpFUVDiCNeBdxyO4YSbSc2yaE5kaDsUrGqOcR3xawnGGok/AWi8CwokNMCSbIx6K+sZzyUUw3w4IoXA5IhxAlaFkK0JvgSdxUkXfgcSM7AtYGuwsQNqQUg8fp1sbciaQ6n9j0iITqSsfNMlsVhpcia+IcKRr5F8ciQ+OR6w1PBVBrRzrDUwyJJvybGTiBI0NYyYUoILgTLIN+yR05NBVh6OB3QTiU/Q0axsp68gvYcMNDQ1WKqPs+sUEyVGDSb4JaKognwSEjajgVxQnmxSQ9HohxGKOHOzkZCFupSGsnclt3Efk/IRdINW79EFI2VIuv9SQbdBzw5F3C+yx+4Y/bae27EVhKx79DIlGw7xoT8EDonNGNSQWiVHI0opC3MjkiZY5P88kGc+CLNScRAhRJqxDI5R9Fmn0FoggIIbRdDQkNx4E4bQtX3mNzjtisjyLDCPIlHIOkfIWuR5RBz8lN44Gu54MK2CI8Ek3/AP6vBt7uXclYdS5+Rz9jc7IZo4UGumhJC5Pw7Ht2M8MkRBwL+/YrWlKaxJCHMtCcjQkQMSxPEFkRcFobliSodJYlOCWixAl2O/5JIG5IxJcaJwxMSfXf6FDrlIpZqKKxbCQsagPHZCiNsEvEClZF0Mdox6kqgmRjSsjL0NxQLklsZRH6IXsh47j9iH6HtJs4cYuRpo0u9CR/AT0zMCrQ7Yr5uxJIVG6aRHc1hFYdoSojg1pCqyxoQ4GRKFHBoxawekaF5HpiHKdE8DxA+RkWSbk+u/0fW5PH0djsxfRsWHc591gs6UJFWN2w7DVSLXsakGuCBEiTk+CB7GJyS+nCGzsvtwO5b2d5PJiNyxbtFFzXY/8AKGzeXyM/Qku1Y48v9MazC0yGrJKzU2RehOBpJkZOFNk0NjaSsmscIHRwRUeBqB6w8OsMVkLDp4PZJEyhiGHSgv8AJ+hqeo2Fx9CHllWLQgqP9fkk0xQQlm2CGgaLHKCWmmI2dCy7C2aE5svZBBoQyUEo5nSfLJJ72l8tl6eEOUI/yAgTUxJ0oGsCuwrwFLUI7neQ6ZT2RhqyxUqSf2IQ2TbTQyLbJ/A8LJHZPo3sbJNtY5GbWJ8Dtj4HFCUYPRyIjk5mBqyTajkSP2DT5Rmpo9E19EmpwnB1KXghgGhcy6AQ8PEyFYhMiFingNCZaKUxDHyI2Q7xUt9iYXhTsM3S9s/EIujWhAOAsDbJBC2iymfjQ55EwJyaFBR+BCkf144NI5JpnI2MbKJvQihMImLNBw9CW/wcY2PgaRHk0a9jUaGvHI6RA8fdZRQajUcPQmT2wsGphobYLp+w8R4KkWEhip8DoO3QWQtIa8R20IkGl/3r+zGyNssv7ILv2xbCCVBscig7hI8SxiJtKGMTaZoWCfDGWqb7/wBK+RJej0QOzbDfYk0yHS9iVZUcJcjJhEXJ+2NnrDjD+zaRyJYlpxhjYaDo/dEp6Gop4eh7EwIbx4NJtCJR6Z0LI2wWfbG4tjqRcWyaY5jyiglBpDdD2OkaO6mlS8vR5Chvcbb+f0WTyLV7/TIqvJtZWGoWDakZj5JFN83olQfETW5d0hvG3tPaJvIalDwnB4DtPsxEt1R4f5mwi8HIYrGyRf0NyTRFilMY1RMIdngKsGuSbhPGhBHBYyQc+CIKHslSdkzWNcUhsPWKHIW34RbwYNDbFFMN8ahJQ7TL9kHY7ESiSoOB6w3BsfYa7gy/hX0Tubk0bFtPbID2NIJJZL2JtXyQdpIxuO5jkRpx7FCco8oRAWh4E70yILE6LgUDfB6E5fkcg32nj/X8DTDnHfDeCltYYmCiKKSZE+BuYZ5ORyfkIg5OR0bKTnGphi1JYaGLT55zoOcGmWuENQ8KPMuhszxCdj4WVwJylDJv+ikTIiYbGwU/UxSXd8IdRXl5cfgX9E4LpDVJ1xQ/0SsvIrQj9JNBh+x2zLlSOfGyIxF2pLSJB1K9PCNYImnjp2EJH7oSm1BPaNvsNWJxgr98Hk1aHWoRBpI3G9m0IbIvAcB2GJ+Z3TsKwmpbORoJngTnFW8OjdCcEwSbsmKH+zTzgv8AvvEaY1MGmLZ4p+U39jNDfMt4MhEJNBIpYriWh6GguwbIG0j34v2//P2Rq9vKR/Y/0PzAtzyNHjgq57MerKmN6ITzgbMSk272PTBfo+SGp5XrAgDSVmF4FSaPwJdMj4b/ACHOQS8iUVOxSxGY8C2fsTdMh2tq+tJ+hQocY5MEyTDL/wDRsKkbEe4272Kw94wNCG3JtEQiJ9DWyBmxHbsNpkQ0NlHsx2hdBhCUsNRAtdDm+ZCEzuLsQciFieRKx9kPRwQaiQX6T+Bq6Vuwltew7seGvhWax2NR3z2G3bWyYjZSttRxQikgF2DTBiphHKiSDEjN3YmNmSQEQI6LPgSR3o4OK0/JT/onczUn6GaFRuTSh3jQ79hq2JwsJPNkwFswSLmylJKWjnwc4ogbsdoczJI2owtxo2zaPqj6I0w0aGy6h4Rb4EoyGaG+KQkLLcWUTDgmyItvQtl0E4tCZwaG2MpT0C8/+P2PUHNhtiE8LEzPMfI2xtCoFqUuyivIi0hNPwKliLKBkhEZSIsrJizZEgSABRwNReUxYn2V71K3kRflwn2q/wCD5HAmnB0ENng7BQw4E9xOhMTsSWhHGFI3Z7NWWN6DQaHGVqx49Y+lNTV6NWC0LUnsLR2I512Ho1NsWFvDCTcSRjdogZ+4oWcpJUlaEyUMdgqNKSbd3QEalMU5y+fYv6Ru9iRr8iXEkqVDidkDpY8gSQlO8ykW90nRr53YJsWvRInJpDbbl8jQg9Hkah2Q7b5dEEnkYQbGNhuxuJPEmRMkzyJ2MJ3RPsUhK2ImXJHYbJeh7FOzdkDoihKcB9PnNOLUWUDlXJSRfQGaG2dxFDZuIXGGEcCy6GMa7Eyfc3ZsRjUzk50/sl/gBTqdHGvgWjkNyycNn7EIJK8sZuGnoUHhbkTPUS1SvGqFHZpCWFIRdGOcLSbaFpNfyFr+kRy8Jw0Gg09j4ZG4JCRadsMyJwhWQJicKcN8G+cJoS5FlQayYmMDc8TU0+hk2FGa4NLPqPGxv/BkiLFEoaK1xgaqDybjogjZoyrIh3oDzD193bGUW2EvN4PgsSE/3yJlTFeANNvQzrV76H1h92pFuCuCVEJWeYZsVOKIENR9QEEovHN/Zr4Hs1J+UWAcowNnwNoNLEfIoKVMnRPYlMu2TFkiJg8CtjRoRoKjWFBJ4EM+6z7j9mprOAhUakcCBR7Go7B7N8jQWWeBjZDTAk4ZExrgS0LexcDUW7qZL8C/J4OTaU39v+j6sAmZtjm6IpZ/8GKtN6IQHtBL9iDCVzI0Gu0J1t+WGEVTPwBeeGbN8CWlNaPOI97QtPdnyPkcngw2PZ3GJ4mTuCDChOhu5PwJ2SOxTNjdDExrTxIkh1Iv2n+DyaYHARohMHvwaC2h4teRFBMh7wTEGx2kqEgiEIbCa+FFycr9H+RNiU1GlF7EllPI3EjkjKktiz74F7Y40ehXz9GMpU9WPJY2BBu8VsQh03Cw1d7L+2Xl3EiTSOxaLSc0QLrJbh+BTXmcyPsrRREuzQ0obuNw6FIYcm4whYhQcCGpRykJZQ5O2zZsbfI/1+cNRxNjUc4iwhUuthIQ2NxqLCpIQzfwO6O2awWmNIno+h6aZ+B78Mem03w/9KK0W2vQ6Y0Me44EVopYhHG/7CENtpG6FtoWi2iofYRBdCBNkw67myFiXDG2mQi8WhbHz+ktoFyIlyjuOKTjtEkjCKExaGsT5Ey0SJxFieODzhcsTgdzhllyPL1Z/l8mpoOGDUJJVbLI7iPmk89+jrY2NjQSEOVk+2TcyeTbBRi8iYthJNS5KbmJXftfYiciJV/ECW0yOFwaIPtFMKOHsJs3qCTQzu/TJBLnbn0RSITsKi2TykOYaz9+PCN9EW2uHQcqbQwt2caThJT19oclI+GGMYmJwPQtCyKxCFsXJxY3DSJJEYdiyKhqosb2NLDqah7Qs2pDYvIWPa/Yxjboix2UaHUDUxSt7JIRQOXY0KmKmI0RcEJVK8MWHQv1IRPSpkl3NbNk3+yhnuFjxnlHLGNKcNG+R1yfJHRt5Fn9DkERZjoKQ4tpjx4OhufJWhuafKPQyZpNOXnwx27hBvSKLFuOB4eETkpGNTnBaEEySDOU4mDbINEDsovkLGZD3nVqMDKkxLg1vDH1FYQW877sEIBP3KDgbjCGuRmbeo7jQrl7+Rwi50StxpitlG8FRdlejUjx4kGJDApE7EiImeiFYIPRkrwNA9IfkPQrEYdMnLtQ69KYTx3ENgPvgxjcEicCyJ5EJ44EJkicY7nYJsalehvQf2F+7oIHoLBZEpKSbx0beIGrD6VKzcSBPCBZE4ggJsnLLBbwrAFLb0kNr5KR1K7wNAnFtiEjXoOJ+h5OPmhLeIwmHdBJlhTHZHSusE7OfyPX/wC4hhOp++BoEJGSGWmnCiB5pQmX+iDagp5t4IkcRPsQVLA0iCwtCY1OdioWjgobE/Mf4vJpgPgWfwEknQcz6K1ixTnDdDm2sNiGgKxkHnDW6K5eFygwcI9uyImNWf0CSGkDsvyyInDReg1+xycBIh4PSCJpkuyGH3eF2rCtE3U8jKeA4pjFboZVWO7KJx6I9NavXkU7U5IC7xh5G8ITkQwhYMJiJzR6EWydsaE/If4/OUmWEwTkSisQLYT8gefXDTGopLGhriYELg2WEIQnw5ntH6RjmRyXTeYl+NiYS1ThPuTM0mtjBkoSpJwURyKQPJtfZonHKKnkvCpWFhvkSkdDpZ2ld+4lGmiWZyJ1vgvQnyMk9pMjsF4FpcQm/wCxSH/gzgeGayTFg9iZYphWhMSvKPJo7ySKPoihLuw/2ectysdiA7hFfknPhECXZNsFgti2JG4tDk8ZkoEwnhTP9DNzdv8AK3/RoTQjsJr+zkqa8AspoaGW9L8Cqar+pDjk+iEn0hi+ZjqEXgJcll5GpfRTYgoGp3EqommbyQmy58FGkhoVIRofM/8AMIa7dRb+uZBpPIpli/lMGc4WqNhbEVEMOKgrUSRJIiTuKgrZomRclvcLnU9rJUXF+hJ/ZoeQyxsUz1C2cm5rj2ENvDYoYkUTEJtH5SL6kVLuO+9ZE4BO96OvaIJZJUSuPL8jGt73ljH5vgfhcfbOHpEr7ETJRfY6iSmCRc9iGItSNrRs8IjxRCONm+5AraREy5d/+7kkAfhceiHiCCCMcjwmUxpq0ylbS2Lv5G8J0MIT5LKLRQ4E8itZKXjZtnJNSRBCY0cGhD77IcrBiyNS1JidbEyTfNqbF0LZuexReS7HoS5GoWxOBbKaUIVlWajK8lH0LSQobhgkOGmdnsQtNLRcbmkJ/LwPRfn4G5okFApSEPd2UpBnNLQ2B23fyRW9EKRDU4QmJPifn/wbR8T/APobxBBGUh3WGxsezaE6Ckl4nCghMVnaxBUKLbGGIWzZQYmhiF/IfbZLsLFaRqJwKD7H1sKrC+GmRGxoWgUlJkSI4o0QjfwJO+aYjZUvu5tfsSVD/wDwjeP8MkbXbJEV7+4r5V+A3IkVL7L/AIQstRImwEGXZ0U0fQ2oXtpzj8M//QH6XxGtZ3YEB76KX3UnzYiJf8Cwu42NjxI3FMrBriSFAQmPgQiZIsWz1i+h7wgP9Dua43AWBtDqiiNj7weDGgjQY3Gkqzc2kSNMWVsXgm3sYmIqX9k+dPf2W/gUoLpCwl7H0fwGFxcjGsRyWe9iSvCFFPcd0NZf+Pn5LFFctwOUBofVf5P8jQsMY8ePO3ziROxYKs6GpOEk8idbwmISIcTzA6dY+2f7nc0yDYqIawe3Rztk0Ni+UlCEI3ByIQsHT20tiTMvjXZ615Y/Jlqm2/YljqH4KR+xtEiQlBxZM2b75FuEhCzc2/4PnX4Pmi26Sd32H2WW+n/x4fn+Vv8Atkx4aGeFkiwmMKwuwYQc7ZE/ApYkawRpqBLBqXsdHo++fa/s0LFA2ENUnaJDNBWmvs8NRMEFoezwEbD6YqxQNlOAzfAraCRB2/8AgLXYvzJpfIbu0kfb3lE2WoF9i4c456X0Ug2xMQsKk5EoTAUFjkkjiT8jmf5lzi+HmZef7xwIVYOJiDCsTxI32xtjTND7HktZ06Dk3Ya8apQSZtJ3Z951MWs6dypxHehDSNhE6wkljtuYXtWUS94vehsEvbLH+cqScJInJV2zEqNNBuSzPHfc7gkRi8mEtLQuA3pEp7L+RsbFy84GnB59ewbwmInEmbD4GnnDOHBZYExoSjkhzsnhnNpic4OKLo2RsPUH2w82w2XYahhKEli/ZOh7HYmc4ZaeIG9saCqZSicW345Yo2Xc0QnOX/Y2ThDHVmRkSIzH8rDY0FI2Yx58opwicJ4PgbpS1hNwK3ogZ2okjkjg1eumaLZxPoXzSPaGaG3RKiiE75dR2ReCwKz7zrb7LyQDyUJ3DRCFTJxK29uWOiRaQibYKCfwRT2cohH/AMDEjHENCQWhjHhYkJicokkTGwVDDicYTODSBVo9iEaXUHhhCilYgYWj6bGadUmE9Y1I9BCgrlnYLYmNUhN8tkm/bbfY9pYl9JL8E9yfadnHYQ1U3N7H7EGy8QShrljpa3x4J3/xDoNkjFQMS1l4Q8x7MIWE6EIbITCbgaTQ0lobOWG2tivoMdMFjbCgujUxPjiD9vJtnRbI9nAsEsbNNi4FbEKiWBOEe0zsUluFwbI278Iv7e3g8oe2yalvkJIgI/kfQ3g5JxWQvPQeEUXlMWYEIQwmUCY1CZqThQExW8EYYvtDTFdhbNi8JFrBamB6Y4bHhvlWCERuaC1sSk0bCYgqODU9TVT/APIV+BofITda/YV/skQ++Lnv+iBEZj+J9DY8LhjFou4lCjGxjzqeELE5QhxhxPAkEvgkJ7kiZxWHoePcfSZp0VSsWpFxC2eHhob4qhYXF4K4NKNGNULaEsglGImidDXOnPyifwiUimleSoRW4KB7iSUk27CYR/M8sYyBrG6xRC0MfRU4g1mRsNxOMbPBCs8hYkNyjR6OZCpwqaCQjsfVeXfBYcYzk2OwdDbMnBdR+R1pXv8AL/o1KyCaT3A6UqP+BNofZQflX+CiH/K8PDGPqNsdL+A0hiELDneJjEjSTCKhhC5FNCUL/jzitMJcCxscDU2R3XLLbBcdAQoWDgKgtvwQMRZD1KGW15av0JWxG4JGq8eTWgAZCpRRHzWKH2VP854YxsfQ8ZgKOLB4uR0T0LYmLBOEIsKxUJmhAtkPQfg/sX4cBrjpaFvDcQ2gVISl8M0w3NcK4cRDcslDPIRbuJLKNi1lCy2qLjsjmSRhKYT1CCr/AIEiPBEzU31pJzOZwxjY+l4bZpG3k8fVXRGFsSELRZYPAwmPoKymEeDQU9bNSnRpJzcnwpD6sWLCVk0xW0pELorQkiEGkWyJDRHxD6QqG1snkU9IYbJxJJJJJJJPRI2N/wAPqJ0v6DeKzyITGHw1wTNi6JsTuzuaRJ/h7PsjToY2s2KNo+u8NMiUJg4jc1KBpG4KBMTwoTgwdwxmYGGySSSSSSSSSSSSRsbw+l5NjjpfeQsoTFlqwQwhaEhj1EnJ5HomhoSh9VmmM0UbG6NzU0PqYaG4kiGFkkZUcKksdjUng2OTQeVX9nJUSw7sWxvE9c5nD/hUC/wieUYQhhUIoWEMJzlY1H1WaH3TUI2NiIl8DsfWOTToiwoJmw1CNPkV6Lo3OwgSSBOL7WeRG2bC8niVMWPMkkkkk4kkn+LY8CHk8IC2LKE8pSLArYkRjDCAtG/ZDtnBrPoM0PsGoQ2Rpg0wI53Js+GPYxsObC48TYezXFldhlkIcThN74LM3/o1Y3GmUPzEHiCCCCMR/M7fAuoivsYkLqIYYbBCXY8hcUiORLvjwSfQZ9dmh9g4YqKUCwJ04LNvDNjU3EFnvkbDtJoexdhUhMVI9iF+az3soPjElgbEskEEEdAaGP8Ahci3hFljORfwYSyhCNMKLQtCcbJiBSNxCNMTnCvpZ9Jmh90aIHHkQ1g8juRb8h47dYzWeZaBSTRViOMY/JCui0XIvZQUTyy7DGY6GMY/4WqOQqTJUk4C6GPCQPDpSgV40WOQZQkuKjD2x9Ycj09H3hpmepCDUeJHllRSQnaXhqb5kxcWGmF8G+KRTQrPY3+EzfoEwyJdlEalkQPpnEjH/Fc+KCfmQuh5fRRvoXYWVg8CCsIUSySoWNfo+6NMS6wao7D1KYKmReXhZGwuGhQp0ikDaVscbiaNsIP8Khp6As+wn2+5SGPM9TGP+CibiX7En1iyxvDgp6QuhMT6HjCAgjsFQ1ivoX9TE/KND7GAjjn3OJ8H4yHil4JiliC9Ci+RKNUOblPQgyEQPxr5djsax4zDTEifexKZY2TfWx/wdqZl+sfTwZrDQxKaNV2F0JiEbIEkrg2StnoIcmzk19P7PqjXGSgumktGx5fQtcikcUTjTFaR9jcU6GFveJW94fgKSwZoM2eoFaRLY74lUWEQPLGP+D9YIEhPuEKBsbSGGfaIvKwhYTEJ1g2CY4hCeGmJGq9j6LNBT0Cx4nDBXB/aO+gIYaeg9kFBm9nGCgaqF4EhxMCW7ITr7Euy4HfI2Q/WCeGrHpqhM9nKxCpEt8UQN5Yx/wAKY3Mhn2Aho2eAn8DgYqaJJI8iWF0Ji9ZJFlGwpELCaLI1+Z9Fmg/5R6wb4yO4VNH9ozQ2xWDjM7sYNkvA40MYRsIV8rNHLcjVabQ0vMj7A44Jkd2R2RBJZwBM5GOsiw2P+FqXbQIS6SMPpMbbhIS3ZoggGPOSNdSwQWxLWD0IRyEhVhD/AOPJf0s0xbYeB6JIf9iwvBTTHApk3Isq4O4paIMLcs2wjP8AphobnIcHDooZ6C7WXr0L0T+cMx2xIgRIQJDY2P8Ai9fnBnD7hIsruR7GwaJF7qNFYnCfQlghCLCMTLkYkXATUYnte6gSPkHrESHnMsyOAmOmGosLlBWSHoeypHYzgSgRoi0zu3o9i+BxtY4acEG1ODdjOCdTRHoeBqcmQNEdIQQRlDr0/wBsMiWOKOE2hKMPBn0WeSMQK6F0DHtgh4EJE4eBaF/IXb4ZoOHOWiNR4aNJHlfIeiyNMUNgsOQsLGVFtsfByuw0i7CmlUzulyOH3LNI+QY2JsR5K9jS9mNe3O8oJOSTkolFdyiV3JRAgSiUNBoSNgNJX4eIiyeSfKkRsWELQkRhZdhLJ2CcCckUhEyLaNfVmmInYsK8jUQHwdiKR7O/QlkW8l6OImig9iciexFGX1BI7Z7DGj1Eq5cjfRI2NnD8YXv/ACR7/lgN+4n3Eu5LuS7nvjAgg8NxvGg9gh5GfSeI6FlYIWxMiwiSED4LCg+5J+l5RK+g0E8C2fsZOcRCGw2LG449DqIHRZifEQSMrX8dv9Dy8Gix/Cae8G+hkEfyvDlJtOUIUaRPBj0KED6D979YRvCFokkQsjdA3EcRhwIX8LNvDJS5ERw1OIj7I30psbjHeWENYtNtDStwJybyLvyTT9jfNf10S20krZHdo3VPU/4Gs3vbR8DGLjPoE/BuiMLCxsKsVGKosecEoJYncVFl8jb3f6NBZUSOBuWWDqYFZ+8ZplQToLYPZUfkUwR4LBPhZmSra094MaNEjY/5mMeLXpI+R4eV3YYx5Jf4EujkWsLJWILFGmGwnIkLGnzN/d/o0wUxhsUs2FehK5NfZjNegLob2WQlkNon84o7H+eB9A7gcjdEEfzsY8N2JpEqk0kjcG+wrseTx8m6EITzogJ4yKPKymOTYtoqBORaP7z97/RpldB7GlG6FP4GpH3WM1zSwsyrGs3OBuPRqyzGo8oz6wbCF7WY4yScSNk/zseYxyW35C0MeDERK+7b6NYWsrCIVBCLGtYLyRHGzYjyiEjY/tNPf+shsaG5VF/RqI+4xmuFukr5qmox4QLu+3/wa80oTkP/AJWPPsC6EjeDERLsguhCExCOM8yIQxITk2EJQM/YzT3/AKNMfc1x1E4xQ+/hpnWRc10hTUb0MY8q34r/ANHw7ULwBQMM0SSST/Ox9Ez4b+w8eWF94Y8GLJLvQlx2wsbwhCy2wVjioSwX0WNCYJk/exP2NcfRk0YPUHEI/IbLHL+AffBx4JlD1hE75vy//MXPRLHGNk5n/wCB9LNk1tCV3NPDweIl5npXUSwYQpJRZ2s5Sw8CSJRB+5m3+8GhocxFjTIWPmwvBsNRGmxmhzw2EbnYbG+FMJdiPg1yUvmk+FjUmfx4vD/+R9Nb2bX4GPB4kd9RwLoWCEYQJTyMbIPQnH2Wf6+B6NvrEsNVhIZwPa+8EyIJCwTBfJqKM8U7FmNbcn5MfF7pYxJP/wAFYooohdyPI0PD3202x5Hj5QlnYljgXVcWxbF3GLCeFYhO59o+7/Q9Dwvk2wMJKw5C2uxveZsPRzNMGg2VHvFRCCZYgd0fNG88DnrQ3ZLvQ0kdlYQNMuSf5lkul4HlYDHgxHuUvKTlpyskyJQLaWPQvhIl1jQf7+h6HUG+5qw1Y6YRMY/YDefQRbqC2HBPcRdtb8WOCo9QrNR+yXhI8I/klEolEolDaGxjwsI8DG8GI8PJLKwmQx8hPFUKqwU+CYwUFiOwizwj9Av+vGJVbZLk2oEKsXo7xKsXPxI99FTsQ3y0Lob8ngSIgR7X9v8A/CCSx7nryguNMaGiyclfxQyGQyGS74tIY8qlg8vOyCxHQSyRjYliiH4wS/JUTCXsLciRvMqDeIF8SUNB5HBn7x5NBLDboFsFo7nBf9Q/ihpFBfcYo2QlZCY1GG5DxL6JxKKKKIRBBD7DGhvwNjIFY2GPEk+yRixx0IoST2FZbBlzl+8K1homCfY8B99mgoTML5w2w13gb7PsvB66ItExQWsshobEMNK2+Bm9PL5KIlC/CnBjFBBKzY1g8UEEF4nCZPIynuN4fqShZZ+BjwYj5jHQhKxIQierKzQjvkZPjC0RQj+A9mz/ADZ97+hcO6W0JTjuPQ48stKG/fGmRYLDgNGBqJxeduP5oYeRoSBdlgyShyGyJITiMCUyiCBAiRIEcYiUgY2MYxabB4PHvN9CwsJiIORRhsIdqHgwghaOw1Y3/wCbzgpOKRww2w1xYuvd9HxEXQsWJyaGxZ6wiauZ6/8ATHkohUPI9YPMkkDLLTRLJkxYYYJwQu5A+BPlDGhpjGQE+xhseEpIM4QMaF1sQssHwJRECsQiSTkWf9cn2gshID194bjjlSbPuh5EELWDiOHQ+T/BsvPf3j1hBBD6q64ZEPCAnci72z2DXux+Y57jYVC7joYx49yYggQunY0KhZULibkowWhOxWiRA+6/0PWHSaYPWNzUG1g1yIWhYNeFDQeiaKhUzOgpj2G56XAx8oGMbxgViCOuiEQIECFmfI8GMmGGEFko44+tldCZ3bpSIT6YEsELCpsQriBNImdo+gx/zf0PQw0GomPE1Hs+2w1NMEWFgtmg3BIskmy6Cd09Ca1Fs/JOfrBjIGLJInmlFEEEMgjrYxjxBVaj/wBSyIto2CZtz4HDshbJoRd40stCwhCGcmxGizEhIWxFhRdsxeP2D7rGajVDEjx4DUKx18rGNTlgsVjGHA0gVDxC/Nm7UUTu0o9DJzHSsNFkifQIkpkdDGPC1afxq4FSEPSGLb5dEzjwKaiEcSYWYysQJCy0JEEqwopGkkRApk5ThjfaPWBqyOQSGEfdDNDYtlSNxFxCqJhYERCHgeJx9uJkmsHicJJzHUeZMkR0DGPEPrgel/6IeFgTd8lH9C1ZGXhbOcoWEKekLwLeEYKCEpsreaUdhzqjKVA9DA2ReX6xpoWpPsRmhtkQ05bmgjYQVPa4RX9NSO6eCd/vQ8qMeGiC+kpX8TGMYxbMsgvIhFxpsRLw4KIbmAic+EXd3EthFPoWEhKxHGEwQnBYphYl2GhEyTDFSPwBNwvwRER9D0fdLqaG5tRcsTwV9kY42OGC6bQs0wFulwPtV703/owqRV3+2Ikvv6Gp6GPMEdAhkvpSeljGPH+j3JB3Gej+oRqRb8AnD5Fj2n1sTlHAiRERlCyIkhFjxksIeHob84+A2LEKLtwGn3h66J06w/Asi1JCgLdG/usJlANP8iJOJcX+l/6DUGMkT6YIHkQQQLLwxjx4I+uxfwD0twIdk1/4RAh+UoLwyqO7KJH2GPKPPUgWCwWCyI0F4E5GqGNjVgtgPY7HG0FtISMTTDcQmWKCeR+RrJ+doQd0QyR8M+hQDrl5/wAp/wAGDH0qE4jqjpY2MeJ/CV8knwETf+MjWd4HP7Jj0OEPF+RnzhMVHbCwtiIFlUaFbKYIQsSRI8HrCaghhtDjWILfmw2TYWjUcRwyp+RU3LY9O4PgnHWgehxm5vyNfCafoP0QQR1NK6m8MY+iT8Riba1Qg+3TXCmyvbuCanTfspA1S7ujYY+tQQLZYhG4mLH0bkGwnh52cDYxQSIHoJj2cLGsYa6J/INV0w0FjB7jVI4rRBeSVwhzpn4Gh92cxsIkk88lJMqOB9EdQnoc5YxjHmvgcU44E2OxfduX3YmLNrt5Hg/JUdkO3liEycoypwmOI7ZHjgXoLC4kVKSRSy3A4hz40cKXstjYnfczUIgYwRRTYsj09sKrFayWEI0y1kgscU2aLSexurHNcPuiSWqiGvoJxEtMYTbHuf4Y6BBBBHQx4eb/ABSRKgUU+a4XLHlUsJ3EUO8tHyJxIrHwNLzDJJyiRYSLZAlhKhYoQYWoFQhBaONCVinlp5YoIq8DPlwIXsKAxveDwSKW5ExSY6cXOGjx1ybCOegKxG9DwXIhiZbHhBp8oU2A7TR5G/rRH338y4OP5IIIy8MYx55HMZlt/JjElQhsnV1DRCWhjIxxhaEhCEjkQskLCeDnrDYqQsNLbv2IQvSt4G0sSxejwhV6RDbRAFKaHEBp938DKEzUqh58mohUMCZn5TfwtrlDXE6YrTe5F/AJJ/geGPpQkV/CKdcKIHxt1yPWkTlsQzghHJwJieFlZoTFAoxXkQmJyhVj/uBtabwKOkJ2MfB4TwlAhK5/GBXSu0jz46QWFwmbDlsUPATKGBqb5Gy43wuPZP0Q22ri+mOoknrYx9LE/iYENi9QR5GEufODo2sM4JysRzksTiMGwiIsQgtluBVjwOHcDwl9oQuCbgUIpOkRKPbWi3XNIa7lKEamuCw2EJjyPRcrRNkp8FisSrt/1vpnCcQR1vDw+pHcpW9vJGUh4UxOFhCIF1BCFsgThEkiKfJ4B/CIRC7TPieSBNul3JRdoNtYI5ZI2OTSXS0ISuRZH0Md7PthQdvAx/gyUx9EZI/hYxjGPp8rW9DwY76JweESKBCNunTGmexCENEvgXoRxA3uS6LWAk5ZNJ2LwmPDauKaEpsjD4pJN7/CKRjXKmJjCwYoGGKBORcjSLZ7UfsY+iSf42MY+qRjsPbyMeUQRlEciysKxKDTYhFgrQcTgmLRwNY+EZtU7ZwPp58EMHL4KQxJ6JXtkPZ/CFRyPeOeGmCwTyNQxpsgnY/YmhVSw9UT6P8A4jGPqWzU7FjQ8RhrK6CysI0xoLsIRPkXISEQLHA5f4RD85Tiaz5HDiRoEoUaQlzh4eOmZsFsQ2VFCffBU/ZKnyIt7GL/AIJ6nhjH1P2R4EiNCUIeDRHShOsoQsLCWXbgnRoIURJcGjQgWILyJN7oiiMFSJ+8voK6NPDTFsHG4NjFsMZBBHTBHS8MY+q1KpvljWDy+laFlYTwhQI12ELYmJYJPJyIL8EyskEwW0JWhL+So30oeixthXYmYEbGxmP6Y3bb8K5/PYj+CCOljw+vvr9CGqwddDQ0OsLoWEEiBIgVECUCrGhIjbFYlQoiJIY/QtC3h4nLw3joMIWCYhjUqGsTFwajCwheBkz4SSh/R+/Fn2y0bN35DNz2UfxPDGPpR42UoMeHhk5Sx5zAhC3ksFbJwWhUIVbJJlYdkWLHceFlnGGprgqE80x4ZEQbBOyTSrAt4L+SENCS0OcH4TaH4OEvQxv9hHZmOtpofkXs2QPLH1eLBfY32GG6G6S30NE4QhbknoITE6LEBMsd2jsLHBq+vjLG6Jwas0MTImXwcQmPgmNOG2JDTkpPARY1PdSQkrPsaVvzBuh8whMD1MkvmU0bFAb/APEbBXyGy4f4IIFrO+Bdan4E+xddz2OhcnQxmyMQKjkjKwQkLECCVEChwLZyJYbEPcHOFhk9DeGb4J0JiE8ExhxsEOLRyMNYxsT5oeKe1QngnBJx0NemT/FkfQOYpzgdkdsPsIghijvUGPBEcDGx2scECLEuhFiYRwImBKhU8kosWyYNi4JNOcpw9HK6GMfQEIgQhmVJuC45GFonsLBYJ4rDYJ0hEw/2R/YlCHyNjoxxsWMZ47QybGjYQ2M4zeVicaFhsQTo7jaJxoJWOsHY0UUQN0WOccm31nWRsFhCY2DDZOKBpwTE7Ehiah2aCC7FE2SdgmFGgww42xhx47VTLHg1Y9Dsex4eMxhIWVWEh8WH4FVYmRaOBoYqJsQmITDkSOZ6VgtDGuZMWV0JxjuE2aCp+BMTEeYYKcE6NH/rJYocYYbY2DDx+qYPZoSMe8no945EIRGUhIQgSgW8RBGENi34J8DNBLDZxmeq6FrGmKELCEy3QEPWLYGGGFe9Fh+UCeEFxU+aPyeTjRmHGGwzvQ1L5HyaDDQ5GPDQ8M4ynOU8FhCRfcRF4RoWqwRQascmsThDGJ0cZN9CWVmhPCcGoTGGGE6F2PRLJPyLJIUPGq/rCaGG3Y5uHHG8eXkYMbsaw2IMY940NyITN5WFhIkK89zJcSxOSiJJrWIRRYjKFiR9CSaxfIhZMNXQy2J5GGELZCrsqggvYcsElx3oWixYYY3YmGHj/CzeR7KD0Mtgxk4YusgniYQnQtCEbEhIfBXLELGxiGcCeOcThhjzoQmLJMahMsGDCEIWCEzzINiZGMvmD92Z+qomwz5lDweRjdjsbvo3lCIFlMWEWMSiQhAghpESQoQ3QsNvECY8cCtZRI+grCOBCzYcWBYGEJ2JiImXmB8TfhojqLQ0dNA/Q8Pkh4cjGMYxk4NZTIEK8oWFFhG3GCdkkucJ0WQxMIZA8aZIzTxOKwSsi6CJGEJjCxVDDDCYmJiQ78zgfpHhvB8C2/o1wfo9uYwljyvgeDPAY0PY7ZA56UbINYWEYLQsIWVRxhORVhnOOcIiOiTbDY+ZMQnhCwYWCfAxvBMTE6ExEyeRJoyxsGIqPH6Ymrpymyz2IeDwY0PCzH1lrCJwQwsWIQllUk2JBNkEh8WLeOcLCHicveTm+CELZNCeFkQwzGExYITJEpvMEEn5EFwRkUMb/NwPJroAPiMvoQxj3ko9D2Nj60xEYQjYqFvD8CbjRY0jYlE4T0YnRcLJ4lE4bwzjD3jTKskLoMLCYGwTFghMTLv4Hv4ZLHOfFkWUiCN7wPgiBN4XX3cGPJh4PD6F0oQsLebEY7wjKoiMJHvMGih10bDGMb4LJZVCwkkfFsFQmJiL+oTEJoxxrkzxQr+xQ3aNbG2ObF0CR5Zf30j+hmgx2PoehZ5JFaJyWjjC2PeHthOBIkWFZEKSLF0vobDToSwsIWExicLImMIQjgilZMmAWD3/AGDQTLE4mYsIrMseiPoNjyMY9E44FhWQQJYWhYVCEKtkIkTgRxsgSIEo0ck9LTOCYWXsYw2CyWUzsLYhMTNBOhsidCEIpvhyi5TCvCV/Y+waIaxqxCDpZvrRjGPY9jDagY4GPWJGIQhiFhIQhHOGhaRAkQaJTRteFag1mScN3h4byeRPoROSExMTGEITGGwTNCJradDSpIMDWLg5BdbIuSQJCEJ0OC5MwxnBTBlhjYxquvYhMkaRC2JybQrwsJ0ItRFsTE489DEPoeGPIhCELCwmSITrBhWIT6Ai3yY4I4FgvHE27s+RzQwmaWRCWJGZC3aI+R7GMbLeDQx55yhYXAsUWLeFCETDEJScCWjkQ6KE10MmCRjxOGPKhYQ2FhCwsZjBCEMLHP2xICFAkE1a2ISm+V5JXhN2JmxocuticoQg0kjGON5MYx9CdGlhMkUCyRIrEsLDQQ/gRzJvMVicTiRvE5Y+iLCESLCE7EycJLCoQlkXB/cTkl4FDJaYdqF/slMSnY9jnGLGITu85XpjH0jjNFiehYWIwYViExeMJSNiwlsRYXkVG2Hvp5HmScPFhMXSsoQoGEmCFhY7BG79siR3hIQuPj8jYLb6EkjYkjhmeHgmBj3g2MNeDHhYZwIXQoJULC0IThYSxqhjZFyhMSOTfW9YkkY86EIQsITwiSRYNgaxMYQho9pZG4+ZypNq0JocEk0a7CYI2KKNZOnK2rFDdJIxsYyg7H0uOhOEhCE1nyOBdCLwhoaE6gXLuaJxOHhvoY8yESIWVhCYhhDYGE4WBpEFTfA9YPgpUe1RA5QsrCShMHgyBdzDnBqJsSxiDGc9EiZN5QnAhPFIYsEaJJGJoToWyw//2gAMAwEAAgADAAAAEL84YTC+jQ/trWmuMKmUZcQw9gxuglOJK4T5/QfYwcMHCOXqzk7j1JVRiG6nprvhgrxnDNMBZKQPEIIHXzXH4ZDDHXoFzwt1mtZbNskK1PYYKQMLODIQEK57Uz2wGNIKFGNKABEtK98P+lXVZBRolLYi/iXGPc/6U07wS2AC6pvMCdKDLDEBBiU6hwVWScHRo5/yLjaRCP78P8nGLJjIM8N36+CsnqpqppKZG310Ae0cMj9OM0OJi+9xfGCxRGV54aLwDZh6xNrpgcnjyAysXOy6XeAlqIvtQDL8uNaFJKHut3670+DEiiljsnaTJfO07aPdzVTNwPl+f2y/huySnNGpgxGOIvj09AfXluhcWebJw6YD/l/MQXTuw+y0JBm2LYOexjChFFPgw4HMp/hkWa24syMfNwnaeF9J+KWTfaUt+t29g88K2gHJNLB8OVz1oxQX3sT8SN/mfIDtvNl/G+d54Y39/wCvlC52+rQiiEwXAGFkqimfUPXhNccRIglr3vKpxZv4VCn7WTDDFWMgHOuRFUBdbhE2dfjBQpJNUh4Hja/Usbg4ynTHWOutjH+kIic8rGHpHQXO3Nu9DQvO9G2mclLKzTaTQxdYPkYFyF5qfjxdoXWoG6D0DpttO4RO++9NkQPS6JhCwH90z1PrNBjlx51DHtgOARSgCSgL+zQRvcvjhP4SjMdSqQ82i8A4N9fPMW9kyeeEo1znogTudsg4ToOaFD5miCTm7GSMyGqKohicTKevFx8ZkmX2hUhi+VEyIDd4817fF68yE1Ygw9Yn5Bjjt69tMlIsurXRWhQiBR1QvVZIsHUp7m7sa9L6xiLcoWB9bAQgyAEaNuUIUegORKbEy836ZS2wy5koNVQL5Xeplw5+zQSgwgsuxx/Y+1EWEMSn1yT2p7ecBjU6DRePWniO5NMvCxSAzgyyxOaVqaehbqTzMvUg0YpfVUCUDDMnKg3FdDi/ShwhDCygSpIXaE8eer081dMgT9qrcF1DyDQCW6lZpSDBzhoyRgTjhisXmVSWnPsSW07kXjlqKMVExlCzSdr3hiD4JJYJCAQahiTfjidrVQdLABqBkmBi5/MkUymzAAtUKBr5bbKpYRw7CzxD5M8j/wD9j2WqEsJptQaDXjFItkE2nOeOu8yW6OM48es488+LlOnxjPniuUm9k8xOmXlZO9jEdBRW6U8wCI40YUa+0wg/SfqFAPruIWBxpAUReWP1sYD3E4BSpEEgA4UA02Oi8wkE/YXelgq/+tcCBp9Yf+q3ZJY7nkZmVYdEEQwUMOiKUwUU8XMzKZonOasEbNtoc7evJBtgWTtQZl8kk4wwkMyeoUMnoIPH3Y1c+DOxuuZRI4jQ+rJhE/nDYy8IcsEIcYgAAaWw284/5JOj8zqX8wK9NIE/VKXTBM3Tk2ScAUkQQsIoQAc+L3IYX8JIpU/6mkpyIraMXcaLXAc1T7UUgwoUAkEAs0qWmAFcsj0B67ujK0o2I1lAw/BKTV0wTrL9daI2gUQ0QYUMcVPFYglIbopLewI8WE9NMozpnH5YYL3bBvUueME4EQgc0wJPwkAOMTGfEHtchty9J5oa1lRdC0iC3U4qe0WowQM80csqO8sg1/vOXo+YkhcBtZw1z5f3hcsrL3R2q+eI8MYU4kU0EG6oC+3wmJAgcksm9B9ctPx1ptcss/1T2WI4QE4kAYIAUod3Eag/o2vAA4wlsgRgFpFdxdtmUyvQYui44Q0kgQwIsAU7cgSb3BKbczWsZJOhS/n7jFjRCoQawKqKcwQk0goMU4kcoHUGn1WtXYvO+Bqyp2VDPVV7dckpjOmuIUsMM408cMQ0EIks7DvUIYwHSeI6fZ+SaRlMPdm7DqB6usMMAY4goUIUgkgogqUJWxuU3q6a23RCinrdRjR+uEwA2aoYQgoYsYoA0M8wcOP2ziRjEbL+oeWVyd1bJ5NcOl7AYwSWww4YQsEQ0goYE0MN+z6JvQjqwqX/AFbUR07XBUCubOrM49jAKOBGMjlllMNcHC3rbk24Drr0ic8RXcg63JXApRstGsdAGBkLFCDOLPL3etALwdh2C10iok17P85v/jBaPrIkbSjWIKCPDgjqgMLuwUMOD2SI1H0MhIlzOkttJER+X66bP0CTTMOgqiinroDG7xoBal1adSL6rmEM+7sBcE8d3u68K/Lf0bADILDDlqDGD/3jdD/+GSHl6uASP40FpCW+S6i1SA9msU1MFNuuIGEIFJ7QWks7zlQD7+Efti+9DrO3ax8kyaK5j86LBCAEMoqsIJN4lIrq7ZjXIhyDuptxyGmSOl0yknGl4mjP8GEEHFKJuDJDzAPkiUhu1D+zk5tA5yM5cJO86ObS86PooiMHNGstsNCOmx1lirVtuaGtxxs144y4iIuK7Gb+1240kmaBHIiIprGNKr8otj+UjV7274x3zzzxQrNbU/DS1yr2KQiMGGZFMLhPJArft4hUTo8IjiI4502OwtdL+004wV4lcUTjTCI83ll+3O2dMUWunQG9Xz18nti00yvYczyC1pUh1+DvpPC0M/kdIZkcPXd8m6ejxNj52pik/wAZpiFGgCGKe7f/AIpcINIZCju2kTFFfb3zN0s7+SrruC3ubbHZxAID+wyTB3Fe2mnkBfEQtrYT/hwi2HEB3sDzvLHfTL3N5VMSZyYmjYsh6dKrY9Ume/owsyggzT741Hw3XjjjDbf1r6Mm6xYRFpJA9yG2aP2BKtBf5cCpiXn4ml70rT/fjX/RbWOmjfdYN/Zu240KSMDKfpUeDtN3BDjTA+Pv2nJB5FvfNhiG6dJi5zPGRfQk6W8SEFe97a1F7hdT/UIJZI59VNFQBUN5WCB5R3XWszR/8qGM8+68rCLtqrx1rjhIG3ukNpZQ91dH5MNJYRTUisuLzTiAdAIZWwa8zmvhtHPw9TNLkFavFAPyKfZeOtXsIprdSpD/AAoFCuEteY+ZK7Z5y9xeGZQTrpXaqgpgY9JQxwC8Z2cMT26dQ4Ls5wqq9mff0w9xQaHUk69XGPPCgQfQY/wP433/AGL12H+N5z9wKL8KCN1/32MN52GN/wAAcice/8QAIBEBAQACAgMBAQEBAAAAAAAAAQAQESAxITBBQFFhcf/aAAgBAwEBPxAmIwd4EZeG/Q/nMRg7wIzojbmfvO2BHCR+Rv074hntMRwamGG3y3E5cn4Qw3aYjgGTG4Yc7l1JILAfTu3w3z7SRntMdxlROEwW7dqke7du3q/vD4/H2wM9pwZ7w4S3gYbVLeW3kz8eG7ed2/V3wM9piDJ3OCcBxOvEHbBo8kmsFuLfoJjjvHbAz2mIwzJBLLleLyvOFtxEXc6w9Mek4ue0xntMRwcLw7X2ABbyeIebuLVsfd2nwwWw5mDjvPbAnHaYjDlnLOAQ2yKXmW3vxL2tiJNRLJy1gy27d2ycdpiOGpJM9ZmB2QfLt5tFrxix7lpjr0kcu3A3ab7HJLVq/m/2/i8wka9zvd/q8F5yJDBdPRq1lycRu0x3HDfBlu3jS7SbRr1EM9S0XlgT3hwcNzgyTmMN2mI4MNvgOFIQEhV/s6T3mL+iHeTgZIzvIYbtMRwTiYL7JK+Oo7SX4SR8Q8uVq68wwxxMDPab7HBw5d1jsxoUPNqN5JNeGGWm8TnvDwbfI7THcehfC/7Pmb5F94wLaTsQdY+T6SJibWQz2m+xGXDhJtvmO2/iMO9EeZIzan8fA4CLZ4cnAw8TGe0xHJwN3V3LqJA+bW8OETpldJVteQy2bweneYz2nBnfBxNv+YJj+Qf2XfpXzB7r7dpvscmcgwuNN+ZjsepacHpLtgTN2m+xzeF9ww+k4jjtN9ji4btuXUvvJ+MntO032OTO+ie/xdcnqDPab7GHgz/kvN4fh6epMhhu032MuWZeZd/h68Dk5DPab7GXg3aPwF1wcTDzjub7GW1hnxP4S6Hr7zE47TfYw27eG6T7jpyXSMnIu0xntN9jluXl7htu2SOo9DjtgTjtN9jDlx19w0XfJHp3jtMZ7TfY5MvnuPBwkcy1wMZ7TfY5M9vt7cZyLWNZ7TwO5vscmXbv29sdM9vcGTub7GdZWj3js3dc9/aYydzfY4JheNe9eNXznv6Hh2mJwdzfY5Lz71p4R55EW5z2wJwdzfY5PfvDpu3rmN47YE4O5vsYct5P4F3npHtCcHct9jLh6H8ZHgjgc+2RwdzHcYcrX4w28j1BwdzfYw5fnX4x5yZPQYnB3N9jDl7/ABj99vacODub7GHJgpGGw95bL/ZdvdMnAy5+MCZjub7GHGtuo/hdk+3VkPk9Q2uR6AcCcHcx3lwNzQXj7Zb9t0y/Lo8z0icHc4InANM3TUPaLVvLtfZAL71wO5wcFD2kbPaXkG3NrfifT1ufMnA7m+xhmHTuWlaHUe/YWu+bxNEcRdvreHlxN9jDl3shDfcNI9vd/Lbo8CPVvWG7UGG+4OL7o8weOJ69wMHBvsQ8Cbv7Rt5nA5a1nWW+xHLt7T43xPxN9iORzcb8rtCTXfqGjifgYm+4OezW1A9k35fFL7GS6k4h2WoGHv0HJ9T6tSJwLywBgSEktv6iOBnQvAKxkstHp1HvcHp1DkfO5iZTL5+lvsenwam6X3MTLC3+k4PStIwsPuFN4G/1N9iPQ9GOo+LpHcpmfIe49J6HoMS8XhuJYZeOG+R+xbJ8X1h+famN+/7EW/R0YeSWT7aw2H4dz6G++vqTK2HASGnXqPe331rwbeDnyYZh53630HBw5JwcS68N2iZm6fj/AP/EACARAQEAAgIDAQEBAQAAAAAAAAEAEBEgMSEwQUBRYVD/2gAIAQIBAT8QwM5J6w2vVrjq1a46zq1jWNcpOXqJ6z8t1o4a/wCFPUT1MzK0OHXLWU5atfhnBPUT1OHDeodzGayTl5uNe+cGBPU4esRK7tSTwCeoaQllq17tWrWesOS6RPU4eoz1Hd1DvAtWpvJh6Y1JE+STT5/JMmBfJnHTBrTDu1jUlsbYLxaW87vJPNPbOC6RPUzjRDvFWt58m0GoD5kerzW/wxnS+t59YnBdInqckkoQZHncXhbRjovlO8bCTkZfR1jJdInriMdwTk+MMptdwea3SG7T+at3hwlqca5vHWesZLpE9cSUORuMKPgi+UHiAh6WlGHeB4nD7NWrrGRukT1PDcMORtwTDpJXzHXiNtrzmnUPEPPqeXXgLpE9TzCbv6wR0xu/iE1aHxgoEFwx8+jfA9AXSJ6mcFrJEdFrG01ju1+yJHcNsdYMJMs51zMjnpE9TkjqS1jviYJFawxsSu4mhdM6vhk1l475al44C6RPXEcawWzHy3CeZfaP6wz8z8ZF25bycdzxdInqeBgbUWjj4jPhjwneCH7JDZebOG16TkE9RPU8y+jD/Ii+zfOctLESU3j6k4ebk4Tl6iesPExq6jvJN8LW2TUTOoHn5PBD3dow8XhrB4C6RfOZEsdWtzBTxJer/Cc6YUAaOT5tTqfVq6cBdInqeZfViDDBP9t/CDXpH2ZLXti6RfJ5F2u3AMb6iAO3qGyfX1yIukXycmDBdcnuSTXr68BdInqeJF2jo1gPex82sPo++AukXzmWvbD4wFrk+hu2H0/eDEXSJ6nkWvTDxeX4hw8xvvBiLpF8nJkiHghrjv1vAZ5F1eAukXycmSLp+FyM+jq8BDxE9TkyR+Ju6Z9PVyIukT1MxwLq972byy84Z9HVicF0i+Tg4BHw9y0XXLdsPp6xMRdIvk8j3z86umWcvo6xMRdMfJyZC7H3Lt3dMs+neOrE4Lpj5OTJDXtdHH1l4J6OjE4LpF8nkG4NGvb0x2z0y4efVwcE9RfJ5HY9zDTds9cszz+8HBdIvk8DA879587vrDdMuHJw+4nBPUXyeBgeN+8bLrhn4y4eWrq4MRPUXyckYGhHuTZdMrzxcvDq8BPUXycmCOjX4A1leeLz6uDEXTD1OTA2Pxsts4cPPq5CLpE9TgyN7fjWjg+n7wWC6RfJwRg+F/Ez8cHDz6spiJ6i+ZMENfjL5ly8+rGS6RfJwYJT4Zt6X3ron811MsnD6H3kRdInqcGS6eOvTvWV2lpJ84Z9S/y7YInqL5hjDO1vPm3b4t1EniC7Hv7YInqL5M5YiM/PHeNWuLLel4+LUNuX2DzknqJ6ngy8JMue7dvjuvlNeYefd4hbWXqJ6nBlKgdkde0/65b8tsg1wfVq8LyxqXHyeOt28ewfb/iLw74s+o2iEUJWCep5EvafHmXbvO/YQSCVwJ6ngYPdPRxcM+lV5F8nkXX1uH51xcM+p4l8meJJDbp8XRNvhvg4W3i+/eQvkzyIa2hlOov2+qB9IWG+w3TblhDk/h1GGcHAj43ESvAWJwQttho4OH1nMwzzO0YMHgcEQ283L7iMM5OJ1pGHXBiIh95uX3EYeBkwPO4i+YmIiHj9JfJw8x4iF2vmAi7fqL5M+gbhK7z1BGD55Pv1xL5M+gbGIu5MGC7eh/EXzD6fsXxgMH7HzD6V8sXkQYYn5469LwPT84PN7hwfDExDHk5vu1jWDDweXZy/uGWMLx+kw8HgY7sF0yRduThzqY4OP//EACcQAQACAgICAgIDAQEBAQAAAAEAESExQVFhcYGRobEQwfDR4fEg/9oACAEBAAE/EPgCi5/81DUDPuo6+pnmZlOW8yo/RC0GmobU4UPUbyQBHQjNL5IvsgzbqYsQ1/7C6ahV1rcssr/2KDFrKdFLVwSUalJhNQ/MtwVbDkF9wMt0EHFNxQ7COLxAr3M3DMU8CJywxrSwylUnzEAXZ/Uqm1uyiFU1j9wgFjGKhy2lAAfuV6L4qc3LM9QqzVSqOd8QAAvgvmKAWg8ahhBfFwCpVXySin4qoNT/ALExfECtGI2MZuKDdnUVr5bzMmuIBfx7lubdUj0OIA0mOO2Oei+o6cBqoNbMRwUdcQaU4lQNVGAZ/qGb7hAjVOGKAqi3XEtjWdQQNVbuVc8RCXN/cVoz5PMaqLkluFq7NxGwZubBx54jmn5hU04xmYCYolOV13DBWPEPbftEX8MKt+CVYzB6jxvqFdfUqGO4i9GOIGVZlQUbPe5iXOZNXuZ7hIK1Bn/sYHVRF4u/MxftDeMYQqPQMVeEZWr11BsUWcSmTxKVg18QEOxtYib74i0Yg0z4neuisQQML+JU4Q8M5qiyXFuyIGBPVmNVrGA8nEa0Di/mDehuLG4FrXMoxm/MDCrKE5joEdWiG0uVsQGbgbO5+fcUX4ljVi04BLD8w3kLr8kpQpbqO13fURtACzKzEXQsjeR67mRDjAMADav9RcjWmLTzDEZZhoLEbC31/wDYbWsShRFBx5gBwXjXmIbBxATR7uYKbM15mWxjEBQOOe4uBXfmFGi7ur58xGoOPww0YZ0O7Y1lnohByM56gNU7qYYbzd4CCWRS58wlLi2UKO5dq+JVucF+J/r9TIhv6zT6mSYAS5icgBc9plS8cOPPmNWSsy+5ZdrvPVXuUKIzPVTO7OdS5CvuCjoZq8QGKs1cQzUsAPjuFuGhZ5g7OD4lVrUcwLvMXgmV3OB/MMTaC1pR7yy2tcwZM4Y2z+kKWzWggOmajCUZqiVRXmskyxZM1BjYS6DE17Kjg1sgtL4z7jVSYpDKq+ZvfCLWErpjtGWuNQ4BPiQBNXfNRHMJxLF5MsDQu63HDPqZVN1Gry40PEHMSoNWOcU+ILFN9MBgMT2IIteSAD4xKy0L5lQwgeY3QNPkgBtWIKXNy92alWsf5xAUb434gPCmmBE9U+YqNUXr1AcreZiAyhUU2mDvxKwBUpR6iq3K/mLaUhziJsbxcuhlKhWQpG1ltppZQnFfqWBLsTfmIgucyyHFlfEEY5H4gyiZ+oZFEwZgamYeZmouqmi29TBTnZKgu/8AuzEy671Nfhhq1QOai4xAQxzN6QqWoqZZULgfG66gmzjc4o8rzL04GpkorsCNDtm1wjia8Z9QrTUw35mttG4J5EoFyspFbsrEwUVRvijKsDmUtK8ErRr9wB8csRaRvFwVagCl9EuysW4isM/HEQTdPdxaXDcywxVRho/PUsr5iCvJG2hctt6x6jREr+ouV7u47ksojOQgxtZcLUpbXNR0ajiUc6OowzFvIX8JZtCepV7YgjNHJzAovFbgbtfuAxxVQbQUvLSxr4YArKgua1TuNOg/qYvxFAeMQcz4qW1rmogWOOIkjnHByRZVoOM6gXUF54IoQYS4ljVMksF2bGANJXTCqej8R5dP4Q86638zglFCMYG+oEPi4QlWYqUFjv8AEVQ2VvxNugDDxmYphIpT3LB6g/zKG0QjwLhsjcmC4PiIEpPnMQqShX5uYNFmJeDxiCVmHxEKLFzEzO7joA7zFa0+YFZr2RyhQt+ojrn9yrBtmDD4mVmrjjDfUyEcO4WLCJZxn9QMZGScWfHUQgqsQstNQ+m/ExkN/URZoOYLg6l1UOtxq+dT/wAJWdXe5eVXDj1KlllYs5mCcmyYl3aOOqlAXPcpzt+o3xcQqYlzeu5S4QbeZZUaq46o3UpTfbhjJqWsMZ5gOCMyLHGYAd1V35Igx4FJ/ovMqUWTlRn3LAKc1ANc5fcyU6jciuCx8EK1pWtQgpj8RAAMvc5gC5ZaWmvMRdmzFnU3HJhgUoMsX5ma16nU1+ggKe4Hal6jkP3BfOLIpmDKzKE9w6M95lxsfECIpRsnEFLW/wCyK6UzXEwBXMAJqY6Vv3KdpSkrfmGkvDuavWh0Ahu3mZRTPMUoqm/MxirOYjTJ4l60LyriIKiAeeYIauuIM3ioeKoDW0OIcQvjEMtic6lFYY2J5gwmsL9QhQXnDGyLp7iFi7qGTUa6CC4OZ/yIJQznojgltEFLOI6NYPqIKI96EhqFZjhoM4L4hp5gJeq4lBq+YTId9MoFd4lI1QbjYzA7cSw4XLiQtwBEqDUAuOOoJsuAE7/EuqtGwhxl/EDUGlVcFFVZW7llzQwTCtZZRXrmuGV9wyLUcMyyenllxhAwp5lA4+dwhtOOZm+IyxTH0TgbXcSw9SszXbGfMaMmf7lXe6nwH6SadamGUw/xzFhBdwZHEQ2NQkKz1BdOt+WeBdXEz1/0QYbqpkMdH3MNy+UrMK7czDx7jKalnPKEyhBsTCRxggxYb+IdrFzHXg5Ixv6loWXHGrXUAoGRqMKYuGYpXxqGlZtiZkoltJwJQxFsQx3LFqdz3NlXXNRytXpfUwFcHMWveY4Uczat9xw6p8RHx/5GuWnqA6zqchWo3WTNcQYvJXEFLMnmJRMuoRR7QWCm4AqX0XzDRZWZRS09dxKrafuXk9/UETZLYxj9xLKvyJGoyifmGA2cwVSudRJqBR3Mijt/MG88GphYueTolzAxgbhX6RwW2B8zEFAPu5UcYgtjTdX4iF4wYCXCqT9TYUPZ3Mlxlz1KC1r9RaPEcK588wBbW6+YNJljVtYDR1GhWJn4X6wQyoZl3xF0pthxE1S5eiFSyn15mWDdy9hd5j5c7/cG7jQWZn3FhdVAXcC4vzMExMj41CIAuMy5NwRYvHuJadji4DwZ3FpfPUHUriX5uNxcL3awxacw40tR6usEZTHkqAJbVi4BQIXxUCxH6iwHxEsmePcDBSdEqlu+I4luAuaLXzODcFWX6gR1qXJu4FKJWvdQcnUbWxqcDdViXZMkVwZPEFzYhl/UzQb5qKiZ+4AFcXFEX7gSoyFTmFiWzTyHmLjzxcHlcMmtcxKLZ67jnkGOJdytSZeJqGQObnMYalti1EYjacwZaN5GFlWgFTRWQgZ093z5gUt2fWJ3q3bmZXjzFbvBpxFXPZ4gJVourgKgv9JTdmcRAQVSaSZ20UV9yzAGGoW1X/ImMiweAL8R2O/1zVxB86YMngJeYpn/AJAgGvTBRyV3Gr5KZgBV3/UZgxj85gy9Stv4qJaeksViqmq8SmF/EMQjcCXpQhogjBxCUw444iOoK8ytG8mpciUhiVYt8XAskHmD0uuYSyKlVALeeoeB8pad5LiHaQxcU9QAMO7l3jWIGBoqIumESqxYnEzQ3MlnEsqrfqUsfvqNAtCNAv8AS471BLJmYjxClkX9Sg2NRTLlszLq/wBQ3Rb7mAfMJXZC4vv+4XkTe4WeV4ZUL51FpB1Himbsu8xlYPEN244my576iUU5cwjgJfUAS8ek7DeQOY4fkxK0DnLRKyxpmxZKUPFxocm8yyFXtnmAALsun1HEGIotBSQNnRnECyzWIKbq5dgYwfELHmD3cZml579RrmATXQfm5a1/hYcomtHKCn0iazeIMKzLNVtMRWnBNHjMp1AimJQAiSnceUOnNy+LIbJ0Z9y6Ghmea/iemmCeDnuHYLVtiRJtbYNGhzc3BV8Q1dFwxqicF3/ZKMrKW0TVSygO6zMYD5ICaXDLN/8AkBRjOPBA9jzEos27qW225g0veoKDeCXVRMv/AIjqNcn6bPmoA4mmo/Omvj7hCUDup5sv4gHHWL0ezplRQxdBwiL6bLgrCIZ0d4xZ4alETpHIeTZEvjS2Jm4W3VdMRprBohWUt9wkQD+pga4LIcVxvMytXKabK4dyoCDrqUd18MRKIXwwa71wQNV2+IdnxUVKNcQWs+IvEI4jzocSrsG6zAhKLC3uAUBxAGGzR4ii2PNRbFApgxK2GjuuYAmxYAUVVf1KF0ydzIddytWaDiLeBmiOUUWgsuvggjbNm43d2VWpa7WYjk864jRVYJSuuZfxfom6oh0YtmYwL3/yFC9TkCtxkl3oiC8gVLimDBviWAt2EmTVQ0eEuDyytX3/ABzVUF/3DtfqV5uG6uXMvAKEAF0Qpo3KguT1xK+sdyktx4gsW3uHBb2QKWNQXhwu4xlm9Qia9Si8IZc4j3yVFC8nuHNJsjSWGOElxlqpYnlujwrwfviAhs7bX0gRBs2tkEQjmn/My7oPRAAq7n1FwYGzl6lMHTQ0Ec/+Edcy1P43+zg/P6hC7EaxxFoyIIioYlg2+dQs8/PVylF3LdrWcRbFPzMpG4Bbrz0wJR4Z8Qqg5DUFVRslhccVKW14lCxuKNzIc0fqUUbxXcpVdx2MWN55jFJmrz3NI2d9Yl6PP2RRjF/1AbNuWzqJxhKcMoyCld8QWEgVRmoOEeJm22au5zspWq8Q2qR/BFQQpylKZhdKzux6jkvXNk0BffuWs9z9TPD/AGTWFAPog11HsxYbgyX4Ym3qXhoqDs6wWmzEJZ7mhWobBlLhYECxRKcwHxOIywFmcRAxRjLCo0ohpq2Wuc3EoNBzcoIFgH3DA7fmJReyVzRx1KtrhgiZDRzLq6uVAWfqUi2Xf4JgDPScQFuTRHTjLtPS+PL1gjRAr78DgrXiZ1T20Pojj4FwMULpTdQ0ZqYfUal3u/EaYzOaLH5lgTP1AMmGDdGnuHWlzB7Dh8xybaGw9qIBfxETOsQ7Uqsqb+VSlYwphZkVWe+ZoDiBVcXvzKG1ZbZWDWfQgs22cRAo6lKusfuFDl4m19anED15huir/EKgNxYnBsvuEpQQDem+GOlGZVQzhKYESit3Axb9wwG3t5hsvuAMdwBu22OXJ4i6cpBBtebiHs4m2dp7qA1ov6iE8kOv/niC27/hlDS7dRFTdDGnMdoZhaCsH5hXt8wc0DtCY1W+IB/0TM9RmVk03q46A4mQEtcsKwtj6lyPE8yyrwcwM3WsRsnrBMhjH5gKrqICp9QCdxuCuPUDAO0VNtQVCmu2AmGrjIA8xqoodytdxsA13cF0W14I5QfI3D+SuY51EbtfR0f4jC4eYhiXW3xGOLBu45/DxG0TkVwsdNXeVvP1xEZG7gRep+dzJUwvXMscFPmCyzWpf2gEZTpxQv2Y6hMta5HJ6iquClhmg44jQFWrbBgFxfqINCMuHcAbdVUVuXQKM5ajqK4SDUrVMmUAos0dTDJqUNr5iEWIZ9xels9QG1gNXmbV/KwouaxxMCG8yv8AaJzS4ajF2Cy42AW2snuWuphTWKm6a9xGCC3luupj6dy8FBfxC30QLctBm4HK69ahTYyYo76g2n/xRBuxD7zKnAQKJfDMAhB+0tTUVAsDRCg5W6o5iLndVmYCpfsgmDLJeYwZqbQFMMNm6m5jzCqw58SmullNAMajpf1EogbxDts7lOj3DMFYcRHl6gKA+LlF/EILqYf3EwdxtQuOmG3BNpbYhk+oBJTLVf8AroN/uKd6uOv3yxIaQA17MY2Z83d/lgFxSW5Qy+otVzoTmFl15VHBHFFcAB9zBqq9B+yVatEcMcmcwSrZDtr1CC8hrjk9Hfu4Bl3qdiUdkpC5RmtsUF2bw5g8jD1xNqGpk+5zvBBTWe4TR48RywxFtX0Q7G28NS1lpvqDVVsocYzKKrYc1Ovo+ajVKwYemKtFmo7JWuI6UOY2gaC/+yg1w/UF8it3KIHOmLJFV1MGwKylKHu4Zz5jbiKi2tQVVwCNuNR7kVSAnOzEaI0QFExPknMwFouAAW3MxAMksFxCpMNlviCyim2h/cGfJx9Zi3U5TFvMAubIECKmKhGbw7zL3MeQaScIyaiqTOsRW6dVAEAiqDfbiZ8ZeY5Uxzqm3mDQbzLzLS2jKzVMv3KGnC/UoByShVcEx4XUuZ5eR1/5Kr7YMpbPNf7Ue9He9w2mTt36ItAu/DKnwJCmujh/sQZRYqmgfHMeUnC7wa4rqCKAF0xLHIlP9RrK4S79v+yxl2yVfnEQfH9Qs0UmzuMoKBWGzSeYesUO5xpT0mZVoWOfM6E/KgKFuITOYaGWJbRxzKKVRo6hRq6lC27nGiyna3McdxvYLTLpW9rMPguHoYvBiqMoECq7rkiZDl1Kq1rvGpQF799R01slDWauIN1TKu8nqVbN4qVRVu8MWkc6P/kz2P8AZDZdWGoEyP1FpykwgZWsw0OUMXVZoJYShd0y0MjYT5giJR3MCjLxKgBR4nNatVKFr35g6cSUd7maYb8wguplidSFF5h6xHiJdxBBuT9yojY7YJpW4xW3MqJbBc90z6i3FsiBe7So9MHUKG6DmWp1fDEAmcbhBBtozBVrqO2nPHtwfUKxCE8aBrnlrwrxdPXIuSf647aW1Hl5f93CotVsJfgFtLQQ6VgKPiMS1W9y4XTxH5pdVAnAkruW4OgsZrNlifEOK8ORgjWHmKVOu45q8PDwylUw8xuqArxdU8lzx/RDzj2RHH5gGw6quI4OQHRM7RckFBzXmLZbFWUpw2biuHAXmWAUw8RrLLNxVMuIC3FRsAlbZYqBiinuGUVgYsuW9XCkxSuCAA/1xEN7U4iLnNOoVo5x9wW0s58SjRv3HV3RmVMIogy9kNmJg213G7jCseZsSritRa6V9RKgVcVm5fN3+kNX7S+bhivrUIQrgwcRVg3yzHD1FANW1OzHHzK0Vqv5go+ZVriHJ7muJdTmD/7NDZBRiOUNSulvUtH2l4aaMwQRC5W67cQC2tj6gGOF3N5R4gxsjs1APqPAHJtjTLz3HpKA4Mnr/wB3+4pWBK9A3flcfiGNi31Vo/3iOhwNPl2x7eFw6gCiFgPmbCQ/hlmkGrua+78xoXeajzm1Mm+uI7BG8YlstQzWPURvRZ0xolqXKlbCBbtpvzivzMNpm9RxhhrbMIUvqLSWi8EHYGaozBtZyRTW4C97CUrnX5gou+YZizFT36mC6hYbxr3EqmX+5dHOxYKLZrVxxJs4XuJSQvgIBpc5geyl3KJTf6iKrD3EjW28Runr5YAm6s0QC03VSymnOIUvzqb7dsGh8XKhb8+JQazk+4UbLjsTn9EVLgD9y6LtG6lXu2llQlHcCIHRHkuBmwZcysNfcuA0ffMdOJgmO/BnC5vbiU3FTd3cZuLTjEu0ZaF1TiWErmEgb1U5dYtQKL5hK2DuXrfmMi51hYtA7rMQs54JRTBirYOavCTv5MxW+Br3EjUpo24u/qvwHMQpbXvLf+/EOR0Po3/cV7yjB6LqMPoREW0eJYzfqOuhHV8x80+SYqp14DYbncwidzEw8jAVZLPDKtxh/DEH/HxNJDArit19jAr5RdNU5KmFeSMpEfKYqZ8OcrLu3URQ2kBM3Eu+ckZt6EQtS/EFAv1uCoM+Es9bhYFw/iAF2mrWnhBobTohSo4dTKwOc2wOWjzNmDRxMC3SJ1NH5lh4vmUA/EpowL1qUVislnM/4i0QsrJ4lq7DzKYXMFfL8Shnn9rDC1b4lX70SpMB5jLzYwLzhqWfOoKArFLHE3ZPuYbczIhwzzF/yAauU0E21CgBnMGHmLpxLyVRuO/rUFH3DUHF8wguXp1CKXIy+oV5jUNksHu4Fu3TmBovOriNuKKCBjA9jQtQX8vi4uCvWJltHC6xwAliTaofbv8ABNg3Z9kB2IWw7qI9Evb4zMqVw4hnK+4CHdWyviX75Zqi5stlWq/UQD8lZ+tRgV1QK9hL6CqcRkxJzEeo68dTAyyahilBvHD3AYjCPKj8GLBsOSCHiKUvfMBUJ4ZTsH3LUrHMojpjUZVmNmCxAw0PiNP6RQAW7/cGS+CW2Y8ym1/7qG5rzqYRto3LJwXG4rgVcoLZRc/MmewgmA9gdxDoF4SNgzlX5jcLV1fEZeDDN4zPTyzFwdq9xx7NYxFS4I1S4GB2ljtvX8xQsfTMLThuUO3USm9zg0XUxd2Zm9DKVA4DRREAu6z0RlHVxZeZkfc0MS+C/mZtYm0GD+YCO0itKwQLLp5rmE0v11EerbEogsjxaYgEW89wrgC1UUKpZLJ4XB4i765qUP8AsLFOupRMscszCJbyy35D6XfJCv5mbBRfVBHwOWvo/bKCyIj6f+xMjv8AMcH1u1UblwXVMR9aCzNLm4wKZA6S3UrS8GeCLKCmy9ASkWSgFH3VRUEH5ikh2CWWMywBQljL1IJANLVAzlT08zEOBEiop1qrfiiBDa+Xsaf6ZVJ0xcp5mLtUe6gZxjiAc9bxCF0VxcUL8ZogGtVnuczY8wGVzuK5FY9Sru0XUO7PglDskvRZfMopOXZF1cRpeaPEFKOZcOKWGcAGd9szdMcYmFZagP6QS3iGAq40quDiW/QeYVyWHPUQqNmqlmYMA7CUpxf0zNjy/cOGfgO4n0QZIaF9ymPUxzrEud5iu+o6RaN+7hmmCUt8xYgKIM+pdoCJD3Ke9kKBzMTQjIKCALTVQbpviPxnTMDwQFLa+IE4dRW44jo1dnUFpE+M3F04iwPY2a+RhB2jp+MmOsILMpVnv/z+pxvUPkJiVc0vkSBMlunm4f4IgmqNapdtgYga6PO5UzS5h4o4eYnmqg5eCBDaMQF1cuyg83mLhwXgMCWujur5h5MqR34e47KxzL0PTLsPtKERXhfMGmr8cytRfJ/TLyFoew5Pq5eFixvImMeHDXmaMHHHMBFizUY2MXkIDkxFuOGOABjcNafSG65vEY283KCr3uNFlbajONubmRB3cyObjHbCmCoqoasyB7zADg9kZ3bolVc8wckt3fqVdDwNyhtylxs4HbGOMD3CjOfcuFKheIFnKziUQh68QAtVgxVQAtTKLzGW+Lh9o79v9w2oa9DFb0jSrbiWz3KJTT1AGAS10NzicMJmz77g0MVRgSLxBYIpMf0hA19xhr5mEWVxCvTmYVMdpHYA75iWshioWG5pfmZChfcoGa6xzLq8tXEb0ddzaEE9wnXUufRnIh4VUCdUg9ecoaskPNY/cVJW2Pbz+Yi/J/cpT/2szfAyUPbGwtnjgBllqlWISqlxQLQg89wkiwLOUYjsrS6g39AZlTdO3UQ5rclT52xgUhNb0KnLRCZBkplmK0JLgSsOxI6gS2tphsnMpRUobf7gkcPMHHRk6P1LXplhTdKfOx+T8+5kXzCGbgaiM7upY0G3UuyA07WYLu1/ypSleZRSiDUBUWjmWbOyXYBZ5hKmzoVFk/MdgFq+OY9pcEGK9XnU0B/7HWc1jEoQcXjDGjbqCq7UYEO9kcS8XzCa6zEVVf4gRu8SxejuEqB04inY8zLnPMbP0z7U7oGlsGEVOaGNuYA4ipNw3cq75jWoGILFULLA3m7+ZpLox7+ZmXHVCZmxl9w2czn2x1qKqFyxUptJUrOnb1CqaGVVswG3upjOpgg5SLQujXqK6XXMtcq6gXi8RKJVriCg2OUQW/AEXwPcwtFtrS89ZbZkpA/Q/OfiXmuj5Of+RB6J+iJPaTLRZAF55zKhLAA42WWN2KPmLjCgoAVi0M5rMTKDdaAMEXiLmECm7gBBhw9+JSVxzqURXWZg6JSY6gtEG26efEGmFBEyMAD2meMC/Z/5UDC9xUOwy/D+m/oRmrAdh0fkqdzLEoLd7i05N+CBm+/iN93/ACVhNkunqW7MbfKp5YcVLKm6qAtmuhicipsGd6lccMTlc8QuplaHmAiVripYtJeS4pakR1C0deJQCu/cxGVRh7ggBruKnsYxXxTUVd+MSgMRNoVXUWYoO3McGBCJcpk3UFP3+iD7SHKYj0xODCunXMKBWc8RthDYG6+5uLzuNFVt5Q2FZUDoJrBlNfuPiEhiVJHRrc1t4jLB5hiBCgr9TLb5ggaKN5VnMAvclLDwGvUXBW8SrGrI2o5jndbliwqs3KJjxg9r8GoFwc2w6PBSTQzX0vBFbKtrDIZGbjya+ob5AfdQ4rwX0fdZhjhmUHn3EH7EQ3fHiJYW1LWpYrTniVBcCb4hijYr9QrFyikSKEKZMYmxwLeaXcF/MJZi2fkV/wAj31pn5hAIgppgg/Cj8RwqK0fI/Uag/wARlSSyvmuogw/qCU78xUVHbtUtszkGPEUnUKbc6m9jF2stSAPM7eICM5TcxjQXE091iBWVK8k04xeyKxr9yghRcLC+WyU5HLKTmitx0LXddJAblfuI4XWdSpxyXO0xFu3WM1LFNFxP9A1NnuCqEUeUenpliu5j8QQYQ1Si+o+DVjHiiqlUAg85thzmJ7uZkyGcEa6YghVQqZ3iYVeIVuRAWY/czoOsTJB7goRGhUbVkw+Za5U7vqPZA68xQL30ywzhSIc21AXDtxGlgXj0SrFWYpA/KGvcEIWQDDSh9TzAF2pbvbj2gtWh/vxP8puZdCH/ACDiB5hxUCL2VwXVTNAKq4Du4sVuwKI023k/iHcOsxKaxVhMkVMszEnmFgtFhMsCYA/cdZFWykXzKuoH7zEEPDcufQCDksT8tfMuTwpOoy1fjPMuVtfErSjmXNFEVnZRp7hlhsc3LVnHdyqcM58wxZ/7FbAwagARavmOxVriJtGbJozk6mvpz/5ELv0ln+pZRuvqa3VB3Nh6I2ymjL/5MtOA3GgsC/qIagC8ywpjwwbqMVRBNYfjmUoeL+44yrvcsV+ZkHZ+hNTyfmYkVfJLAdjGFWMLBYAMqOO4XV0ZjQsVKq2rx8ypqbf3gKSHI6zUd22XFgiMY1BdXMlId9xdrPEvfxGKTrcsDFNZgotRAIaikVhYzPDD7l9bEh7U7iLW6qZFDfAlqVVLiuIr6O1jJsd2EFPr8ZwKhVth/v8AZiKuWtO+pag4MA5lhbhvy7lyx2jg+Mh/cHXUvZCggP8AQVX/AHY/cL2cM1fVkOS3Gr0uLCFBm2EjqWnctU1xnjxErRtuWko8YsC2Vp1NVcfuVU8V8EsEQdg0Z5FHxYeoaAace7/+ypfbrxECzrmPTdvEa5OV9EqAOOIllZf3LtsHLWKjqqSms8+ZbRGLcN+Y5w5ceYc1HsnDLfiXojjzFZfOKiGSIqq4AVS+Sek79xEFIpg2I5THuBSLEx7hL2qolFS9pxKonxG6HPXqMaRvBLy7vbA2AmNO6fggvsfgYBgVX2me3TMhvLRM0zAg41GZ1S0QI1x1LCjXUu8AAfiKFlSijmoQAXuJola9SpN1UeAnpK5NwZbfcuPoeIWys8+I4837qYYoHe2UWL8JC6CgeNwRaGyNE3ivuVirzKDGKhaORmvcqrHQ0Qr4Yx2weRVP7n/2LKINcvlijka8nmu4vgwP4ZBKfCLj4P8AcCgRMMR21u5SXAZVaCALNxurTbVZ+J4QnlndQGn6jMlLMyM79RzCrgeEcftiBOdwfihW9QaehpMlyg/CEAuotXhcMk7X8RzSu2YrB+bjcAUIvyv3Gz9XNAvfUo2VHWGhiZDmIpZEPuBddyi5eoWYhWTO6JS+nTCqPCIAvzUBd5ayQpdldRvMmeLgDSzHHEu8S6juAqjHmUJjeKuDbGOGI63+Yrtmrjuj8y7VUbXuquqiUWeYyDlm+oKSuNstXNzEv80T5lH8CtPYyr8Q4iNJiIA3mW8FbuXoJebgpg2YiBrlL72xflhpeqmxuXQ83BETpM23dxsa6fmMJq+ZhbYGbhYCxzjmNjRVXfmXOPhmA/NQgU4fqX5Sx4FVRL0qniAtOwxmKotz+IMoinKmPnREjISPlyl+5A0MyxGxYtKPUcO7cgVf/YpLzpTQdH/f5GPd2Uuar8xj4lHJVFev+weoPEFtthCNDnFimfRvMroKpju/eY6hLus85CrLKVGnA9QWLuFmC03oPMvUXN5mIDf9yv0n/WVq8XC1eV3+Yo0nOcTEOUGpdQUFmsAo+S5hyYlr7MRIsBHSagt04GpnWndTF5a/EWBNzHfBDFVQv5gxXPVygHJ8yrLWfGpfCgXWIiuzohCaYoHmObi1fcrW/mWXI+IEXWLuMVV1nE+qwUFWd0yhtweYzR/9iriviOHjmeALGIZccTJ+V+CHB7QLm43QxHBHX9VKSxGMR0BWdxVo1hLNOVXPUAObXzmbK1HuFy5lD5h8wPUFMxKz8S1L3FWWyO7tdcQRrjjxGW4qFqrtguA1DVk1zFpj6hQWyMoyNvMTN4bhTK7hYp9oL6mLzFijTIhGnNVUwQpoJpOKltSsYOiIuWbjk+IFyoT8Rc4L5/dnzK4HReSEB2vXiMUUcF/4iAqhZ8HiUJXm0r6JgYt3KSO24G7Q1VqX94v+x01zX5lQ2Rb4IhXQ2x0clX3LATmpk3vT1KiQshvrxMq9quXl+enh9x2LsIc+Y6WtbgZOYpGnSIB0my7CWlGrnGlMNHCWtKBZo7ljbAoz49wFUruAbDBjcGkRIADKQK2P4hGnfENPUcBvcRcDAXCuZ3CaY/5EBE4v5hajIVEtDgN0xLFB1EWK5qLO8C/BB8hY0i+pihZmiOzjHmJpZzMnhI2qU343OMxjEHJXcKXavX3E3UVDxMBXcOCOgqX+OYy8zAE5q4GgXuKZuDRHyqsQS1GLTOsy7TBtCBrvcTQTz1FHB57gj9cSwr8wkA/E5BW1dPxtp5DxEMDQBYJwelUqmUNhd2/sl0NBUsd8SjVVie4zbKRqDb5eYlAUTNm/cKyAAunB98+ZsniNSw5YvqL4XNRvwOYFxRzCsKJbMRXTqXlGeJXZo3E5OqIVjaqYL8/maV/0mIZxeIr2liHCZnGQp2DwuxH+nBSsOgeSfuuG/EyJb88TzEWWq1bN7qLRf1OGdcwd3XiXZZV58RRm7eIiiCD+Ix2xcUdYKjKcpSFtxYsElH8E+L+4OMfUVQGgg3SzWINCI454gcgXwzyOsxKywYmg3Kc1jllqgjYdSkeH8R4ej+0VRnV0wGlOIs2TEKWKhuiqhApUYzKrLhWFmiG7SvPwUxcsuGIsfceJRw3L3uLCpoVdxajUftlsrM8VKxPvzGaPmU1zckztssctKb3UGrXYELCVZ+YXRvqC3JHxG261ZEeI2CwO4gOSUaHC9AquM1hAUuXmt6H6ogag/Wdy8qg32S6aYwqDFeMMPz+7hgwK0sZIiPDLoBA/Scj1LuJhWF2+Txsh3GnqKAa4dQVwUHPbHTHvcaMz25fMLl1NnqGlrxFryXcoHpKgd2pPEHBUXzWYlyz2VyQLOL6lmUNyFJ8Fnr1GNaieESD+pXAV5sye4+mLh1LL+oONXqFGrC3uKg1fMro76lizEVji+o0ofcdYz8xtJw7iRKzxUQzGQmXxzAtO2DDx2zg73Cmm36lwXnKu6hbBr9Smm2BEDu9xaZYV9xRjJuKmlDNSrZgz7lDn/SAF0Pz/AAY+liBCXoouArKfEeQSzxxHkdRCsLq7YrBwoDqFg5pYtMWYfzmFVOGyGtsqPvmfWGmMygueJzDf7l5dblAbuXNbL9RhyfuZWAepcEV6hZEfg1AlqqKgeyIXiDcFsrMNjTnsfWIahxN6K0eLv7gmqvYuYlg4vahcRIrm7+5RFzA+u/jfxEUhok1ffyUyiTeK+45St0wCpFiNI9ymBmVpUYO3v7mWZfCio9SV0o3K0S7VQ4upXiVL1mCqomB0wx98w6nsePMQAwuDjv8AMxtuoNLaq8y86oGTMiDo+MwNbCrof+0ShK7sXt4Y8rbmMtjDiYN/MsM3ELjKzf8AwlWzmHAzUsQzK1TUoziVL3oiadrm5sg2+ZcxEVu7qVKkspv7mWlxKoH/AMlwswHzCwvH1AC0ugBjs3jMGt38RUKl2xsOalk4sPzC0dr+sQHh/U0rxDp5uDG3EFNTzJdGRpYMGZAbEfiHimUuAKGi/U153LsxfmGi5RIFU3coMVcRzqEMn1DSIxAzsmGdjF0vrcooAt4jtUvqOYxs2cRVNFW/UQKU+4Djq+JhiUXa7vUT8sp3nHq6GXtApXlVf3mWqOuRx1LouH6lbXQ18Q3OdPcynl+wyfWSAgXU2XlPzDZ5inNfsIblkLInAsRRouJoMZVWI7S4WNajZPx/mJU7ZuZ94w+oxPLOIrhcMj3FpvfrhJRNPw7GAJYqZX9FD7jj2K/ZhQ+blhooeEfMRWst+Iu+JRcH5j4lQDf6l7qp4yxloc+YWVX5lVKeMbliNtQq5bOMS/Yg8x8+ZRWLde4PTDCc4msuwKwVZq22/EoYLFuKoHZx3DAL+4tFj3DNjOHEIstbeYgAZuvMwObHvqEJX+kGXw/cHM/ZmUCmIVHjM1EMwgCy3mMjhDGAKKYZh1OGs1Zlc0e5dKqaVADxCuvxNV3ArECo8wA8y1nBLZ8y7bFQuW8wYUjGFLn9QOVzUDxVucw4G2WHh76iExIULavXqFAZQw+fAW6NtW6I1rW/Q4/3zCbcqrveWbM2GPcAEez8sur23EoDVpAp5UnJ5H9wsFdw1viZCvI91BpBpwJBFIXMUko51uVYr7iJj3BbTVP9+ZiSkoX4GE7MQAxXLeeyNUiI6ZYP6iUG/nqLdkRzwlQ5Lsqr3eTkt3GIuLtWbfrjr1DYvFOy/EO64i0pVxvUuZ/zMm3jRHGrx4iaYK8wtjAeyLfXiYiClcQQyxEc5x4ioKHiD6I6GIwQ9dzocVZAVvIX4lA7cv5i4oxEoX84iFgy8w3b9xU2MYvo5iIFaeJsFNcSijt+v4II/ZhzTbzBiPAXUvot9wsaCvEGlCKX8wFaZCiFXyO8eY7P6mQzFO5rzKKcTU4jrx5m7tnk54lTQSwCjGrhVdD7hLNjuplbIbxXkmw5Y7UBmYBfcvFnUHItp0Sv0r6A5r/cTL46KurQvIOK1dmY2moC71AHVcdVKPhpePh335xxLHVjbwVt8ssA1lOJQOsGPbFZVczY6/My4ulX5nCuMQUivcz7cNb4B+IAzS4Xf3FRU9TNvJjBDroqtQXcvMAlpDrKLp6eIDDw+j/yJ3rY+1RW6LvDdQAEWOjMgFnZLrZ/7E0zA0lSm6VwE0n6mbgBuReTXFNQDzALP6fTKCsr/ULeItvMWqO4HD8Qbd+Y9EwgaYESmuYpqo29/ENrB/upUC3B6I8XWIhKDxAQwzNK8cxMiaNB1nicrbbXcKbOYvFAUEvd/UFRbMjRZKPb/U2eJNSKvSxoJYfhlQrzD9t1LBmMSsrmrxG589VKvJ8mSGj4hsYc/MvSoq3BtxLX46mPMSbuJQOK5JrDe4jDliIn5jQ4qs+4r18TKjiodXE/X7lqA1tgUrxAstqaKLbwLDpt3URk3RkdRy+EOWEg010MAPGK85hDxKrk67CYHaZ8PXuNe46q48+ogA4NeXuJftg9T1H4Vsyz2rDKVu6l/BVx4W6EO0rAxW6f9iDRDPbBdedXANQsIKhklehnURvgd8QQpctaf6eYYVHisPxGYMXVEFslR5Trt7iGMHBH8pCCcgemK5x9MSAiCmBOv+vuagW7Fr/H5IpkVQ7hvOPURvfmZf0sEW7ipaA3HnOYSlfcVl89xAW0S+twhLcSqyeiNVBh8wTF6IzYKvMS1yqMTZW+WUc1EpbQqy62xWYJXXMwaaHW45nvqWKY/wCIZkrOa6mK9n4/hhxN/wBkQom1zKlEol67mFDkhtXTSBMOH45YrhVYHljkLgAfUX5RYxOPLM8cQGDcaM1K1+oVbS5gsxiUaA1yytBTAo5zAlERjOxPBEMLdauDl5gQvWF7ZjRYNDga/IfBhDpiJQEW/LHzzKCm4dIcHL+paEUIzeisVTHa5zihqraGD2gbfrhmOtlfqNX/AGIhx5n5Sj+5g5K/Exe0uHQf+xq5wD1CLP8AxB6DMVoH8SiJq8tTDzsajmxt8RxBk0HEuta0UiunZ3EABAoDFE3xbSi+jt8GYWh8PgPNfQZ76gOBQfwB1A8QJSxz5Tn45lOT4/FT+4vZ2pV7HD8TTEdlcxxhmGs6iqv4RNOZqs8M2qEVm4rbzfNyjjjU8txmzLqj34hRuUqW/wDYbHBGh5eoFqqzDIOevEFC2Y2bqDILWyZoCpBquO4EVdmpk/P9Sv3v2QYn5bF9EvU+mZQGsFMVAepRbHNHMMNeF+JqNXfkl+OI22ZavuCkFlw+LlaIbDcqrVuHHDBhXGpYapz+JyNg4mSH4lZODURrMooG+CCixK7mS7qoFFZpp7gTKwHBvm/XFOKb1lotfOkepqT9bhunkBjoi3eAPFADsw/uWjEtb8R3HWM9AcB1CEazn+SVuTkfPiYY3js5eYpPmHyQM9gqD8zfC0kZjLKpMg3cFwh2zGCWv+YFgLoAmJUOXUPUDVe7/wDP3HCMXgoD3xKv3hDSeR+BjzK2/wCAOgwEy3MrDvDaYQhMWtEsavR1/wCxwVEwlQaROYLCK9VOn9nE4MRr54iFDf7iLSVUreEuqgBlf9wF878TEqkRS+WYcsVKNLP6hwFUw0/Vy7cQgDZUTBk9TN28QtK4amTWvMS1bDULrCs2yrh3FG81VHiCAOIX/ZqFG7L9TIZrd3ByPVRvEpcwmXkqALtVDSM4lgNkxKG4V+4p3mQfM1CC2uJhp8wFFZeh4mQ2s1Nox1SxU3BlgFPcNrXqGjpcQBo26IlltEJGXHMFC0f6gEto3mDjR1wWmk/JXN1Csge0tYu9E+oLxW8lAq2t+sRrS7S4vu3wYgoDGBjEfk8Hxyx1QsuBCr1jTX/uaCVg2umNU9XFZmsPiZlIwXB1cNoF4rcIU3zTog6l2xFbf+ERrgNxLyqo+Qri/wBTGAacZ8sz8H3FB+P8sb+VxHWCV/DT+FY6YGZZDY4bZrPM+KZpVwezp7HwxinEC67PZqCoY3XqFcZj8kShz3HTa4eHiX4F+IrVnEWLG/1OTR7mQcVdtERiriqtKWqlFGjxEpj6lKG/UQKk+pXLnMu3GFuAIUC8wDaYlYvd8EtVXT1Lref6wof+7JgR/kgGcuVCnEQAYEFpviVAmHcFBwQ9MSjwM1NypmERfzEAJr1MRzcpVt2zj57gRvExGMf3K0KLlKNu4FujGIHYxGyjFxN08EbtaC7KxuJXheJsF25FcMEXt9B/4yv5PAOg9KYxmLTdt8P8SvUxaDXt/UV4VtjHrywJOvH/ACOXzqO3HBTJ4Hb5joqvNvMKcEAiLi3mzalTE/dePuLAZs0+zmV0N1qNlKr/AHLVcoG4w5gU3V4iHsf4ZSXEmpAxlWhoDKrgGEiRXtpLocCl84uplMm0r94ItnB7yxKzle2JKzKgSsSsweoGMxXfZnc/xPcvPMVZtR4cP5qIFeOJYGMR4tblRvdTgBi4LRmNEpxCc1lgKYuJbh+olFNckdFPMMBdYqFK5evEd0TUpTfx5hgaMuiHEx+4Klu1WvFx33cFSjf7lrU/iNVfL1LM2Qfqf5HSHYjfPn+EtnMLYYq4QJPASoqMQUdGDzEnxioubH8QF56hUeZc15mNH5j0Q3GamzMQWso4hQqMYuYBpyYg4OK9TmMxLPE3p5cw0YOsRMVWdx9MEypgGRzlACNXujldB21NRfGI5AGraOu7hPKQvvNsuW1s+5hMh2ufHzz8Ry2BQHHpTfrXuZgt8zaA2KiA8oPmWgGWz6qVkqxBhKYvAHH2YD0PucB/j7VXABlXAEObQBVh2ZA/KLcURfmu5bKjExK7j9/xXiAzmaHbqFBWcYI8XFhm8bluWl+DD91G7brzKe/ETK//ACIT9yzviOmmor9QVcNy63jxEUuFOqcwQ0O55C36hAsK8kGq5+YHioVyrrDzApbrqBMaBrEyC2NLAHItvE0vH9SjqkNwA+WGLashYJVT3NVuIyZ2czVb3BaXwlGruTBmmOZgHzFadQExDcajxEK0xGq3iXNfiGF+pi8VCi7zKt6QxCEs6xL7aV/ECNXvUFqjrEXugteNv4hMEK7ZweIV2R7YjYkL8CWPth+ZXaATPQplCpVfKKqabQ8RC8ZOIocmFwOQWKp1lXxHTlY/Vyyd2VGv4MFSb0Svp+xFbCwsewR0PPreIt6EBehXZrZ3wBb5lXPNRlYfqc4+4s53D5lT2waZcDqBvEwJ7QxMxgRpHD1AE0K8PP5uUq71qFGXH9wq4zLsXmXDI3qVcIAiO5YmcEV2xF2yjmSNnB6iXa7hy3DDUBd3Z4gNqEt4iLl5hK5xoiIFvBKWcuL1NFjMGfxfxDQ2Yx9YTqYLfuIK1xAAnz3KbH/ZkHhcoO2Og1vMwWri+Zv1iVVcuX3BXOZcDcVDe5TRlcWxMTcCjNtxAW1mpUFXfUFHi2JSyoIjeo3g3FAsi1fEJoAxBaho5ioqUG+Up+X8S5kBXbUT2H7RZxRSYHgDgMB4Io1oqvTyQSVBV6uo2CsoRT8jHq0MFeFcfD/cvKzSJfJ/2VE3SnlnBFUA4fVzBDatsoQQP/ncP0SeqCFgZW0A75JqowEQS0UyaLcHKF7lQ3Kz/HgCMfVQP/kquZfuXF5qK1+iC87lC7nEMYNMNlbaev8A0MGuot0v5i7SKihfqLTeTuZHuo1nczFJMPU6KK0TFTf/AGFgN58ThbEQFV4l4MVLZN4hjKeIOQiu9QzYOlwoXhdEtrD5hrwoz81+z+L8nLPUyykdAuImz8xoWEONtSqtquIr8+D1DZNahRxiV5dTEuontBm9zBCi5Q9oLFRCWGYAgJURoMj9zAk3zKM4QBXEKFFD6hwIeal8bcm2gfqVeFRgEAum38QVIFoeNH1LbkNYXivxG/yb/wBuAWHRLTxe4yNmBZZ6+I9LbCl8yoNONBMDk+Wj1Fu7LKIcuIGZUNdUW8PCIiWI/uEnRoli6FXaqqqx+Mz69w9/wyuKj+ZU1O5cqlZuKuK1NikegmAII9zUY+CfPZ+oHpDDdkC6+4jPEMTxAXdvEpB3FtkikI6uJVsPXUxbzoiLzKd/fEvBL6l7K/G4OAhUsHwwaUODVxFdq5mWsBmvEyPA/LMrOj+5a3tfuDKY+1iNnhmCQqJq4Cx0ceIsXi7laHPUsUdSzlKpA9znOTHTfmCl+v4DgImmuZcvLMn5hX3KC01FCtcQ0CkNAOaiNC/M0KteIWBab1AypavCxxmli2utgJVqVX5gbUXdCKobwn1Cdp4Tbo9T5QYUcr84mfGs4y/3xKWUdH+yw88j2+5kWoZ1GroPMz25Xdyr3DhAgcw9pXUqGNXKlRPmMS5VR365iwx4mWVGJQzaXDI7huf4ZcxjHKaR+rLKs05IrSUg8jOCscxHf1FTMsdyqosWfUpQV+ZRRfiWZHcxyMMt/MpOYEby77ic5fhiA8FdxIoHxMrO0ZkU44iH/LmVs8z8xYmXtYb9ILEo5GI7QNNzQ/MXq7gqY4JkTiiGy5QVbn7IbpIcF6lJox5iOWXAKgXk3CYz6le07iyzZx4jsoY6gL5Y6zuojYPmC6N3qKtuj9yttB/ADldfM2EWpqB60eeeSEiCZXNf7zLRNBpvzLwdBDaws3B3Xfljw7c/+yxNvyTLXoHUZcPUr1MPUNcQOYHxAbxGVKxKp5lbxHcT1NevMXUY/wCqVkcvzMEWegJ60zK46My/gzrLCc0H2Y/qUrmUFmZQsbgKxqeP5mEKiyVFh3MBTuWAX8XLGJd5wdy0Bliq5ldX/CAeVcQS2ApYowDcFdX0dyqrJrfm5mfj/sqjn/CaT8l+ZgW6m53LS8ysty1mBuw8SgptlS3erlGrgF8xQmXMOZwPEVoSlVABCDmBlXxOCmWIMZeYcA5QBwzIstQTOvEVcpsb5+pWWF+ot4VAPKEV6q7BZDqweXFrUtplaLly9F9twdDDaFUP+sXaKpld20RAXHm2wdrqJr3kuTlWcfdB0/7+otrn+5XUDGpUCpXMD1cr5lSviVKz1Ocx8xfMU/8Asd+JqEcJf/B4YafBl9ETwSgImLSP8Hc2intU+MP9yxwRXpi4zcsyI7a/MbY3kmU/qA+SM7Mdy4OPmUjcQGKxBITbEHU1LODepUVw6gcBdMA5Lro8ymVZvfUsgPxBXzf3Nztf1HDzXyx+Woqi2QS95hQWCnqDsAZlSAKYe7g7J5S2/uW+8yIYgI6BA3qVXOiBQUgryjXXMOuaL1Lr94hwMRZ4VzCJ3BWw6nMVGy27G2keXNQTrg8LAHwV8wDqFFC06IhAB5yvh/viWu5TOy9r/vEQi8ViqDaEWgGub2wxUw1KleoHiBic7+ISvGIDqV/Cy0erYrzLqYmWgHDMucxbGP4VE2u8wLeYra3GbRJtKeh9wT+os/8AJ1mZYZYlK+Ym93HTVxMb+pxQ2agM9QSg/mG438wYZqUrjcTF6axEfjuPX/OJZa8AYkDLjzuGKvupVdyv9yzhwFf1MYP2sKukW8Vip5hr4iUo+IaPIXD8TiVaosTaX4n7J9PEweHEVVglauG0rUBkhvMHM0YCFly4I4oMBcB5OWW5cy73GMle+ocL2EeF16mJ35iywPOCoGVfEJAZOboOeDfuBaivR0rH2xtGrVs9vEJcAXPLwRWBTqdQJ4zMNRJVY/zCAmMfqd8XK4mMZ/EqPr+K3NtRjpi/cquVuCL5i4KgplkHK5QiBRc2ueE5RhHeFsPtmLV45qayEMwcS8XYQRPjUse+RioZUVb8QQtitAkUbWWV5lww+YbqX1csJyQKbHzDSAVbbWeoXorELsUzWa5mIOv3G7v/AKj/AMvUMO8nLFtXFQF5lAL7lUKwVZDEHz6iVbWsw4A54nxa3Bm5h5TD2Z07gsSlEBR1MQTNqx35lNu5VlZP1CgOBVMFbhqpg2hEG+fmGq8pmUAKL4mW3H/YzAm2LltwYXYNhOsNXomhwpTbqrOxq/kgcF50YHOF5cQAqoKVoSKI2R7oPRX4lERS69SocRmfH8V1K4lXUr+GP/sd8TdsWvMXaS4sWP4iInRGH4CGUI8Fw1aK3j+LCae8P3MHLnxFeIJMwsd4l+OKgibgKlQZr+5bGpcIXEVOIoPoh8lucR0+4aM7BQlH/sFWjUHQ8RLjufmIPjp+oMMwp7Zll1BpxN6bgteLivINRBfGYJbvco7bpmMvTH+UVgZ9xYLgMA5uGAc81MUqUsq7ioDbfMa+L6gwKb/UobZ7ZTQ7uZsc1DeXiVPKscYDrMJY5fpzF5jt1jI12oA9zCSIF1o9FEuhlqE1a6v7lBMWDsIKH5fNr/3uAAg3EjzP3P8AZgccE+JVlSncplZ8zMXGIvqMXzUX/EUfuLMWLGbXFyxdf8Uz/BhPT/8AZHeoY4zwMwN7iOdv4ixRNIKzL1h7jIZYuyzMQirqoVpDcY2NdXA9jNik9zI9Gog2Sgs0crxDLKRxcoV4zUvS4OLr+5MZP2sVnpC4uKqgpfURtBdA4x5gEu2CuJo+Y8RYcQlq+4SsfmWwqd8yzV4ZgjKqdwmj9TGXFRWLnmGDWdUwqr8qgL5jCnxHReF/ETyUlIt0IHmrP6ircCdiGdgrZtq+oD1A7bayy953EVtRB2Zv3ZBSKox6sIbQ2QtvMVRj3xE4lczjUrMomOLqaThl0b9xcT4jFmLjuLMXX8SjGY/gqI6G2Uzigx/IQZDx/cFMYIJxeoIe4N7gFXOKZKiv35jrn5jWXE2I68bmIuIwYzA113LMw2CFNXMhn3EkUzCqy43fMqlRUhFjt+4HP5fdTdDeba/qAU0h9wtNJMSvMxA6Zc1FglUJo91LO8RBcCxiRX3/ABcYgRYmCnfMxBWOGco09wcKdwpRwdnMOwXaoT9w0rSD7Rn/AFhbVYJktQ3AaXwLL7B8T+xoYBUUUVzvuXUgrUOFf6xLaBH7MXEUjL/MPicR8pT4l8u5fEdtS4tY1Hyi/bFFv+BRYsY/w4kvDwQ2M+eOJ/8Af8CGm8X5ixwXBVBM8kLl3mVZk5gItb2dTGVcPzFgomTmBaXN8PUBz/WobMnqFHgiioN8wsKqXjV/ECi0uKLhd2MYSZe1/c+yv1M1F8pl2i+JtkmxLw69QgFTg8cwoK5SWL+jNZXOIG5oHEqA+ItSyK+YLGaj0zqZHZMYC4IjgYcXz6l2gsloXaVDoR9wS62hNXVR6LTUbB3zCULwPgpUmz6igWq36JQJj/hKFzUVNxs8Rf4st9zvxL1lnvHtfmf4ReBuLnEXqP8AIFixjGMWfUFl9sVUIYZj/FhuDf8Azctw/cb6gYL3BzzOELgOTHR5mC5iEYgZuos2X8SzbTzENWAErLt/7Eq4X6gzJVEKCsREFpWVtT6gGnxGiQfki/X/AOE3T85iJriKsss8oqB1UyfBzKArxALOjctfXFBRC2qZXm5WqvMu2mfEVajNXKuzcDTNeYsL0dTAVxKNbHnxCTDBi4RQcVMXYbiB2PjUAruK16WVtLrqL3H42v6mZ0hzWp5rF+XX9Ti/g3mpHznwivHidplxBXct4qfSex3G3EfKf/D+Bf4P8MYpsz9IrifmAEMpXMd/wMtXg/DKOaYuM6jo5mO2WHqJXMu08ymti9QAVxGJXnNcQnEDu5e8a14mGz8RlRx54iNlniNg3qUUaBVsHhVC2XOCBeUC6gPaD+4sFf6JtuEfa1KI/AgsGYKuqJuHv4joF41DQHepVUXCxxFYniYTxVDyeIw1r9TzGY2uJlxDxcUW/cD5ceoCCqCF8PfmZVWLmSsbi4meZSkDW6hO3uDjlM1LobyF/M55/aZdPdMPBLK+WPhyf3EuczJ5/gvzPZl4n6ly3uX5+4s0YsWPlFuKLFlx/lm0VjKC486jc0jCYJ3/AEhbjuN66h4OYc6IrWm7gIVjOv4IHcsQqF0vuVQO4uWTjxEekeNVNAVUuZX1CqKOahY6fcyx1m5dghZwxfS/uE+e/U3ypi5QWvUv3HQIqGEqJN1Hq/8AxHDvj8xYuFpE0m/xN2Wo6htNeZxuiAdGIE5niuPCrgZPHMdeT9JgMKrbME2T64qLHxEI9hHAsoC0+/M3F1a3rMvrd57VhS3MswlmtP24hqOKXL1/D0/j6/yXiMMPlFlxZcvn/wDD/BwCYgT0/wDY/wCZp/AlTe3+iLTMDV5jd4gN573FRgjc5/25QufiBjEvZlm0lQy4nMPHEFW4q4v4mIFzxMdFET3lfMYUomF3yZbQoXBdNwNfh/c/w/E3zGbSma8TefuKqW26jaLyEBbF7lBVGiK/CY6i4Ykt5loEwHqWNuor+Me4KUsO2KiVq4bFkGQz3mFwLWyIRmu4wwbi0rQfmJXQZ5dwqgRb/EU9EHsAnY46DwZ+JVguNsFwYpxXECZVuPB5iVNoD/C/8mEqW6lMRYmY+ou4xj/+GMRq1QXz/iZttQjdx3Bj1EzN0h9hPzEZbmU7dxcV8R3iyHUcVRG08ygY9ATRh+J8v+wXg9y028kTQUjGlmNwYgPNRN9oAa/9hq2vxA2iVMvL+yb/APnE2yuXtDZ7wYJkDjxLAHdYnUzgJgGJo9O/meCI1UNfxtNTOSrATSmYqv5hzu2b+2VBj47hrO0jqtkNxdxKHFQ1rbcHs1eNQ9EDPONzWdzMNIJ80/tCl6+5l5jqnxB9kqY4pl7r+5R/KoC1LeoRtqe/8cepnPM+Yy/wB3BEj/8AhI6nMolR16RD/eZhBjMXNR3hmqM2hNPyPtZSYqJUMP8AcvH7gpschEoXhIKzOAzAKq4Gw2ViZj8TcuXFypmYA2yoI5j5XiEq835jsN29S9GGJqDG+4UWJnmYiGz3/XL29RyVTNG2EjjMuCnO43sdxUGFwUoNZa7iBnxJyrHhJmfDNd2wIeY2O9fiFEt2wFmYlQ0S6WPUqQ4rMMbXHdQ2CrNTCsDEF2D/AOS9LviAWV6Lcy+sUXmw/wBRWnzHuH3BS5Ynb/b+o37tn6xCwQ4r3KBxEpZXiUlH+4lGpg/5KeYszy/gnUSJ/wDhjOEYHwcv1CaAA6BhxOP+xf49pixwj4nFtfomLVZZoblW5jzKBVMya+5S+oaHEAaf/Ig8vuYmIA1eYIupkLbiAKHuDq3ywN6Xxc4szxFFwFKIHDUw8Jm+n+5ohj/jBB9ts5PiOtpiZgAV3BVBamIbKSfNmEaQWFmc5ujPnMHHUyDiWGYE4l9LlI28/UopW41FzEs2zQPUa6MVljq1VTN0uC5zLU0L5jMktfMyDqVcjv2kQrzHhMPmKyZFQV5sbIweKivPP5jmEZDDiN3/AFP7jzuK6jbcty6jCiix/wAxzOIn8v8AFoWB8jv8fuIp0/5hlTmo6imDHQ+yMuf9BDoY7gJpNbhVzXDEWRTL8RfP1BviYEF+ZcvEd43OZCDujkgBjW7nMFN7gB/2Zyb/AOwKYMZ+Zjo/8lKTP3/3EW9/0RyL8axWarExH1EPsiKMvMYpXDcGFLmbjgopmFS2Tcx2kGHuapgGY4RgfBEIYLZ1eoQgb4istxKIFYOTcqitG/cYbnGKmzUQYQmKu8xCi/8AyCkTMK+7z6f9l7ZHhCaR0+4AnSb+4+hRoAKIyp8I1HHRGFL/AIY8+otzT+RjiXxH+TcJCn3TMATxb8k6ziatr5lm8VKNwXmO/jMFNdfoIse+4fjqBfuDmVK9TGV+YKnE0ZrG8QdI4eZcpv4gLxx3AKT8zViDHIQ25cZnEREVkuoQXQR0FYhYZxi3xHRl3x1MDV/9pV6X9TdH9r9QYZYqjExMOZ4bqZGrmVK4hVO3KfZfuZrBQxNDmX6ncQfUDK6Z4YbzlUoReYKFRgPNYl27RuW0PDvuIE5YjQXDMseaYRaur+4qby+JfZT1yq/FTE3cA2xKzSDM2Iw1KZU9R7DDNO42cM4uq7hn/Za8QNYKjRH3ca1GaTJjGMSXHcZeJb+AyxbdQX/jsgys+FzIz+Yt+JdMGZI5gAAVSo8S8YIZKslIn0y51mDOJkmd9w6cwVZuFByHnzAATVUFQ7gpM54mY5xLD/1KjXqIUrr+4UDq8rKR4K5t16h4ub+Ew/wZIM5o9r+omeoMSthNDEoIW1DkZcqhx+ZRrdrzGBjcePfMVLHhXOo8RVWILMLSxrZiLOcxoMfUVhblgeg67lPlqDO4RgYjGDMbQoV1NDniWbb9TFEGfzFarUW4/wCAgbACww6v1HEMWr0OJYCeZ+IbhQIsy/UYvMUUY7j/AIn5jLi5lgp5/wAv9RQbgaA3fUXEAz+4DPbQWO58an7mCw7gdG43iuJYM5l6mSxpBbH+J59yvb7jLt/cJD8S3+xKNnmWF3GVxbxCWLxm5n1UsaKgOcSy/cyL/VkL4P8AnBKJHb+oh+GMX3KnuJrtM3C+4lR0ZiEgoSYj80IaVLA5xA3DdcEIAyqncBFu4wqinn+B8RiCoRKAcSoFfBMEPHLLgs5DjLLiAwbigvBzA5rs0Ba/U5TtXpH0EF2o85MIo6iAixUPNTbgNcS8+UAOAzTBVZYSiYdSiXf/AJEayVEZ6ixFmLPUZ9fwxnMNhWb5VuGv9qFa/wDRCVeMTAoZ5XwR5CvJAtIkIR2vIwC63AYr4iN2LjbckS8B8zAvPzDV8zsIYLiXdSuuEo4SpWjOIKyomwuF0TthTWYTI4mHd8QXl3mIaEJQtzFeP2Ex/wB2ospR7X6iatwf7qP4XHaYrqK2JoAsumFCZ7nDir9lr+FB+5kriwUR2BqWxNIHzGJgxFiif8mFF58wacoQHIl5g21cAAv4gijV9wIU7dwnl5g94+oeabhtRS/gZdtH7iX5eB4B+oukIEXDHF0j65jxAhhL5hvES5N1KOT1KD+ptIqweSLRip5Io9GI7iZp/lxLjMvZD7Wpqjh9BUyfU56VU/TCFVM4LeZgUH0Rt5PUI2mfEBcalWAhUPRcDnmK2mDpxDWfqCVRcAPEC3XzHTULeWAoytyypUpeYTaty2tnHuEKgreCJvGPJNgqjFShqq9QKBJQ55cFQ3kHPEqXv+kdvwTJQ/exiPFwMXiWB8zEb+Ywsas5lgX0iLG63LV1t/UWal0qZGZW5g67meTmDS5WqvZDRSGNx4UfBGGn6iIgGV+CoCmx/EyTdyyxYTN8k4MxvyrTVWLbi6r1cKtj6MTCKumKi46HlgVxSLOJ14/9RSkPeUb0gxjk8ykqr6gJX5iqoJdSgeIW/wAy3vMWIu5uJiOX3/CVGMYFgs/EGVhxmGFS2wfTDAtpMtiA3agGriXf6gMQ43B9wyc0QV7YGf4Wh5lW+pdUGIcQFiqmuZjReSMa2zBwzILgBWcxzQ16hOU0RADA1l8QF5u/1LUCtVldkRtjh6gU5bcB/cZZr9wgFzqRALfcJAvKrcFdTLZ8ypKhxvuXsFL3CwtnOZQC82vxUpu4qUQxUIbDqIAqV2MvEIixhML3AN/cbaLRCu2No3h4ll00VXMoW3AQGJc95gK3EHcL8maHgPy+IttnsjqPSWrb5RsUCJrVTMLjZsHr1DN9RhXH/wBRUN0AzjI2SLAdblV+o1i3co0RTxBS2ZaKjWMMIxJjYVfilH5qcZ+ZX4jgNVphWTRDwMAYLjr/ALD6f47Ymdn+GYYYlsFmAPpha4f+lxYBdMe7mRt/5BTv6hMVcK7mVXmUNUFxM6zuMaXGYWy6lFDm/uUw7rUpgGf1ADDjzuYY7sv337Zgp+RlX8oLfGYuxx1DwNVcNWHWYaGKwvMNQ3/4iFU5gs7gyCK6uPWpZitRZOpi7xGtRl7bjju4VAnMKowxFaxVMWRsIK4BpcYCnOp1OWEefAFt7b+KglSn0zfb9T3EQ5ZmRfyHRKiuprJe+ZY03WUC3X01+5+l5f6lFWexUOE+4cRmX3I9h1Hwf8i9iPLDnLIqmY9kZvh/g8KJZbAZlzQ6DnNRLLdvEH3W48oRgNAn7z/cBDn7iUcznhP4u44evxZiqrouALOu5gQUqaTdz5hjcK15lZo1BgP8QOv8yllmepbgOJi5mRMqmLoktLiuaLhm6xEWcHM5MustyjoI/EdeR5uir5Yi8UWxFZ2TP7zLIwriEga4m16xFZWtpCC029YmLhYS4MsxCdpjxuBXBMxniYx34iGwM8kHa/EyKKeYlK1uFKLV6hMhwaiIA4ywgO2Y9Vo+xUfdTvLn3GcflD03BdkQoCvQErIcvNnkxEHHP6iVeiLsyx/3uWGczY2c4R6x6j4HyiOgh6fdASYDxvE8+ebLdvuU5WPVE9ShCGtAr5MfkI9R7Y68y2HJ9Mf1A7o7ljqWzx/HaL5A/EBUlad3Aoq5jcOdY5geoXxLYdWwAw4/snQuArmVSutjCOExAuKoGNFt0wFF9Q/9ZVRb5lNB+obdzFHt+DL2OpaM1+7ma3zDghV+Y6QTcWFBXcB9pg7zWYQx5GObgq5dcTUGyGyIYMRuBIrAaJbwbx6mGxXMo9ceYnPPmKuYbI5puWBBnNgQ34Xf8h8ywe4R2DOuyJ2jDorc/wDiMvzODHzFK3iURNwfcRHyajcbeIj19xGtRHrMfX8JKiXEifwYltCTyM1a9+S4BzdHBHQlS4gFh8piGGVn09zzYrnMy8Z+yZNRNQrL4ja0QdZnQ/UPtC3OfEdYcyjk41KOYgBrjmI833A3d/Uupj7ifjmYg75gwoaykSi1b5mWfEMbZm+sywD/AAQe0J+JUJ+MxKrDNmPC+4KKBzmVboVshUy31DVi3gczJB0j8Sh8R2OYd8QUhxEATFNYYOm+Y31BeDqUDG4AACFsrfEsKui4ApYxMqPrqdxGJbVf0lEDH/Kp+FM1b3PEmDBtolB2sMo0y9vMquKOGsyuR/5Mh365i9xc1iPp/Hz/AB8R1MMR9yviURJUqJ/Ak1MzWunlk/uNvVRXfmEVOL6mi8yuot1xFOZdZ5H6JZiGNQMa9zIqoYqt83EiichApbgKl5GvExydRIM+4l24gDEKeYXh/cTHBwH7mRl1xAs2XxKBbGt+Y1ZWw8Mz5qn4mPqvwiyn3mIDWI1ozQBbcDs1MKHUFiwFRi1XiZeCv1Nr6hyn9obDuWc1KCakAQAHDMwLBi+TUYA1Uwi5HXiO2drzCMLUee5e6iTDi+ZUhtPjV/lYhlHmPLWZVgcPs/4fuILhnLX1MqHnA4Qn4eIu81Hy/c71c3zGLiPOMR/M/wB6n6ie5xx/IZ/lm6l/Fk/s+YL5gWkuvKj8zA/cVvGpr/Dct65Pt/8AJ6IbYNmIaq5flM7fbDOrrgn2mndnNzN1jiHBSoRx8wN3BTdxuAUiMD/5DeM51DZeCC9+vMDNuP1MXnPULxVVz4ir2L8S1lf/ACRV5Sj2J+IhV/tRZmJcw0BzxLIHFl/EaDQ0S7qxCvAUfiJ9zeeYOZW+dRef4lgt5gybxKoKBGPSONmIBMgruG0xUaZoDUK20ZfURFt9jaf1Hn9RRW8wOJl+zuZWL1FxMXEOMRpdNRKTErr8z5leI1SMY+o7zOLxH8fypMfP8N7/AIMfLGPw3G/sh9JcLSAX8S+TnMdMXDF/EmXNWQ+D/wBhszKI4shWc7MyrxLL4zOfcGhOR5mo14ZbBn14gTor3BkuKsWZgHmOCMNkLZGJQjQgkZydkyfMQC2l8zVen4m/sfh/E7M7gcJNLzCDuMPPkm8ngZQFBhdTUGMOeI/eXfmGi/MVtmr7m8q4lUPuOyPZiGgp9wgF1zUew2RqMYlg/UELUsjyFniWK3E4+Svdg/KR1ReipmWz1HiZ+X+C1+ZxbJfh/wDIodQaZYt8wUCo/aWSzqKRY1yRrqWEf8z8RYzn/wAlRP8A8A5uX82q/Wz8MVM4T8MNHjU1f+xxfzYO/wCxX9Q/MKlWc5mBiViyZhr3C32ZlaZZdeIFE49yw5B13AsmKmjNfEyO2rJsUW9Qt3b+4G1rwgTAqEIg1WHmCKMu5eYwrWssKfL9Jknl+kOIfvZwXDZZmccyhIVHZpw/MW6b1fEa5a+Jl/k3OkwSTdzLwsRf8lDFZZi4qIBqMGuGAQzTGLfGIyje4hD3He7WEvEyhSP8lfwoynUwKzceJc5lY9H+Z4Ypz+Yg8xPzEmnmL5uPEvzLirP97i+Y3G8xzKlRqcz4j1eZ7T2jLlK3WPY0/hjtXz/5DBW4qdTF/wA/grm1zD7se3P9wcyi/wDkDFSivmY4TmUO5QZjslu3qKwHHXcY5rJALF6lbqCv/Y1U8RpwoGYOdRYfqAb68MEGMufmNw3S4a5g/wBOpoc2YMYj5Yq03FdNEVIXz9wWW4FlqP1AJzAC+Bgt+1/cwuZOY23LAXAuZar4iFL1AwyoazBkbis9QXIeqiDR+oiDIOYaLc5zMWAqUg0pB1UfmM2COmJWjK0e4ROigL7hHplq3B1fX5nao+UYWK7ixS8jc1H1H1LlTHn+Msplfw9iJ4jKgtNWHrD/AJMbNkr0jdGajzOfiL+Ci7R9mAFPCOOcxp+5m6h0dQwTJOP7gXcFc7iuK57mTS45nBgmJV+Z5NZqE0OeoUZxCymfEBwucbiyl4RUEfqFySZLUx1FCz8MP+3UYHjMbI93CwRwqO9RWGaI27ul2xMjzUTMM9xojkRcFkhog4YqrM4QpgpouF1XuO8cS/JjKCMhx4llFamEgWRCHZ1MTDRCeNwvl39CVFuW3RFC5Ev4/wDagBGrieCNuZZ3LojwuLnvxFPM+fx/F9T1HzUWNSsS959/zZUX4izGJHcYpVJY+dypqi/q4uMT1i3HHcx9iq9Gf6lWVAozMXPwTF8RLLgo7uZ2QzcN1As0saZZdwVxCbx1hlXF+olQPqLgbuGoSqwbOYGwufpNVxiBrfj1Hv5I/gYdw24AVNcS4DhySvcvZqoF1EwAvcRg3efUF6uSNdQUm94m29kVLmVcu4NR/SHU26mVBlwDpjaZM9R5vnuWorco52cVEDGBnEU6ctkCm16uE5X9Ah/NzNyvyRZVGTMFH9v9R5m0VzqA3r1PuPuU1G4x7nzPc+Zc+SL3La1LfljcuZ9T5ihuLqPcdeIwwwy/L/6fhJq2x+YtxxnWqfbR/wBg42z26gBK5qPYQ8KCHNwzq4Y3REN5LiT1HvFv7nN/iZFVmAsuAEoohj8omFLlIAOLJfQncTWRlgLxw/mZ651FSQWfcnORVfeKg1oM9Yh1iWsxUwDDBjVYuM3QGNygcXRkl1nTaVJQIzRi1upUS4vNSpVix24lyc8w6NRqKVH1L2KuEXW4DsIPmUKgE+IMv6mbFXvyP9xssA9ywJm7+f8AyVvUTiyU7zMcVEvqJEQ5zGKvMZ8S/wCXrc/25jxMO2V2lncvt9x84j5jImKdMDmaYRWmfIX+oq+Iv4ekNzJeQ/Gf7gcXDXcHYhI/8lB2+YlYOWcKhd2MATIyrahYbhz3MocMCisfEF2dGZiZXcQ1fhml5fHEEwX7i5t6zEZW4c+JTeXNQDCt/EPxqZ+hOKlDpaJ6mJXxuYBeZkuufqKJnGYbDsIgE4GiIUoiBUZabmY9QhYithWMSuLv4h+UEpDq5ZTHZKg/iE2bGA0BiApbrUc1eC8SpRcx2z+zGCTQ1GUNdokLtH2gMwAHxFfBEul/gNMiCDn3LV4l3mOf+Ru+4rLi6g5nGovxHRMxvzKX/ZZ3Lvc45f4oI05YE8xWMoXtWPDX5g/g/M2lvrdfuv6l00zF+Ilm8QaV1FVmVZUK3guGIG8MXOQisb0cwOJlWPzLvGHmH2j9DOZapfES0GRncolNwC9nUoENGc8sKFWD8y1dg8YgrxZ/M3O5zYCs4Q3tUS63PMosYDuLiUIzEmNUlEIEXvr4iLrjEX4hLfMMunUXaHXHMNvxcFHUNpk3GAYb8RlMHqO6cGIOFfELFUmPwBOyy/RPBupXgio7VfwTPYIW8IzqJeZtUCnco3G2mLjd5uL4i5qK9zL1Lu5fiXL8Qf1BKhZxDRDZieSI7Zw4HEX8GeoFzLcKv+xLm5tNofic+I7oJnmOjGuo2nnuA7gpANGZXk+U/ISlzNDuZrQmYwYIFS3MQ5cdwBPHPUdE15hwwYLMh5ltmef+SnjiKw4md/b8zJPNw6dRVUA4uDPFj0TFEXa8w62UVmEsg20GGdzM7w9ytPM51FTG0GCfYlRdwQeYmsstWqzxLbBUFAbX+JootCiKuh1MiomPhflo/H5RcojgNTJOD7P/AJBwTEJwRLziLMH8S51CvJKOyKo1GISrzEfMbiMqU7nsf5X3QbcANsFxKXMIx3KARVc17naO50mB9XmK9FeJRXzGxCy2WuViEMVibxFXn1BhX4hQPRDI6fxGdwd6ZWrXmBUci6Zg2Opz0WgVx4mAuf6iN0HOJhxZj4vXmYWNXMLdf2h+h/UzfEc3hT/SYK48yhOLYwfMoBxBdUvm4S8lnMKa0KTMaN2USwNMxmAISmYwDEqQlsrzDprETvkjQHUPeLl2lkTPhAaVdsARJGOifsMtMw1tlLL8fgjKo57iW7mwIgsTuoje5Z58QHFJEu/Ut7mTd/3L7l4l+ZhBOp4NQ8oRn6lnUr4ZeIPKB6R8z5YxenuJFc6PXPqHaX/U3R47jnMpny/Jx/cFFkRWbi8VbDOkLMMcmiCPHxAPVwilO6I8KMqNY5n0R1VGpcaWy6qtXa+JRtB83DJdaalVgZkFgzL2VNrcxYORxjiBurtLpcFP3Ffoj6izgXPLKgsxyeoM8x4jdXFYI0kFhMrzM28aqBjHL6goeYCxh5QXvmZnmDWpq7llicTjqOsmZIU5jTF5mxr+46FuuIYN1mUjix4C/wBRYrYj2lf3EMtYiIcReLf5GNPUd7MSzNtktYumch/7PBHE2YIlxU6Ys5i89xfUV1E6S0ljuKO/n+D3TwM6LhoReqD2jENhFc/hFLxUrDiMSO1zF7/jtMk5Bvxl/ZFrzAjzi/M1pllLa7lE2qGi4cqi3G7K3BdYzxDfGYNZ+5ZY9QA5wR0FP/kwuzzZFKyPEKrHEXPNwwVUp1o2KgKlfMzww14mtAUFK8XVytw4BxAlR4Ku5SHFkvbBx1CAMf3FZDBg8wAB2vxHedVDlKXfUYAxZJhWAjpKjurZlSCjPGohGLh0yrzcKIQVLuVN+TGf2ZmXR7jh6/UxrPEQfieD9RJKREeIagmLgv1BY/FwOaSCGYsqyAtVK1cYLEfkm6XEUYG4BxcFxEGj+HijhgmschH4ff8AFW/wDMs1Zu/l/wDJWJhhKQGmt6lqphg8sQafmbSjuBw11M3/AGbFOIbDmJErMJ+Y/jwURrsNvctaIYxDeRqaoL9xMBy7i21cdf66T5X9UNqXMwMPm5eTm475j/KZlLiOkXmqYaSEFqFF5lHl3s41HddwYSDeDEeATKo3JruUcNjBZvJKE4uNFEix6juzglbrHnuWqFAO4JtNeL/hCTuIR5lr2xB+YMMxYcQ+GJn+D2Zl1EvGYMXzMoYlOoFAInMDUt2EH8QfbM+ZbNOKfMyHJG3J8zLkjdk6kKcfwxZS3GZzMUzY6iIAy4IelB9CNYVxNNVEVbAoxuC3qZ2uYECnG4FZ1E1ZKUVTcN7qYBQYhUzNKKvq5d02GIeUKMu4C3iJAs5jeKrkg8VUMFrzTiZE9yrO0QU/z4/gC+SbsPEdFxBARl2uZoVpvUCbAUHuFsrDk+Ia+J26jsmIbhvMOsSkU1D5jNN3CJjRO7mCjeIuX5lVZrX2z+gjW2mNqqYKXjGNPEyy1H0iuIhisSt4lDE6gonUvdxFEJgxEdR+MXFS28yjUp5YHaD6uckqK7US5+0A4D5iGn8wHtA8y25UEBhWDBGN7mvEXMWWQWVX0Z/qBRqN/cpzxMruC3WJUrB1B2VBLcOIHw/c01AA5Y2NS7v1LbzAyi8wuWXNVAqGeIiqLv8AUxyKg0wFR4ue5g8KcxK1/lwd+UjfG1DWf1K1+YcKgBMkbpmAtd4hpdlEvK1TvEoOu7/VRKpFnxNTMRQR6qau4eAhrBEoOu4XRVXG4vBPLl4gYc+4koUREKai6qq+KrJ5lFMraP7i5z1gS69par9QNTnuol4D2wps1+YOVFVxBxcW8W+peInEfdSnuZriD4mMWTLZ8zJBDE8VzwQDj+GjmowUW4/4bGvSi62vAFs9faV/SEZlTtfzC4Nl56dxE/jDuHz1aH/ZVGWK6Ja8fcLxjEKMpe8TA0wFyMr58Qu8/wCJaJKp7lSGvUAeoyruN8Z3Bx+pks5lq3VedSlsax1CAu8m4Ve/uFsmo5T8+JkHwTIOylhHaN0oImx/Uw9pNEW7/wAS4GP/ACKkBY78Q40Yeplhv+o8PFn4gwNyl/M3HUWmoqpJiKZrrc1Li24/M5huYzJDMC4HEWS69QptrEtNCrouBzPqVfvpCQrWGVgPsfMyLmd5+4L1HsYngiBxO0wLtuHaArO5ecXKp6niy9bxuP8AjmPjL7pgVLS8wWX4Zb1F9RZxuPPU/wBqbRLlemaXL69bHxR3DPiEVCgndS3beFxcR+Gz6Y/UtV6fqeEwToL/ALi0UkTxAzB5mxxllKKmDUVBHevTDAcrBV5IW6/XEKFlX4lPyS7UoNxVR1Lhd3x6goNayQ0acv4gpMoN7hdPTj4lVPL3zKqoa9Eu2NLH1FZAPluD75jCNtx5ljTmXTRmoOTcLk8G4iqsF+JdiEdpe40mZUdeYjcdpu4XqsVElfqCxc8+Yq6NsALEaLlNWhV45hDZxCWXweIbAEH3CLK/sRXD3GBz6iYYncQxLxHpFBHuSxAoBuCgpT+LKxUpwyqruMX2RReo/EXM1rg8NFfJogRI18QQGLPuZbOZTl2j3mAiN2gk7bpU/UH2jo7iX4i7YoFebhiFoFez8w31U04tgaMEtj8yhsixisyqDuY2zAU7hRpr3LShPqUKXugxLAuHUHJS+pvQfMthSqhZTnuDY86qE0jcktTkR+I+EP3MRm7gKlLJWFxgvdXEeOJV5KjwY2Nepss89EeVziOoaJQDOXcuc94mLi5iEGMw8RGrMHCmKZnIQJ+Jxe+JcaK2QFhugVxmFrT8JbMXxLkMyBxDl/c3g5lY/qI6iInONRFYjnNY9TOCAhrEOjUNJb8xuot5iijMRF1/3tP1DYNWQVOSIeMsxQYyIKfVfxPLBJbVeoBmJZXiDMM8TGDKrnsnmrh41E9xZ8wM/MDxmsSzATDf4gaC6CI2VmDOXUPsy0KtEKc33UcwoCuJbTZUKNwVxdwBawgC1ZAAHd3uChc2tKYvp/g+ylCeSWogbw1m5gPyhaswXBgqXs3L9TJv8VMWbmLKWK4jHa3LnNzEhDOblicZga1xNTaMuxUKwrM50biaF2Qr+6Cv1Ng2o7DVn4vJLgchH4glXAYsLIgeYIuDxiChhLuZh6uV8sqrnOLfE/qLBlRq8P8ABRePzHuKV0HFymg+5olAuXl+W2G0MQEXRdJREZNY+iMlq36IlntPg0fUYq4WKmMMy5hAoq4KhPBiWC9QZlYXAo9xe81EiKR2E60wjVQg/Upzi4UD8TJfLMpinHMss1csBUvZeKia3H/jE3KAOhRG2/iAcHJG/pL5LFVhXfmKnO9wUp1Ai3TW5iY1pf5wsQtLHb5gpHzGXV1AVpgAM3MBUtsT1LKDSHPUtQ3mGeUNMNei6+Weg48kTKN4+a/5KSBEDb8iKflLr3h/H/D+cpnx6iKjfmKOIh/AM6IYQkCBdyucTEvEu3/Yi8txZuouuP4LdRlafF+EUK7trwY/UNSiViaqyMxqIVKSxeZVPm0DwlX3EIHFvzFVmH6g2xzWKlAxmDzJbVYmGAjVMUQWFYhr1DPXxHTwxjrE2M1EVZx/BgXfuLGdzMd+5ecsktdXVQ8ZYQLuWWC0zDep4zxGW9fwT7oi+5S9RqCXmB2nhgEZb5iu9Kq4b8P/ACjRNTdUE8Y3wmpFgx9R5iEFjsK/MWrxHrYgHmiBeiGhcv5KggHshGDAdAP1HMoalTzTX2A+0y70TNihRnJMIZlZxPj/ANm7x6qNvGJXLODnxHrN6CXIPUO0B3Ei9Z6mzcXzFcX/AM/gvMtIsvei/wBCVi0XhESgdMUF37ggEtPqAo7z9MVMGizxFYGESHgAhlL5Z0jY1UEo48MsLnEOaS0PMHPUP1Fq+YZQ4hbqYNSy0St1W5kUZgrYXA3VXCLV1DVo+swW2x1nBAFmPKDEVyudS5guIo5JkYY8HllxdsSGKiOUZh0dykGswTQfJ1AtRq79w6hyt+IOPDC2xPSEpEcalQeY9qqfNGMhnlmQZz1C4yMsqAMHMuRchuFbl5d/EaRvi8VOb6M5sD8zHRZa6UftMYuK3r+DdS6eJhzDjBuASULwx8Lle/iJ/qgzEq9bn+kqv/kc8RfMVi9fxLMU5j492TWX/wAH7gY1EojxiKEu/qN/uLU8tniDFq6pQigtlje44U5/iJzuL8wz7RbTxGGmOlXN6SrvMFEHEHwn0hetsqZlrx8+YbIsE5goes4YtHLzcQWfmHkx8Q2A7gUpKCFcwzp2/mKyGqfzN24sbxHajr3sX54ivcyv4gmbT3MQXRcYFuWWQ7qw6hI+b+IrdRm+pnMacyztBCwuZe6jz+bloQgGGCsYr3EuzD1ADJcwVoyBteyPc4uVgcfUtEPZP9xkZW+Z1Yj3H8yhZpcftHo3LT1BHeIdoaQLfMG9QpJUp8w8S3dxHzHnqLE8ovuMZzAKBKll5tP7iJBsB4Iwuxzrkp2rXxBtAGjuoquoq7WfwVL0Bt128S4ltT/qVCWgHEFQcHMfMC2VcAAIFJUKW+WAFMQXTLRhqWsX6juaGtTBV0cBME2yqAPmBZkS1uZgl4uV2u3MR4xBW0aaxLK7FlnE7Bn9QP8A2VfMoeYYjaC1Mn0y+pVjFa3TiUi6uHzisxmyIrd4tiBrBamjHkxxHRq5nTMHi4Kb+4aZy8wNjhNPlMS3jUuBz+pkmsGY/wBkrQHjxhPyktxQ9Vb4OKlV/jWpQ7RbTpuXodjUywc1iDcG/EPiUxG2iN+4xSPUFO4M7gyswVcsA8TP/hF8secxFb1Fnl/goiMvMOWgu9ASuOcksFo+zbUIQq0+Rf7JdcgVWU5dD0uPxKm6tcEAhY15Y7HtmsumJYxNSgczBzGlc3LQ3ub9Ra2NS7AcS11uBbigf8iHASi1LqXdwMrGosXDhbr3Kf8A1LjpMEN4uP8A9mCFXBcLXk7gqjQQ7WopOOT+0TWh8v2lbWnNbH9kWoCXLbecxDlmC0yYmpRLsTIeYN44mTmYXQSwJC1bqPNRaFRur3LhmeiJQBqWislxUp+JcqoTxLeWILMqPINidiXCtG/zCLSL1mLN8MGmqfH/AGPaBLis3DRFPie5Y+Zqf4lcQLJ6RC8R6/Fx+cvf8BQWs/8AIDHEcPEtc2izKMYMkwwqC7zY4/MrRgNkcp6BmKi+oAt9RBjbfY/5cIdWNS0eePo3+bjlkrvgio/5MNzDiLfEcJ1A1cMskF7ZgsLUXOSUcDKDcdRnP6hb1KUK5j8XXUHNYCYMCEq5Nc9S6M4HiGy0/EQLl6Ame+ZlrTEqwNTBReqY9g6UQgtDo/7Ku+UvG83FUzuVdkpQE7iFPyDqJtLOU7gU0F+YhobH1idN/wATRj/gFm5iKWLT9wzYjSplSTN0xXDxLYCsRsEK2L5Nd/uGBNgGq8viIaxpcHu5eqR5XaV+Vrw5i1D77vyfNQphwy9dQZZjE/5cx3DUqZn1UMyifwyNysx0X9Tw4jmLbF/I1FgXAsIsatZDwoF+IAIG10Ev4yBWXyxC6qtYlWhQaWbVKMsNjB1qNWSDfrqdm5QXiUQ7gwteoWOpfSIIlxxcumquacFfmVcVVMAAcHUGgxZxKkzUFOxOojv6m0cpY2wyr6hsa/8AY2sKfEGztljIoMq6lm96IF4A2Ec9XhU4ooUr7oczu4N7qfEdYZuLlOIh3UCvkK3XjuBfVzVzHVx2Rd9RvMFsxZmtmQ4jQL9TItp+ocM3cq2D9SmXEfLxH2Tz4j2DsSl6TiUzjl1fwMiwxnFyuCWjDLiEHsw9/iFjxMJuV3H/ABOZRXfcoqPOGZfqLf8AtRRRjGVLlj1djj5aI6dtBQEe5Ftd+JQaRHLMVNhOVZxEyxUDWCFYwKrzOC6lCog0Zle5YkoJ9wy0b6heyPOllnzKFA+YTF38QAhw367gwfmoAHzFj+koOblKZxFoweZQW6qWPJcU5g7xmXH1EqUAeCcKzOMNFlf0g6VdVqArLyQQtsO3EFUBjZMxCsgPzBtZox7YuGGwY8UwA3Aslrk15+Y6H4lQq6X8yjWPMtWgXmZqZSC7YGoKjn9wmrJMtGxzhuteYv5khBFg4Wh9JAo5jzn8TBuAOIl5Yt1mWO5VceZ3wwfqX9wruoMGfP8A7H2RbvMUiiiixY+P4Z5eB5X8Xq5pI818R397ls8H2AZRozMrzvmVtGv+k243Dk8ZuZMMXMsMN5JuypdW4FFQqo2wGVyxzBWofUpRUHGMQCG7Ic9zoIZar5mLACzfRAfb9xjSemdzrdQFVCdMGuckc6WFXS/UtDTKClLjNmWiwPUrXXiAty5ia+K3DSg2uKiastWYfMYCuk4jqJtKuc7mQVzF7xFVYqpMMyswj5ZjwdEIMkMBXz1DeRFifTLLO+4IpTU2LAfmWBnO/Uqgrj3CnAXzBHMpn/HmajiJ/wDZVdS2kZT5gWWMTwfMaykOIY41Bxr5l2/7M4zUWoovv+DFFix/ne5YhQEd5H9wZohWjiOETEblmDVwZ18RQEw+WFW89wtqA1Ea3Lvn/wAgb1G6dQESFbg3UaF/5lwzz+Zaun4isMcRqZJVyxbdwyxkYg4biCl3qCwzVYlUJYGviW1ZW+YnOXqpStS+pkMrv/krSm/ZDGKypoJqGrQKB98kyRZ2UBA5yV2y1wbqsQrw52cQw5uzcK5JhvEoVmVAf8xXWvuHgWXsgay/EGDJT+IAAWFVHxE6PUSptgxV5ZfyuaI2oxwKglD6ZRmaxroX9EHxHfiO9QgHup+U6Et5hZjUOIa3EiW8zGZpuJxWP5Kfw+EX/wCcN2E+jL+CBF/1RGSECzFzkspi2UJFp/qDwbmC9QyL1GsDbgmPFRBjN+GasQZyShaxD5TTKK3zClMXB4JSLbw1A6VNcl3nc28TQ4bzLIZqJUrJAZaKOPMqAq2z5h7WoQKXMqiykNxM4MSoIXsu/wBRZuZSBMerYmBNZP8AYl7HZVD6losmPiWXc03cz5nWOIheTUKYSqYxUos7isiJnUwVUIQvc3lOS5UksOY1jWYmMh3ALtjwRaf3EWtZ3FF3VxqXvjqA2ub+n9zGyZESfM+YUhAjEvOpSfxtxK5vHqF94uNG2415i8s7XPbH8FGP8EN13KaYJPs/B+YtsYtn8AVxURuJa5gHMOzC3g4gYKbxKJtXXPcb4DM27al0cxLn4yrMEHsQUb/qVNn1LtVeYKrr3LgBmVUX5lgA/URww0xFW1eo1jv+oBTvzM0f3GRcdEbqGXC6IEdhbSmn13Fi8wYQ6ija13mWu7HzFaQUG2ZQBqdMXUoQIKAK6hmy44ldOIpUViisWa6jdfuK3qvzNo3EWLj0rMbNrAOOIltR9zYshBabMyomIQAYmC5wxAV/VJDS4jlMfxzUC6iYuVWrloQfqX3+Jh5leZXmJkq7lOzEbjF3+YooruP/AOBfpEQq5WOHX4IfDMULTF/MaOJScSgnGElwIRAysN2MF4cw1PLzA7dRPXxAsLWDAGiZxVUGCah4lVBKvrxDaMsXIBwLAWyGIQvMG0BiCleIU1Rg3AG0KfoMTxwb+4CP5Oy9SwMFTYml1DADrmXKLHFEUcPBqBSCVygzAx86mxir4jWEjxNGAIWKGWIIZjwf3Mg3qaE1ZiKJYiNkrXTcBohVpHqKgO8oBQws5j1+oKyW/wDGD9wZ5l7lz5J+/wCE/wAwaq8wFwcYl+rneIvMYoxeovMXmMf/AMD1YT8s0qYDVBUINZx+YDioNcngjDRF9S2iK7iB/LLMuI0srzBVt5isqUqVXdQl84hoxhlFKfUo8Sh8Rpa7gB8zQYmlZYKzj3BcZo7jtorGszUpPmZPB/USt7H8QWmYWCUqlpucLNAyrRNnp0SlAATcsYdTJLGLR2stgxCZvzCz1LPNTC4rK6mM/KaqUSlizv7mDGZrUy9JjVsRKvmJVzfiADWFm1BUce4JXcSH/NRVEJo/Uo+JTsv3Lyqm5ipQ4o/iU5+5Tzf8fUefEWL1F3+pl/DaP/5BrDPwD+5iwVEl7riNXJvUXObzFVagvMTccT0wczYhOHf8GJgS61+Zl39xENBqUqoNDaG6/USf8RFwBHW+tQXlaPEyEy6goBEd1Mi35izbgZuVeiqNvbLcHVQJiUBzrnuUFrcK2avPcAAAvxG61KBbYYLg1HF1WIObdxxzmHLKzHvqNBnH1HjUTD9wgVXzMCZKiLF1BwH1HhHzi06ICR7WqxQNUPmK6yFYlQFwq1ETdFMO7HLCvEy/ePMbFjfqImz4lv8A9g+CD5cQb5PqVeK+mVnk+JR5Ja9Suxl43HcX68z5fMX+uLiKLFj/AAbgZlwGWn0H5uFt8QX8QnKOUyseXuFOJWzBncWj7IF15lOP3iBkeY1e8wLgx/cspLqczTOUDEFQY7iV6hrbUzf3C29y4G4beHEoDExo4lsJHyt4g0ZqCyJ+MSu1n3AAMjMWtz8ShgRmvLBhYHZMdM9wy7+Y/i4OTqFt8SwHEMo2wYu4YxKjErSzZU0eppH8RcMo1zHVdxo0w3MSJlf/ALHaLE6iLwqW+IjXoPUXSq09xVb1Ma5d3Kbq5NFOackuq+6KH80/mZkjwX/ctqw5R+uY2jfTftCnSPkYG4CXRUvB/cv/AOy/cvv9Szx9x9Mp2xrsnsVPSWj8/wAmJhbMGUna7S38soE11A7ZzFj8RujEE53uPmbbqXnxqNtY+ZmwQKbLolVhzqCBwsMmqhRup1OfzNJwV9TI4jXOvcAZck9LgNGupY4v3GqeJnbH3CdqjXjEOO3+1LBY5pqGwriUUZxuAqDjqXCXfJBbW/iAjW3UxY5qC64lNGcywd/1OIbKgvP46mo0PceVpHSjsJaC5izd3Ct9zkJQXzHhncurLu4JjkjoATtl4xrSQCZGjMcThBaAWPtLaOIIXmx/J/c0IqIqMwxTIJXYl9HMeclyVfxAXdeX+7m4K9n6mx+Jr9xRAcAvRT9wOCPpuK5IHcbDcVt5Z6Yi8R9xZc+Z6jnH96CVNLH9SrKxNj5gVgilXW2DOOpxiIdwApt8wwE07gKrcLFziLZUe/Ep8HcBZqB8EsHU3znief1Gw4gmHz5mhuUGrajDwddS0Au6jq8qfmK1an5gVb9bgbzlVz1NjeeJUCl8wMLcxh4Z8xOZitwx5MHFsXOuZpcyiKDMWGZEQA0wbCKkjj5gv+oltQYZzE4l6fuNVQqFfXMFwbiXPBEGkuy6mNweItNfMXyZdgyz6OfwspGSLYZcYzLrs844gK/fcIz8pndSlbIpcWIWi/KEAhExQsgwVd4X7IWvxAfDcuhHQn2VF0adh/ct/ZA/ua6VnFv1Ln5z/hN8ftTCWXA34I99c2GioXINHuOwttzyV+iFF0RLHfUWwceJxds4OYXZEBqoWruNswAaqZMyQb2ha4Bjj+4Z0xsT6hEzcAxf3FWKmxQ1BYmCbTKAx4MVGZB81LbPEo+n6l2MYlhV8wcFVmJYGuY8VUumM0AlY5ivH6l1hb9RBmopbOpdl3nzGYSMfc84zK08RZSlQmkoAi5xEuKvUO/1KnLD1i5RVylC3Flb3x1M/cvz3xAKU2+JQ3dRKVoI1qnzCsyCr5jirIr4ZZjUPPXNQAQNLeJQa8vUByGHibzLKrcSyCxZ6/8ACEGLWdvFy8PXB1Fdll1xK0qEeogECMbQ+pdcanOE/wDITiFTywxJlHoMv9Q0df1Fum48Z+jiA1jxN4QU6WfkhYVX+1N+UcsuoMXbKCTZ7jeoDK8ZmWCBwiPwQa6up/jAB5+IrQgFe2IisQbLULrgjoeZiqvNQ7ZFS6O3NcTQWZx8QwGitFdRWrFSwr5hS85rMLNOMXAPNMb8R6MdHjcNJBs1mN3qPDEVFws5cyzcV13FNLuCuYtTedSDB1MD8ohk35g4GK95lDmvuIoJvzCh21GlA58xW5cdR0tTQtxKUYUHz/7caiLaJruI5wnnmXOTe6mTh6mdxjqUjiFT2fMICKOxC0PGqiwN+pQN0dR3ZgNR2Dk4lHriZnmyLPjic8xYiq/E2hdj7csvfxHRxCr8x2h1qBtHEKq8wBltDcu71FxMDnmNGtxsSoOCvUxarF7ldam1cQywa+YiteZpRzDyfUQb4DECnbwcwLgYhoggJa0HwwIC5cG9cMYKKvmELvTxDmc6MRBbiGGN3+YZK8NV3LCcpEjPdSq5pzMVeKuLQ/qJZfU1D8RxFV3MD3NhPmJiMonTLq1FRFxT3OsRZmLJEHxFkpj1uNh3Dhibrnc7OJQVt3GRbiI3n/swVaBNRccSlNNr9n9w6WzAh8LCIdPfUyY5/MzYeYXbidiWGaP5Vf0Q4Kx6hsVNRZYN3KW6KJva11PQXuo90n+O5RHFlll/QGZ8reYKfMxIBUG1D+iH7RVBxUGiE6KZWYhtWB5xEx9wB6/jLuYKINtSjNbgjriACINbzLA75gWjlvmPHw+4J3ruFgYIBGq9RIDGeeo2AM91FTxa7h2u2sTIZmQIUXuMejmUap8ypxxiA7++I5S9SouVhsczFm4mpVZMzY9kvTFWck3X3cJJYeoguHr+JXvMHiCBLpNosCsSbjktp/Md7ZlIBzEqjoY8+JcqXmIKR8RubQPj/wAuXmFzqWedkyOQ/ubLapuHGcee4XI72Q2t4lmDa/QH9s4PWoqMaNTAnznmJbTxvllS5SpdtmXLrMWEjb4jz6jLlzpvy/1Fm9pHSdPco2UxE1RDeLoOI/pwQUY9xVWCGz9Ki5xn+o6ERYcEQlzBZyZVhUDRj3Fuu4lB1O2Dqv3ApnXMqAr1EyYx6gsHu4Erv9zLgY79Gbmjz4m5rDBNCtOZWxqvEDrd+ZpVzqADR8+IxmDwguWW6PuAunHEu6i3mLkgbSarojwYljwj4mFD+GpFeY+4Mu77lGJoSaR23f3LlazDSXqUUuoqLf3G1v3MVUTkcsuzbAdfcAEBYp8kKmyz+HEtGOSsX0kSsB9RMjT5hu/HczOpq9IavJ/U1/EscGa3ELqZVnMwZYWVR4m0ZkczB5i2sVGXyxkCvkGX6qeajUuqm5wNt6InG4AXx+4KYbs15JQL1AMxC5KltwNbgaGGaKhh14i4RAYNOip5Iixuv7l2VgYF4plWahYbtwEKb4ha+XxcBdFFYl6VrvcEu47ZeBVkKxmLTDVwyGMRGlZeuYDeNOYKxVAK+54Lhk1AWKm7cRXk5iLdYJ8iL24iz8QunGZZUeZgZ5nkYlWGIR5lZuGiNxU++48jCk04lgGK4CiWarEQ2PiYTLHoVzELlkhrBh/Iw/1MCvSOwzn9T0Sy0KhU2VAWTgZh+q/zT+4sGarqNgXdstVuP7OJkpu+2UFCibW7uXvxM0COZwr1z+It1Xg6JWp8SC2xyYhNeJRnMV91BWnMtQ4juioO0+RcXOSWspgxkxBK2/wAOJqCZYqMU1KLrE9EORxL3nNweh+pRGxjUJDqOXH1Aex/MQoMXRF6YL4vUMTVRYOPEbw1HJcWvErBjzFp1xHzEMKF4iDMNqwKg3ppjxfxKXVsaQr51LCLBFTFbuKxIep0Z4v/AGWFI29/+RJhCDqwSPgamPjxLXv3FxeJ1KxMN4m3P/JWnM/8CBx+6jBLXcLnPcvpQIMWdamqOajee/JqCOAxXomBz8ygNPgZnUNfiYUoOZgX+JdcF9EsYsxaJbpjB9H6uC8Vc0Q3L8j1Equ+YawcRUZ5+4GgagqrSvEoOo7lOC5ealBDcslGv3KHcGypve5gJggyuueZQm6fMJxNMFpvxFwl9tx8rdu4gVwXNXjMzbf+yzw/1AXTXqYbLdwU7lGyvUNhWdwXK8cxjNc7jO9xQoSrLOC5d0dRvUwhhvxNHlizBgqUqKrjwZjxKo4FmZgzFMSgwy+uImE2MSojrrEeisMbo17jXFTUrXcfNZmYqnzMc5SvZk/UVUe4qcX+4UVxZvuGr77YvO4D94X4TPPO5yCUGf1ASrv1LO9xcnzNncJuWOeI/mLMu2Np8DB/cdrx56lrbNxZdYalerqYGvqUuteYBkxmXH8Rcp+pdWDE04lWlDVGOpXRLVRCbWNr6gGiB18wujUpaEIgDuKww+IAs9TA3+p0JLDIJ3zLNle+o11iPS8xGuZSGrTmCyuiIVbYiUpPUQ1v/spNMIh21BUBv31CjnLAXUV5jghmrxOhzEy7lcQsI0GO5mdzKsT0hRsi+YLD4+585hiFiKyp3KH+oSgRKY/csSs+oh3c0R9WXBgqDNxZLJ4GL6MrrZNgp7vcCwv1AS7vid+xfoX+pWhfG4rFuJSQo/5M7dZ4JbZfmG35llhhlrvmLazzmJprc41HPdZ/MF5bqaqlRelv6jHCiw23dXNnUo6GpaXG5XmF3GBim4GbuXR5mTqWu7bZhM0KvcBrEF1jUPPippjMDlxzAtwmYsWcOEmOR3BTarB7HEoQbAwHGo2m68y6gnXqCCsZgotFnF78QSqX/cVAgHqV4ZklwJkzUMwuA7vb3KvvmXYEGsX6jZuo7QNMNQDcqWb8zEhouXPmApDRbOOiVKguD+F6ZqAq4QbmNLKvr9ytHEHgq4HqIl4/5Go1UC8std2SruR9yJWOI1rfa4+RvklDS1Oc/oHHQ46iUcX3DLvAZm7i/G5V/wAlnMsgDeZZGc+A36Mv6ndxc1qZaL/UFs2wtm9dZlzGnCLgqAbiBF0tRUo3GiG8zC3iCUGFHW+pdsQFtuK6g+SIYb+YqRv+pdoLYvbbHXua4LiNih6IgmX6hBzdS1w54hQXjHPU6mu4tn5ZVoEsGD6l1e7HuLeagUsRpuuIhxpIdm+o0d3LtvxDKvEaGYrEHNzoZUPEWaqPB3MUWJkrmGTuFCos3NHvcR3iMXealOc+ISEEGSZpVRYI13CN58wwTJRzHRS1LnXB8j/7AA52OoUXVdxF2b65li5I6ruPvLg/EouufMqs/wDKll5MzNd/EysRj3+JVHuLjkzMmLPnHH9sDfTPFsNxf+Q0L3DCKhv4iIvB6gRxFzG11LyxU+Yq07jcW3EAoxTLBhjl5YsVHrE+eLd3UzynNza+oQIk8X3MxfESKagru78xw3nuFqSgWGIfDMxlDEACyvBGOxN5uNdpd4uZK/UR1BRVhnMVGWOe+4g0+4Nkc8RlK2S+J2mav5DrX8GCgNJR5g58Mc2uLORCMQJ4NQgW4ZZmsXghGsxrVxYjZdc4fmd2pfY/8gRYqxKiIOLSK4fGYR+SbW0gr5xKb+Jlcnce3N/FTC5iIm/ES3UcvuGdxK41NmcZ1flf6m/Cw4QrP1KtOuIjb8RpN46iX/FiuifRM47c1KvUS0viGMTbiDXiZJkNbjR3AXpjaL7itpIWA8wYCZZTw9wSg58Rpo/E84/UQs/mN2brMug8+4IUGgpfUMQA3NC4014gKX0ETAfcO2qtuDozAnm2UOMu43f9ywqdPBA5zD6RcdpM3FrmLQjtlFjomT4ltY3KNuoiDDLFTPBTEqFy7hhZULvHDChSrKAqPp3xEWUYius0dwjn1KMQWLtQ/mOB0FxqsbN7lF2tecwi1mWZ1XyJ/cZTcWG3jQzkEqOjkhVlzEq55gzqGNYOZR7fxpo2q+ACBFwSlOPcdNuJgxM+oi9TWoMF/mKlC4usVKQqkqXbQ3GxqocaxEEGA3vE0+5hxADmK3+oOsxMBIABi+pYFh/7PBUoXYY/M/JiJCitZJWvBtlm0NworMC8jx9zN34hkeJTF/V4lM+8XE4DjcErqt5jVO6mRlhfkxExQ61maKhm4lBUtcXcCpyRDGBDUtyx0545hRvEKrEdq5l3FbjoLcwpxYxV0MTAkLriOg3UVfEdK3KAZqyfMbzCC8oKnr1FuC+Y7rk6qLrG5RWwvpKicmI5Syhqoug33E2xnqZ0xBAvMFr6gafiGrzcOWdebL7UxyR2urcRQby+4xVb/wCTPnDiOs4K1iLKzEefFT4IawaqPzEVYFZ5/cV2mmZoqW/5gqP4H4JQQC6mVCwwlI+XmMtwzW69VBRzwbeY0DZX6icoP1XqaZ+ELsTPmWKpnI5zK61cF5H5luBpLz5jbWf+woZHiORmDTzDJ+4F/wDIXbfzKEsfiZjmHvEtl01OBiJyzCBibZmEF8waZvrEGvc0iYcMqy7YY1CyMFu3NxgjMstsVJWJqp1MGfmIrmYU0Yjy0OYZRqyvcsIW4r6lEXa+NQWaU5slWGjDB68fhKW8LBUv1UtbDep2NfUsI898zSFLMO7m8L2z7tmTqK3bTiJ13C1pzCHuBNfENmoPPzNtw+JTGHDcK0xHDiUnNdQ2jWAXxKNQviK9sx1u/EFviPldRjYwKiJXOILZX3AsK1ecxOAKO4wpRivxCsuEsgmYGM5j5Zgtcu4KrAfFxCmB/wCSxBuN33BU81hg4Ri6MxRjQgtMVsgt2XMSwltGYHmZvzA/EUPMVTOJkdEC4NCjHpOEtMGpYeIrp9RSlXEKXmKyjH9xZOanUjoCs7jtwZ9x84u5uGT0Iy3K75e4jRPMsHMC4wn8CcuUYOupQLtfuWrnUVr8wcS7jGoIbpmO8xC+JZ157g2BmHtFjCl+vMx733FDhgGsYtqFzAk23iOks4vmWun/AOR4ruBseIC8G9kFJicIs5GIvdzR3EHxLWcdEOBslhNwKt+eoqxi/MqloVHgcXioYbhUC164gnWKwwWvXNzQGYl6OLl5uruUJGoBHR41BQKlrlM8XrxF7gIOY5ml8wcJ/Abbjoqdx9wt7xFTv+IqoJXiGzMy5hl6izwRdR1LEviAZY9X+JfSNe5qNYj5zMXNz8ESt5YshxCV8TLT7nMgvsRPKjWvriMiVUoQY5ijav2pp+SZpS4gWiV3Eq7mWSFW6gAZpWEBJmuYNyzMpPTk/f4nLP8A7MaxnjxDPDzBS6mbdQ3uV8vBDealBWIq6bmh5iYgGdkbvX1zDDA53BcNsDaIOMjBU1DLGogs2TldbiS0NHVXBQayb6laI38RbKjeItuDEeijl7mjRmoAiUe5oG+oQvOmZmyzibt0gcS1TUC237gjjiKD3FjBcyltxWsxaK/EWdotRWU6la1fUVjEZeY7qK+ZpMKiziIe4sw3qol9QhWRIanCzRhxFSsR1OK/iK+vcVV24ltGYl8BAK+bkFQWzmZ4VfiZTsHcE3R4lBgD6dP95lsN2cTBQZjj88AYlAtjcMzAdTUly3zL1P0nJ/ZFekBd1NA8yrF7jvcaOPt3MSBUGOoA9DN8RqYb8xMZi8ExRtCW3e4Z5jnTzqOFrUz8oOb+4qdb5gvJXcFckxJZnZM+KGY1Layy8wVBHQ5x5ImikLFLOFxQy2bit8/uBKFf+wHKvETdoXzEq+onjPU56/hs8zJ+Zk5SPNeIpHCbZoTRuOhjxGx4i1G4xAGbbf4k2qmVuruBTfiO+GYFG4LCqjLN/MZXqPmvqPR/iMUUr+5ejuGUzG3/AKZjK7s5hDdVBqtQi4qJLEDY+Zv8GLjkStK+YHDGZCYrJdYeCLD7v+N31G1UZPIzVYgf19zfzLF8+ZkMNxs3Fz576iDmHGliLvNyj3j7gotuXR4hgY3v9QcP8S0bSbp56iU1OES3OxqC+GVVRW3XNTBsrEvTmZL58RW8XBVK2uJe4Qdtc9yx0f0izTEof4EC3EDFaDrMCgEzr3F4XzLb8k8ib9xQIHxMt3FDRGqCVcyWmH7jiZMxKJ+0OP4YQLq5gRU7jhligxYolIlmbg19ytECAcx0KrETkH/sOJVlQ9ylDbRFjX5jzDpXpfuKlDRLd4dSjstqJzf1MxjG5WDs0P0yiJ+5iix3GK/c4rqApTmBv/ZhrPmDMwJUd5n/AAHm/uPOPWZTRlgt3BVdnMOfuObzzLMG/wBROZarLitqOADuK6xHBYR3dRKrBpNyqNytQOGpSrblFv8AAmxxCrVvZKAtqYJjl/U5rXdwjJliTKwFFkNTjGJ+fqKldfmY3bPNwiGiw3KCtafxAob51F8FiXGyHlzDLXX5iZeZkNmZmsT+o8o2imMyt7iz/BUkdkLqGoSrMTCDfMMcxqk7TRbK/iXC3MVkvZmNQ2TpicHUsUAm1gFRa9n7o9n9w/DuoVPf5lywqUcszHFp8mPyEempftHL/wAlg18y3WZW/wBiHKXnuDNQY1Dl3K2tCv51+ajncfBfxHtlqKoBxT4lN+WbFHubdMw8s2mvcyJ+SEu7qoAfKHBZMOJ155g2f3BjH3BTJLsuYO7xDYalrXHYXxE2Eq0TPuYizHdxMY51K9jmUI56S4tFKH9yzY3mAoUicdy/LnmKoIILl/UW31GlItEdMXGZgJxqI+5yuaE3JzqOt9zvFqtRRZgzuD7i8y5NV1DGDFxZMzDBmCXUeJ2N/qMUOoTn+4FJgviXD2Go6TH1M9yo6zj01Bw1u5YLEW/64bZqG57BshipKPSXNgN9JkKtqvUub4zMa1AtauZo68QUuI0nyA9kOt0PvLj/AMnMQVmJ1M3Fb+ZXJPUf/sTZRHJiYvnMxqLduZVsTBUWdxDipdU7lGnEdO4rQl6rzUGn2y6wbi+UGgEI4fmN0JUtUM1uDUojN+4DrNa/9itvcyINXj2Qixo8EwWyqjxBFGzRFqbZZfyxZqeGYKixpbmIsTWMCtxZPcWKmuNwoUTSZwl5io9QzKWyrmZPfzCiQxH6lXBLnHEqCUWBucxhDRlic3Lb8TSzrEHW63UzIXXMVuvXiWWeYeXiKbbW+Gz9/iZCxOBz3FEt16lbzKMEBbOk2h3LAbfzFn4Y11AA4MTQ46lhF4/UBDtiB18TU1Kl/wCudI4/aY3+IZl1/c9YljAcJdpxB0y1lcEtXzFZeZdhgvG+pQwUajUta/cpqVNGHlhln8Qu8fEV4XiLQfqUau/1KaJedSiBIBppxP/Z";
const MAGAZA_BOS = { alimlar: [], zekat: [], erzak: [], cezalar: [] };
const ERZAK_FIYAT = 50;
const AYAKTA_UCRET = 50;
const CEZA_RULET = 50;
const CEZA_KUPON = 100;
const AYAKTA_BOS = { tur: 1, kasa: 0, girenler: [], canli: [], elenen: [], kullanilan: {}, secimler: {}, girisler: [], gecmis: [], cozulen: {}, baslangicHafta: null, sonHafta: 0, turBitisHafta: null };
const RZ_MUHUR = "Yapacağın tahminin aq";
const KARTLAR = [
    { id: "gol", ad: "Gol avcısı", kisa: "GOL", puan: 3, acik: "Bu hafta en çok gol hangi maçta atılır?" },
    { id: "sifir", ad: "0–0 avcısı", kisa: "0-0", puan: 4, acik: "Hangi maç 0–0 biter? Haftada 0–0 yoksa puan yok." },
    { id: "surpriz", ad: "Sürpriz avcısı", kisa: "SÜR", puan: 4, acik: "Haftanın sürprizini seç. Yüzdeler maç listesinde." },
];
const ROZET_TANIM = [
    { id: "kahin", ad: "Baba Vanga", acik: "Tek bir haftada 4 tam skor." },
    { id: "surpriz", ad: "Wow", acik: "Sezon boyunca 8 tutan olay kartı." },
    { id: "banko", ad: "Hz. Banko", acik: "5 hafta üst üste bankonun tam skoru." },
    { id: "kuller", ad: "Küllerinden doğan", acik: "İlk 10 haftayı kupon klasmanında sonuncu kapatıp sonradan ilk 2’ye girmek." },
    { id: "baron", ad: "Portföy Baron’u", acik: "İlk 10 haftadan sonra portföyde en az 20 sayı farkla tek lider." },
    { id: "derbi", ad: "Derbi kasabı", acik: "Bir derbi maçının skorunu birebir bilmek." },
    { id: "kartal", ad: "Kara Kartal modu", acik: "34 haftalık sezonda Beşiktaş maçlarında 10 tam skor." },
];
function rozetAd(id) {
    const r = ROZET_TANIM.find(x => x.id === id);
    return r ? r.ad : id;
}
function rozetAcik(id) {
    const r = ROZET_TANIM.find(x => x.id === id);
    return r ? r.acik : "";
}
const TRANSFER_SONRA = 17, TRANSFER_GUN_MS = 3 * 86400000, TRANSFER_KOMISYON = 5;
function gucSkoru(idx, takimlar, onceki) {
    const t = takimlar[idx] || { gp: 40 };
    const sezon = Number(t.gp) || 40;
    let ligP = 0;
    const form = [];
    (onceki || []).forEach(h => {
        (h.maclar || []).forEach((m, i) => {
            const sn = h.sonuclar && h.sonuclar[i];
            if (!sn || sn[0] == null || sn[1] == null) return;
            const ev = m.e === idx, dep = m.d === idx;
            if (!ev && !dep) return;
            const gf = ev ? sn[0] : sn[1], ga = ev ? sn[1] : sn[0];
            const p = gf > ga ? 3 : gf === ga ? 1 : 0;
            ligP += p;
            form.push(p);
        });
    });
    const son5 = form.slice(-5);
    return sezon * 0.45 + ligP * 0.9 + son5.reduce((s, x) => s + x, 0) * 1.4;
}
function macOranlari(maclar, takimlar, onceki) {
    return (maclar || []).map(m => {
        const ge = gucSkoru(m.e, takimlar, onceki) + 3.2;
        const gd = gucSkoru(m.d, takimlar, onceki);
        const diff = (ge - gd) / 14;
        const pe = Math.exp(diff), pd = Math.exp(-diff), pb = 0.92;
        const s = pe + pd + pb;
        let ev = Math.round(pe / s * 100), ber = Math.round(pb / s * 100), dep = 100 - ev - ber;
        if (dep < 1) { dep = 1; ev = Math.max(1, ev - 1); }
        if (ev < 1) { ev = 1; dep = Math.max(1, dep - 1); }
        if (ber < 8) { const fark = 8 - ber; ber = 8; if (ev >= dep) ev = Math.max(1, ev - fark); else dep = Math.max(1, dep - fark); }
        const tot = ev + ber + dep;
        if (tot !== 100) ev += (100 - tot);
        if (ev < 1) { dep = Math.max(1, dep + ev - 1); ev = 1; }
        if (dep < 1) { ev = Math.max(1, ev + dep - 1); dep = 1; }
        return { ev, ber, dep };
    });
}
function gercekYuzde(oran, sn) {
    if (!oran || !sn) return 50;
    if (sn[0] > sn[1]) return oran.ev;
    if (sn[1] > sn[0]) return oran.dep;
    return oran.ber;
}
function surprizMi(oran, sn) {
    if (!oran || !sn || sn[0] == null) return false;
    if (sn[0] > sn[1]) return oran.ev <= 30;
    if (sn[1] > sn[0]) return oran.dep <= 30;
    return oran.ev >= 60 || oran.dep >= 60;
}
function haftaninSurprizi(sonuclar, oranlar) {
    const aday = [];
    (sonuclar || []).forEach((sn, i) => {
        if (sn && sn[0] != null && surprizMi(oranlar && oranlar[i], sn))
            aday.push({ i, y: gercekYuzde(oranlar[i], sn) });
    });
    if (!aday.length) return null;
    aday.sort((a, b) => a.y - b.y || a.i - b.i);
    return aday[0].i;
}
function kartPuan(kart, sonuclar, oranlar) {
    if (!kart || kart.mac == null || !sonuclar || !sonuclar[kart.mac] || sonuclar[kart.mac][0] == null) return 0;
    const i = +kart.mac;
    if (kart.tur === "gol") {
        const g = sonuclar.map(s => (s && s[0] != null ? s[0] + s[1] : -1));
        const max = Math.max.apply(null, g);
        return g[i] === max && max >= 0 ? 3 : 0;
    }
    if (kart.tur === "sifir") {
        if (!sonuclar.some(s => s && s[0] === 0 && s[1] === 0)) return 0;
        return sonuclar[i][0] === 0 && sonuclar[i][1] === 0 ? 4 : 0;
    }
    if (kart.tur === "surpriz") {
        const s = haftaninSurprizi(sonuclar, oranlar);
        return s === i ? 4 : 0;
    }
    return 0;
}
function kartEtiket(id) {
    const k = KARTLAR.find(x => x.id === id);
    return k ? k.ad : id;
}
/* Tam skor 5, banko tam 10. Banko fark 6'dır; Baba Vanga'ya girmez. */
function tamSkorPuani(p) { return p === 5 || p === 10; }
function ayaktaNorm(v) {
    const x = v && typeof v === "object" ? v : {};
    return {
        tur: +x.tur || 1,
        kasa: +x.kasa || 0,
        girenler: Array.isArray(x.girenler) ? x.girenler.slice() : [],
        canli: Array.isArray(x.canli) ? x.canli.slice() : [],
        elenen: Array.isArray(x.elenen) ? x.elenen.slice() : [],
        kullanilan: x.kullanilan && typeof x.kullanilan === "object" ? x.kullanilan : {},
        secimler: x.secimler && typeof x.secimler === "object" ? x.secimler : {},
        girisler: Array.isArray(x.girisler) ? x.girisler.slice() : [],
        gecmis: Array.isArray(x.gecmis) ? x.gecmis.slice() : [],
        cozulen: x.cozulen && typeof x.cozulen === "object" ? x.cozulen : {},
        baslangicHafta: x.baslangicHafta == null || x.baslangicHafta === "" ? null : +x.baslangicHafta,
        sonHafta: +x.sonHafta || 0,
        turBitisHafta: x.turBitisHafta == null || x.turBitisHafta === "" ? null : +x.turBitisHafta,
    };
}
function takimHaftaSonuc(h, idx) {
    const maclar = (h && h.maclar) || [];
    const sonuclar = (h && h.sonuclar) || [];
    for (let i = 0; i < maclar.length; i++) {
        const m = maclar[i], sn = sonuclar[i];
        if (!m || !sn || sn[0] == null || sn[1] == null) continue;
        if (+m.e === +idx) {
            if (sn[0] > sn[1]) return "G";
            if (sn[0] < sn[1]) return "M";
            return "B";
        }
        if (+m.d === +idx) {
            if (sn[1] > sn[0]) return "G";
            if (sn[1] < sn[0]) return "M";
            return "B";
        }
    }
    return null;
}

function ruletNedenYaz(neden, takimAd) {
    if (neden === "G") return (takimAd || "takım") + " kazandı";
    if (neden === "B") return (takimAd || "takım") + " berabere";
    if (neden === "M") return (takimAd || "takım") + " yenildi";
    if (neden === "yok") return takimAd ? takimAd + " oynamadı" : "oynamadı";
    if (neden === "secmedi") return "seçmedi";
    return takimAd || "";
}

function ayaktaTurSifirla(a, gecmis, hafta) {
    a.gecmis = (a.gecmis || []).concat([gecmis]);
    a.tur = (+a.tur || 1) + 1;
    if (!gecmis.devir) a.kasa = 0;
    a.girenler = [];
    a.canli = [];
    a.elenen = [];
    a.kullanilan = {};
    a.secimler = {};
    a.cozulen = {};
    a.baslangicHafta = null;
    a.turBitisHafta = +hafta;
    a.sonHafta = +hafta;
    return a;
}

function ayaktaUygulaSonuclar(a, h, teslimKapali, zorla) {
    const hf = String(h.no);
    if (!a.cozulen || typeof a.cozulen !== "object") a.cozulen = {};
    const picks = a.secimler[hf] || {};
    const ilanlar = [];
    const yeniCanli = [];
    const yeniElenen = (a.elenen || []).slice();
    const oncekiCanli = (a.canli || []).slice();

    function kaydetCoz(sl, idx, neden) {
        if (!a.cozulen[hf]) a.cozulen[hf] = {};
        if (a.cozulen[hf][sl]) return false;
        a.cozulen[hf][sl] = { takim: idx, sonuc: neden, zaman: Date.now() };
        ilanlar.push({ slug: sl, takim: idx, neden: neden });
        return true;
    }

    oncekiCanli.forEach(function (sl) {
        const once = a.cozulen[hf] && a.cozulen[hf][sl];
        if (once && once.sonuc === "G") {
            yeniCanli.push(sl);
            return;
        }
        if (once && once.sonuc !== "G") return;
        const idx = picks[sl];
        if (idx == null) {
            if (teslimKapali || zorla) {
                if (kaydetCoz(sl, null, "secmedi")) {
                    yeniElenen.push({ slug: sl, hafta: h.no, takim: null, neden: "secmedi" });
                }
            } else yeniCanli.push(sl);
            return;
        }
        const sn = takimHaftaSonuc(h, idx);
        if (sn == null) {
            if (zorla) {
                if (kaydetCoz(sl, +idx, "yok")) {
                    yeniElenen.push({ slug: sl, hafta: h.no, takim: +idx, neden: "yok" });
                }
            } else yeniCanli.push(sl);
            return;
        }
        if (sn === "G") {
            kaydetCoz(sl, +idx, "G");
            yeniCanli.push(sl);
        } else if (kaydetCoz(sl, +idx, sn)) {
            yeniElenen.push({ slug: sl, hafta: h.no, takim: +idx, neden: sn });
        }
    });

    a.canli = yeniCanli;
    a.elenen = yeniElenen;

    let bitisMesaj = "";
    const turAktif = ((a.girenler || []).length > 0) || oncekiCanli.length > 0;
    if (turAktif && yeniCanli.length === 1) {
        const kazanan = yeniCanli[0];
        const coz = a.cozulen[hf][kazanan];
        if (coz && coz.sonuc === "G") {
            bitisMesaj = "kazandi";
            ayaktaTurSifirla(a, {
                tur: a.tur, kazanan: kazanan, kasa: a.kasa, elenen: yeniElenen.slice(),
                canli: [kazanan], devir: false, bitis: h.no,
            }, h.no);
        }
    } else if (turAktif && yeniCanli.length === 0) {
        bitisMesaj = "devir";
        ayaktaTurSifirla(a, {
            tur: a.tur, kazanan: null, kasa: a.kasa, elenen: yeniElenen.slice(),
            canli: [], devir: true, bitis: h.no,
        }, h.no);
    }
    return { a: a, degisti: ilanlar.length > 0 || bitisMesaj !== "", ilanlar: ilanlar, bitisMesaj: bitisMesaj };
}

const TAKMA_ADLAR = ["Meto", "Fero", "Josh", "Buzlulatte", "Lort"];
/* Grup avatarları — 132px, gömülü */
const AVATARLAR = {
    buzlulatte: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wgARCABgAGADASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAwUAAQQCBv/EABgBAAMBAQAAAAAAAAAAAAAAAAABAwIE/9oADAMBAAIQAxAAAAF/JAmMqvGgZW3c6qNbHK00L5X0lZGq6ai5imxSiCNGpZAJ6pg2PPAdFMZTnq/PFTVPinBVjSVT5NmZoNdkGTnLyDwkl+ZMFbvnXC2Sbk3IcfGdsAXY+WYN1eeSTefCuFBM6F2bKDixAnXhosK16U4yUjJIzwscrwzSuUXY4F9VGNvTeH9WG2Sw/8QAJRAAAgEDBAIBBQAAAAAAAAAAAQIDABASBBETISAxMhQiIzNB/9oACAEBAAEFAryz40+clcNccsdR611pHWRfGV8V2rGgK2qSENQL6aSKQSpeeYgliaFwbOgcadWhluejH8VszEV9QyHoiyndbFe3OMSfE+t3YsTvFGY2r0Y+o7SFg7Pm6ev4zsiNlIvxV25K06vy2TVvIdQcIkqI9A0+NDYCYhaYBhFHheBsZdX+tTUb7GWYKeZMYpRJRGTQr93grc0HohqgjUq0a0wwMZASNdl8I3MbTAG0MgA2/LJIrmKYcqMHXxDFa6NdisrCtHPg95dKuTwSKPIVpZeSK3//xAAfEQACAgEFAQEAAAAAAAAAAAAAAQIREAMSICExMlH/2gAIAQMBAT8BIxs2ocENVjTVvsqsIlG1jT9EW66F36N1iPyRZaPSX5iLofQmqNyjwvj/AP/EAB8RAAICAgEFAAAAAAAAAAAAAAABAhEQMSASITJBUf/aAAgBAgEBPwElKjqFMTvE3SyyMqeJ6GLY+wliXkSRTNC+4krNnsq+FFcP/8QAKhAAAQMDAgYBBAMAAAAAAAAAAQACERASISAxAyJBUWFxMiMwQrGBkaH/2gAIAQEABj8CrDcu/S5nErZS0uHpRxRcO4VzTI1Y3OqW/wAjug5uiGoGZDtWVH4u/egkp2K8rbivqstHdSDioNT7QHU1hgVnE/1YPKat9VNmxK8IUNm64d3zG6yrZIR4ZMipDQ0YUD1oysIXCQOi4RY2CdwvJqPONELAyu1J0wd+tZeJJWIKlpMKe6zudMq9u1IKm6AvCaXjlHQK5pka8f1pg/F2h9mLWypiRE4+xn5Dev8A/8QAIxABAAICAQQDAQEBAAAAAAAAAQARITFBECBRYXGR0aGx8P/aAAgBAQABPyHrmmBu9f8APEeoPHH1MtQfZSjf0AYZEnclC8Xr3Cz6hJjcyIPYUz8pEJVh/nZkNjxMqAVbs9Qw10oiyiiZkvH8cOxGZZqVbEArTxMicRak9HEAx00JYBK0kuORDfHzxKI5L62elV82y2AN1f2amCpG0Y2hMAWPAplAu4ojUMD4hpO6dVWlkL48v+zN3YwT+KJeEPzd7qLDmxpBzOiCaAf7BNHLvwdQ63K2z9lbAql9YZuJ8YcTUebEukaPmxAK53PXPtZIbL4elUwds851Nygt5zcCtLeobt5CZiyhvtBtEr9TLDsiDiLieZxOEE45jDQNjicIGUb5g+uziCTrk8k5XW4bnGSbDybgErDbyw1108UHWjnu0GuSJk+6CsvVPTBJm/yenz2PNtau73+RUqATwGJElSpXRZlXa8P66//aAAwDAQACAAMAAAAQ87UsoU8KsiU++/dOReazZsP8l5p2jAsr/e04/8QAHBEAAwEBAQADAAAAAAAAAAAAAAERMRAhIEFh/9oACAEDAQE/EOBExgxo+JBGDxIZNiuDQPWx0fYWLom/OKqa0mRejUeDNb5f7gjeCCeUscG66+4jL8P/xAAbEQEAAgMBAQAAAAAAAAAAAAABABEQITEgUf/aAAgBAgEBPxDAXEOwBZhNEW5tgQjYDcCiA6lVRyXuLUHkughyG24Rwpa6Q0uU2ti63ArWLn15f//EACcQAQACAgEDAwUBAQEAAAAAAAEAESExQVGBoSBhcRCRscHR8OHx/9oACAEBAAE/EPqT2gPKrb7O9S0u3JodmPzEqht9prI9QPtqCx25Kntp8TXjZOHonD6qkiwTkBtfH5o5mmumrbc7V5XawkyTGhfEEnSMAeFmT9O3R/uY/Z3jtcj7noTkxUjpXnPAa92+kAxcFum7f57fEqqdCXTNxMQlWvmMr3RNkvYPvXAWq9wT7eg712AbW2UAEiiqo6mahgO8YHyYgCayQ/sM0TJs7TBrF/mWxBlroM+RB1Ih3L+qUktt+ijtmLgYRlnal1HMyHMYPNSae6HmCTcVqnTlE9xiNQLs6YigX1vUVwVtZ7Zj4ILjpj6nM84MiuxfhFpLYOnXvuMKoY3Yh01KWw5rxK8BJwoxQ+IdMDlnBECFeW4Kct3Uz/O8PoLFWWyuBMfZ5l8XgN593v8AuBTrBzsk6qI5YpeOswqttzfmNB9foVQt9jMxInOaKxjrenpcpaEVdDQex9SY6zHzrzUULjX8SutykDV+CB23LpQ/6igQAFaOLhAQGdhgCqIEzu8QzEH3K/o8+h3fWMJ/4j9vvCgqSkes5XYn4cv4IYVEyCqeyS11KyA7p+ZmfkHp/ZcxSUeB2PQ+GZkB04OhKhKPZ8+8eN+I8K14hVFci2fiCJ33oigTclW4a5rpDsDwP9h9KcfaMLmtumNW1e0pPjrFFWfOIo0+8tdR2OkYs8C2tB+j26egbHacU6ZyYgGqqrLFLzwxByI8jLdRUIKVNYgB5OfiVkeTZTjuPN/X/9k=",
    lort: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wgARCABgAGADASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAwQBAgUABv/EABcBAAMBAAAAAAAAAAAAAAAAAAABAgP/2gAMAwEAAhADEAAAAd/GJhJliKS7UrDC7WONHs5ytS5no4PMBruZaVhwcWoYlVVRlAnn+pwNffBmOm48xrps47EBUUt3s+gyEVaaA4qnU+rkZNcsXN0g56NhN0WusZ4eeWtgIBjprRNj6O2C1DVzsYrrrQl7BAEzVnSPQQG9Ri0BHXc0GeZtEji9KEmeAteEi5gbN5//xAAmEAACAgIBBAEEAwAAAAAAAAABAgADERIEEBMiMSEUIDJBIzNC/9oACAEBAAEFApfzMFizzHUNiUcrb7eZbjoHjHMzmYJg47mMj1HjcnuHryXzbVW1pXjKAaUn06QKF6MAwA7F3V/k1roufs9TdWa8eFB2p6MuLoWCDvoZ76Fe5YzVLHtXTh3Ka+nJGLl/FnQO1gM72kflrFQ2HXtpZkrT4xPwnLYEhmd/GsPpWjKIvHB41R8FAVThFSvwqbZZYuYqZqGLFaMRj/JrIZRtO3WITMyqzackStdR2VYmqsQaiLcpllhysMrBJERtXsO1hMLYGd5+mqBGiqCwAq/lPofr3LP7D8grsO2dmssQq1LHfjoW3ui/AJhMoXay8QHr7hRZ4CZyT8CKpZq0CL//xAAcEQACAwEBAQEAAAAAAAAAAAAAAQIQERIxIVH/2gAIAQMBAT8BvHcVoq0msdQrUaNa8rka3wwwS0nDCPhzekvCD+VjOf0bJM//xAAcEQACAwADAQAAAAAAAAAAAAAAAQIQERIhMVH/2gAIAQIBAT8BvVcng7i9qdcWYJ4q5Cf0000jLSXptsj6TXdajaij/8QAKhAAAQMBBgcAAgMAAAAAAAAAAQACESEQEiAxQVEDIjJhcYGRM7FCUtH/2gAIAQEABj8CV3hx5Ukytl3szQa7Dcb7syw1CuugYHLssllZQWQUNsIGGqgKU233ZJWqpZXJRI9I0d8UbWn6guY5aL8bviqxwChoJUE/4rzC1zdYVN05DxY2DnRNaSbi5QAg54vOdpKMdMSgf5EI/D2Ra2TK5im76ob2FnEqEQOppopC6Qi1pvPdSmihS0kFV4rv0pzO5trmqahTup6fBVa+VJoNFQrlVVmgdEUCo0bb2UWcymCpiG/vAfAt6lDmiP7Bc3GlGt7xVcwus2weKoO9HDVoKyGCBmoX/8QAJBABAAICAgICAgMBAAAAAAAAAQARITFBUWFxEKEgsYHB8JH/2gAIAQEAAT8hWoz6HeL2/dhnS2deYg+Isi6I9S9s9wbLPwUczlRU4JVjD1Ei3tLGBheq9wBq7lYDcV+FkHF1MCweZyb7iZy3U0wRYgARjOM3sg2X83r7YYnEbEfX18JEBbryzOee+5cOjL34r5w7w5wS2sFb/wCJYLVw8xs30g2OnGTHk6N3jhtWvPzauw/pM28S6Dhjac8eWn7hVfeMM3EMzUO3NCAoJa6ZlHTt6YNZm6PUFD4fCf8A6Lh3TaxzEVjDiJFZGjEEhWtk78C5eKIpg5R8LdvmZYg6liLo0eblKdTJ8WCVc9St297EqtTx14ga6tLxHHQeAQAJ0anmKRzE+nKgTQ8hbBhqiiaTiUU0/fmJnlA2DeH6imLTtQuax/MseEKcCAITK02jw9sxpphFQqr2QUieAHPpmQ9kwTPMGuv3mHBiWAKZmlXiNME8ROsYsRhj2m1HNH3MP8m/gY9ijRDx1KKHQuAsi9LUarZWoJz0XmErNEsx8FY8Zv6lHTDgZpl8xoS/f7CUtnwJwHmBhtfXllD57e2f/9oADAMBAAIAAwAAABDAazsQyL13uZiR5Oc+hmVpUNlshCCAcInRoEL/xAAbEQEAAwEBAQEAAAAAAAAAAAABABEhMRBBUf/aAAgBAwEBPxAPWq09vbFfYAclOM4HjyFX2JdZUa5HFeZLHJQBVAL+zLy2KrYjv5CoIAbYpLesE7EOvI7FOMBernwmdT//xAAbEQEAAgMBAQAAAAAAAAAAAAABABEQITFBYf/aAAgBAgEBPxBcllDmtqfDFXsBlTB3Ka5BOE5uFYYpezcoWksEbexoUTg9jpSyagSjhNNTTACkPQmnCB7Ntz//xAAmEAEAAgEEAQQCAwEAAAAAAAABABEhMUFRYXGBkaGxEMEg0eHw/9oACAEBAAE/EACqAbsCPJSrexGyJ5U9oaKqvh0/yWVFG2zzFFNMWQ22NcqtP3L1GdHI/wCuGSWOj/A2hsDQ4vaI2ePMQKNtdjLTK5u9x5iq9up3DOZeCW7DCcmWA4erlpiKzl9Z3/gx6hhdAMfdzOSql7+IXULnUzVSdmJuX3mvZyE4XHNQATUkw/WRubkIw2JY/kHuLsaKsKbAIeTP1E8vdLvn2jOufOntKpQbkLguzZ0lPFpS8dS70x+vzcFSTxnHxByEx5XoGrKUA9wYmJQV2RJcF3bfqFdsMA+CM82tEDzbLtugsCl0979/zVwle95X0RdkGXX0Asr5ohWOOM/Ig80ooD0YYQFhcBB1qEcD3NMeAr7MAqYR+k/qV1kNk0si/FRGtQH2PwHSyqxMaHO2so1aXooZLh6DZhr5dWVivAVVxWrzcUHQtwJo9xJlVvF2+JnetjIN39Mxn8U1dvrCfcJb9BqzCJS0QSpfVwVIGN879fwtsIpmeD40jkx80A9dPWMus8rduuxxGgU3nH9JyMiCtVdDE0XQPAKhBpKtMOEcMGwdkE+CX98q95hMFRh1QBnw/qYNBi1oNh/WzG7VPzTn4Y9ClW9AjX5O8XLTUbVWb/esZz2oUeZykDGYAAeTsR8Eb+iEqA5zK+NEqTGs4WK95mKgzyAf0+k0Y1Buqf79yq0JEoq4HUeZw+HUc8HgkQh2M1DLU6algETWce5ZLfgdV31NLjYisXVWwFdRh5RKYIKl8lwbeyAIWiWc05IZxGNXTshbk9E7rWN4JluJddQOt8AUdDoe8dqlK1GFZYPMAoqXjYZZgqI0febPt9CWx0FnAtj6P3NSA+KIUGpBklkUhXKB7o0bJpeYOwFdsVXiYWYFbzWSgHQfAfcFKq7fVNVn/9k=",
    meto: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wgARCABgAGADASIAAhEBAxEB/8QAGgAAAwADAQAAAAAAAAAAAAAAAwQFAQIGAP/EABgBAAMBAQAAAAAAAAAAAAAAAAABAwIE/9oADAMBAAIQAxAAAAG/jKYAjhWQ2uYCZdQGYWvH0DtfRLDW8W1z6Jd9ZqVd/ezKqq1IQQRVU7xF0fM3dzt8/f5IdRRteVF7UyjimZj6qFmyraUjqIfV3504VdHFHBM6ToBN0gTWM6aznVsAA6bnuhrFIBV5101VdnXJpuQIZNoe6rGzyO4k7aIZ9WNjQWN4ud2lhl1nQGWExNatptl96/P/AP/EACQQAAICAgMAAgIDAQAAAAAAAAECAAMEERITIRAiFCMxMjNB/9oACAEBAAEFAvh8jjLLeUd/ROYm4trLMfKJPzdYFlr7npPTaQVYfCWEFwAwOpTk6rT+synPIKbHWpaVhAM6K4+Mkfw/xEbTU5HZ8ZP2swl9dlBHvyYa+RdCg5TD5j4sOq13Tj/iFoKbKmHqnwPl6gy9yzRoCzFr4of47GtJF052QWxTsOfAEhrrddFcULuDwXWaatD2XbaZF3Wq/sWvt4qGtnTXy6QtlqOqYZ7LJeu7Kx9iNzRln1VV4JROkdjnm+QPMHVZluuan9XFRPvEUCGeo3ahnZXL/utak2zJ8Dxf7bIhGibfFYzkBAVMOjKF00t/z/7fXyppC2o1bQos4xmHJARFIVqhquEbB8i+x62S4ZV1Y/P8Oc7yqvjDMdAfn//EAB4RAAICAgMBAQAAAAAAAAAAAAABAhEQEgMhQTEg/9oACAEDAQE/AcU/zHFIlCsqvRJeDTO19xS1s1sUfBxY1UccaOhVia6Ju2cbJJ/UbP1CexPqNY//xAAfEQACAgICAwEAAAAAAAAAAAAAAQIRECESQQMgUTH/2gAIAQIBAT8Bxa9Zu8WxSvDN9Er7FRrrF7FKjkckJ28eQ2NYj+kVSPIiPxnH4PRHbx//xAAsEAABAwMDAwMCBwAAAAAAAAABAAIRECExEiJBYXGRAzJRE0IgM1JicoGh/9oACAEBAAY/AqT4Cvdx5RIUlfNNroWn1I/ofg5t0pYSvaril7hWxTSTfhCfimnDVpYFpGeTS69qwtJ4pOVZri7/AAUeeqLlucArEGvCcVPFG32nFZiXuwFL37ltKCkra1bm+E7tQO/VeEVpAFroEvbj4XDuwW4EdaQrgLATgeLIU0zCeJg4UBBvpAgRwmOdk56o/TNpsi71PCDS4Ncf2rQ4QflpW15IINimiMUM4hfVdjVFPctp3FBo4R6OlatXOCg61lnDfKLiDe00kiYbhDrdWcW9irPPhaidTqahccq5juve1avtsO6Ap/IQjHAV89aSKXXRWXph1wXJ3TbQ0tlqn03x8hXbPZe13hYd4WkTqRPRAn7U2kKDmmwx8Le0P6r8k+VDGAFanXeV2RcR2r//xAAkEAEAAgIBBAMBAQEBAAAAAAABABEhMUEQUWFxgZGhsfAg8f/aAAgBAQABPyGKFXzLD4nyf4nOO4+DsdohzlEqu/sd4pst+HxHxD4qbsgqlHT/AMBFlnPFojPAA96hTEXYjuEx6lTJqVLM4Zzosj4l7DAWwE+ESvtS+ilpZfMB5jCAwFQCh9xaOJT1A+pXG9pXUPBlTMdqdAdhKe6hitzO5e8QbNn5G/E94vk3glPN9qah2ARUENuWae3joVri1f2YpBMt9t0XLLZXaNQ7qITQS9Vp5YKKfahU2OHQvRcCzhjpvEbQD8ib3T4YutNGxp2Z42JSpDLc3xLd+pUoeLuGpyCv8LmI74goDicU63V7gLLDhzmoLlq/5E18NdMsKM56uYDWhWUuArdU1DjNBl+y0wSxBfmJhsHPg8zuIX08UD/ZUe9H+P3P/DP9iJosWi4XGEsVrNSYTeLaObi8YJibizWHJYaBFXh0qVRd5ZigJnN8xL/LPqUxVHdEo0obYQ03FSFuBD8UNR4fsjoFl7O6OvRWDQdFdh0/cSfEw6u9/L10XH0doRBSxd6jmmeztMhT4iYWAp9S199Hr7/ol5yLIRYsclQY1Hvv9TYmqfXIKTXFRxvb3EBMFPLgiCd1b76E60lSydCKj5mXnNDK/wDQGKoxVTB8xCpyWI0ay9soCaxY6//aAAwDAQACAAMAAAAQ8/X4kU71w/fjk9o3Gni4z76/5EZwBUEYsxWc/8QAHBEBAQADAQEBAQAAAAAAAAAAAQARITEQQVFh/9oACAEDAQE/EPEOln0iDls5hukuxzwcQwzAbcjji1IszOJ9SSbsj/EgMTbOyJ2Jdx+CQ+2nYy7LDmOWJSzJw6huCXg//8QAGxEBAQEAAwEBAAAAAAAAAAAAAQARITFBEFH/2gAIAQIBAT8Q+CdNn1k4FmQXsfD34Nl1ikukx2bGkRkW9krZ4b+wC7dT1CPUs6nHsjJ4kwwE3JaAzEjHqJzbevz/xAAlEAEAAgIBBAEFAQEAAAAAAAABABEhMWFBUXGBkRChscHR4fD/2gAIAQEAAT8QjoVW/VwVqevbSp9j5MJ3idvmHQe+44VNF7FaO2o2FUa77+SrC6dtcQNyo0O3+UJK3sa+NQ3DAOC8049EESxx9c9KtcKqkU1hiNoIOxQvqiHWIUWxVZ3TmE3vDJFxtO6YlwnGXsf48xMNAGwq1HDKdSt+mUfEO8u7finPiAZTTyrP0zXGotep5vL2a5IyLt/LDhLMhlZd1PFkrBR6C49kfLKys+itQQi2a+hsfvE4Hw9HxKJoNuAeI1ehCA83r1b9FStATgoPGW4bw6DxOqWAefjpPF3KfxArV8NkC6e8GHbwMIYbgcBn5/UZ0tzeYFxcboqUwPhFLdt9WP7GILlmW8KfmoxMWFXV18GWUNqcBfl3DJekurPEBOlZInNFmA4g01X8QGOdU2QB1YLv2iVk6XGVdh2WrPJOIE/aAAm20GRWoxD3Au1fe4cBugteUEHiGUoHLXsTXuXaEe0ejbJ4czMuuaBYyLsoEPwjm8qPcfwxQZazzugYOhACU1qCwEtgGygw36lIJbsaNw8JOmRFmHvrmtQODygNlA2OKu+rcRFGAALKEcn4hUdxF0C8TOE5vLGNG8wluwvFRpF4W8UacTp5YCezOOyf2G7QwWK0jS4uK3dF/r6CNBbL0MILhq+jwFnFN8xyq42KoPDHSOuSwuy09uXgDM0TbHa95XAWMm1b/ZLu+VqbA7Zl9bVmZSjlfEa2b2nRA8dfUM6EIKF1bm8tGvoA9kbS0vgzAEBo8LXxUszW0o+TEqhov+HE62y909jsSmRuWyxOQjTwnOyUxZ7n/H3hAcHVGBTcRCZHIPQF8rxMMuA2HT84q+fpvZahosJf3gFXY+LP1LhZAC9+tNYgamz1Bya4enbxMgbe8PXyMKagFA26ZgWvzwgiEWF3l/YeRSxda2/g9P03+wL4EiK31VPcoQyvGb+0PxwI0ebKf1KKauaqd7Qxh3QNzcEIBT1N1dQCCMY/m9Sl8AANP/f1L5w+9kP3Ogj2mVZX5fpkHUvDBv5p5Tr737gWtRerhvhT2/7pBpY5eyv5CoxZbwPtMwMlqu1xXqWHLn7vQgU3VmFqehAUS1T216+v/9k=",
    fero: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wgARCABgAGADASIAAhEBAxEB/8QAGgABAAIDAQAAAAAAAAAAAAAAAAIDAQQFBv/EABgBAQEBAQEAAAAAAAAAAAAAAAABAgME/9oADAMBAAIQAxAAAAHfZl5OzKqy2qNurDMolim7MCBCq81bO9AATpmSauzExq7WlbsTNUAACF1V2c16Tlbnoo8y266CGJbFeSbU2yOxRfjHN4XX5HfEsnXN+zz8ZvSc5Lu1a+LN/v8AH7HDXj2M+jExTGQAB1N/md7zdP/EACQQAAIBAwMEAwEAAAAAAAAAAAECAAMEEhARIBMhMDIUMTND/9oACAEBAAEFAuOazOB1PgZ9jjvqQDO6cnfaIuI4+p1Y4rTHfkRkEO66Vftfrmvvoe9TwH3hIAQ5aFgo5H2l5+KVWWLdR+ncqi4oXUEOrRiQlu7us/pLttqOq1qiwXbT5c+WYbqpOvVlLOo8vXXHw2Q2O8bxWwBmEPipNtWn/8QAHBEAAgICAwAAAAAAAAAAAAAAAAEREhAgAjBR/9oACAEDAQE/Acx0ra0MnzXlizLMsxbI/8QAHhEAAQMEAwAAAAAAAAAAAAAAAAECERASIDEDMFH/2gAIAQIBAT8BpBBHQmKjWyhHuDjj1S1CxC1B+8n7P//EACwQAAECAwYFAwUAAAAAAAAAAAEAAhARIRIgMDEyQVFxgZGhImGxAzNCYsH/2gAIAQEABj8Cu5z5LS7sqHAkKu4L1mfttGtVWrfi9IZ/F/8AU+LhKmc75HFT3i1vXBcOsXdsFnUQmclaG5hNxlfZz/kOqkMl6moNtyKDRspEqhmiQJlE/UEoN5GEuNyju60hfb8rR5Wy1qdokjKFn8sK0dxiAH3VCRhtZwAh/8QAJxABAAIABQMEAwEBAAAAAAAAAQARECExQVEgYXEwkaHBgbHR4fD/2gAIAQEAAT8hhnArFuos4Fyu4yzQXxo9IXiFF2m3mX+IZf6gUUZHGBtEHeXuO5r/AEdTcv8ADmeUdXpuzvDKDVo7v50GztFVn6l79ZaCD2ikvLzvi7/M/UNH0MnIo/p/WP4qv+e/o6rk+yVESANVgrYdPfCqAcrLss6vksDoHJhYhTQSP9xKkoNwM6AqKqCRijWuUqFBkcy/iHLKrw1DhP1gTotdEJfOG8hxmgNW8NTVdL5h2RCNA/MU3HgJVMsmbTvKlDrvZ2h0WS8U7XBuDMo4zJSJW1tc1Ya9FdJG+Ee5MsDRfb0qE2H5u/vD/9oADAMBAAIAAwAAABBYFh4oIST/APiIU3//AP4J7EPMJfABZvSWAPHPMP/EABwRAAICAwEBAAAAAAAAAAAAAAERABAgMUEhUf/aAAgBAwEBPxCkcQCsigZyT0ikQ/scBYcOzNqAO1knY6yNBT//xAAcEQADAAIDAQAAAAAAAAAAAAAAAREQMSAhQVH/2gAIAQIBAT8QEm9CX0kbLGxKdZl6Gob8dx9EWmJ8INRw2FmLZ5hSPCenJNj/xAAnEAEAAQMDAwQDAQEAAAAAAAABEQAhMRBBUWGBkSBxocEwsfHR8P/aAAgBAQABPxCgq1D7tRuJ5UzxUGC5U/qpHXPPgb+lF0oAINDb0JEiHK2PmoE+LHb7eKAgAwCA0gRGATHtxTcreNxcv9DrQiCIjcTSKCCDRkcjmYk5H0btFvrSjKvV3fSC+wN6JbkQ+M6tuH39AkyGYN3Y7tqUCV6rgdDB60hgJ5bPZhoHYhB4DA8jrw4L2LfJntXVzd/B0ce4+yXfVyej7EvzQIA4/BYDcPAP00KjLpKIApuksSRJYfBpeR8WRQAQRJEbPqVrl/C0USYA+F+qWq3QjvmhoSHLPxWKKtr4i40mCOFyxR14iiO+KjvhIUwVNid50WKtcReJvbpof812fbpBILpbr8UGSM1Iw71Zh8NAggbEP9rN85XlSktCQZY4x0pRZ+8vqv0utM77CfVEREO6xc4Azy8VKpMYiQ49fc2pQjWdGxRyUBbOoZuVcJBwEA8tJc+KRIuAlWsE80AY1Q5KAMHouMp1M/wfFMrOcClYuUK3/BikSRPe8r9im9f/2Q==",
    josh: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wgARCABgAGADASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAwQAAQUCBv/EABgBAQEBAQEAAAAAAAAAAAAAAAMCAQQA/9oADAMBAAIQAxAAAAFCSqixc3N2ypM3ba886gasrpRqXXvYAirh11qB3SVMWjc1lIejFU52r5r0z8tS5ZYCrkLqODUAakPl9zt6ShNzJ1c3VUWpcQMLsGoHYdQoIrqjz2pPi63E3uJZPSRefzOrjvh1kHybLT7bX958+M9nrNnlQdW+elDytm1i6FGrShBOQubxnWHZrWR1UIb2eSj/AP/EACQQAAIBAwQCAwEBAAAAAAAAAAECAwAEERASEyEiMiAjMxQx/9oACAEBAAEFAtc5obaXxqKYOvyJxRNbqNA11mKfjAIYfBqFRWuaNpGa/iXLWdHMbQS4PwFW4zJXdZ0liEsYyBq42tgkx8iB/wCkGB3ZGfaovu45kepBtltCTBpL72nbu/ZlVqVSZdrGUbc8SuZV2yW2ODQnE8XTbBRjCC3XuRfv4vJFIMw3iDxXSc4lgH18IFFFDJItPtkA5VGJZKuPGC3Gs/7RHKvNtZrhNqPSOhf0oPV1+dt+Wkv7wSBAgEtwUKt5rTLW1kEHrPJvkjzHGDkVL7g5qKKRKP2IXljMQZhcnEIkYJSDEako1IhmKxLEry9R3ARVuVI5kImfkP8AlW8fIzp0T1G22v/EABwRAAICAwEBAAAAAAAAAAAAAAABAhADESExUf/aAAgBAwEBPwESqWL5aIo0NGSNI0b5WTyodVaqa5UDrOmzJUULghskNH//xAAcEQADAQACAwAAAAAAAAAAAAAAARACESEgMVH/2gAIAQIBAT8BG4t/axs5EzDjnB0YmvDLmjqcGJpnsYhT/8QAKxAAAgADBgYCAgMAAAAAAAAAAAECESEQEiIxQWEDIDJRcYETkTBCcqGx/9oACAEBAAY/AuXAzFSX4K/R0rkutNrYmsuecZ2OpyMMUi7GKB5PJ8tSfLLXQ8cuWZdh4anuYo2vBjruN9ivDoUfpkaeYp6Ut9HgmUcxwwOWp8ccVB3elbCHC3VZEMrZ9kfL+sTqTSQ3hgh1kPiPU/mpexYrrRnMi4i1jSQuG5TS0tYkYY3D4FeicT3HUaKSjRKPDDsUpJqR4VrKDTZK7/ZkTeHcmumxbsW9bYjEyLtmfr9HT9FYGvBehcUvEi/3ElkiB7Wz3Mj5JLwTRJk4x70Lmligiyl9FfdjS9vsYFX/AE1W7HNOczFRmZTpVlenUoIk8j//xAAlEAEAAgEEAgEFAQEAAAAAAAABABEhMUFRYRBxgSCRobHR4fD/2gAIAQEAAT8h8q0YILZpeMkuxp3DZjFo1Tb9YC3wgarBGOmkUg6nEKhDR2Qi1rI/S9uIFaC1la/4JsT6M1L1Ah2r8BLgbirjeVzbsn05wa0wEDFEsbEOku9o6oV1Sx7ZOIZLNHyLG2pHEKtHcqyK3lFYE+yaZocDeBQrS6IzRfRmlIvQxBNWZyoI9eda4GRya/UETouVtXwSPtOyGhPlzDSD0Q4ZrxvLJnAoe2LffnAtbD3MkGRQ2Lwy0HOGMf2DMVAp0nBKrXRQekVdYlI3nuXWgu7uKQX3Mnuglfmw/H4laOCOZ1axO6gu6imgrmWRkr8x5jbLhm0N41vzME4s2mZdhPlz/PKseFhHe8TaG4MxOavcJbRMXgmZK+UsFl7U2hphis/+anTsaO/K+7KJRTj1Fu10mUgemn9S8am/YhrazvC7SS24Abw/qdh2+4k3YfcO48andLAFmHYmKu5qUIP8ZUfO2NZQhOtJW+kV16MMW8Zmm9DPKUj0EESzSaId5NIqNlhV1iiwAajVQqyhAi1NGhC3CPDK/P8AZGqS+2K9upRvdMssymL5Ja3H4n//2gAMAwEAAgADAAAAEA3heyBFswua70WV71AWP/UADW2ApRYQQHqpd//EABwRAQEBAQADAQEAAAAAAAAAAAEAESEQQVExYf/aAAgBAwEBPxC+lg8bLtyyOsOa2H1CGkQ6e7I3XFuIiHgyHCxZ4kz8j1vhhHokBGuJDbJEvoy/t05I3LS//8QAGxEAAwEAAwEAAAAAAAAAAAAAAAERIRAxQVH/2gAIAQIBAT8QPgb2jzFKNg9Yi16NsYxqMvG+wdM0zsUeOiaE9LexzecLSIYONMcITGuyK+CRC+iZ/8QAJRABAAIBBAIBBQEBAAAAAAAAAQARITFBUWFxgZEQobHB4fDR/9oACAEBAAE/EPooFrQRxE9Gr8aRVQzdY+Ll461m1qJzEOxwAzo59/EMlmTmVKlfVG2CEhrvIP3D3P4Z+YDg20FuuoSZcZg21Tpq/wC/MQuK8xLqVxekEUWhuSpUr6WIAXJ64/3UF2h7WUFDhtPLN0niuFjgRCveY/xUJ7g57m6mycwzEgJVLs9LKlSvphvEVU5YSNrvZWv+xwhdEd8eGI6s8xu1Eb2Ta8jx4YqhXMurH+RBMIWJwypUILo8BLJbLxrLiWCC1tb5Q06Fjsk30PRtHCqomw8xyERajOouc/3mY3wKPT+pb5rjkWx8UwFs2DkOPjSVKiMwABmGJWBF/D7BLWV4FoJu3UUJ6szAovQWnThOZYa16Izpbr95agShsK9Er0Is7B+nv5nvI1FWXxrBOhsQ7NypURtSWl4BX5YBNKma+g6TPTLQulfJnhhgoMkka1nwR75c+uxfom1go0MgeyJNbAEXBHD9oO0jHIO8Ze95hPINQEs8v4jQFVdM5pvGEdfMqVCK7x7gSFISesxpsWWn8NIiJnFYTN1pcCnPS9mNrgagwgNKHU7hwSlrXNr5ldRuqseFQmT8C2cermCaR8ivt931oLNj9Sg1FMYLCIwHG6nlaJVqGbAR2bI46ZJxY65hLrHZx1Ctb0os9oGQRjG2I/ZRamqdj/FV6lfSyw1/eDT3Mri+oXoHYsjvIZSEnmACD3VT06RXldUX9sfJL0xItD5plVZBobLF94hLBxC2K/k0gEE0rUfizoYT8acPH0OBog/OILCmQMrz6lmKUnC5YweIFAXdDqVm3DFCsqS/glXCTi8MyO94XKsHb/JarAQMJm7+6RmwDZmUNEW6a+G/nzHwOP6D8kJraLE3h91pJNz28Ewg1D43S9Do0upfBK2AfG74l4Y0Iy3S7QavZFwaTnkCUkpiGh35iCzkwn+6Y1Ot53sbPbC9HcWxp0d4ZlGhR+u+xx4ZlbNhd3+/7zP/2Q==",
};
const slug = (s) => s.toLowerCase().replace(/ç/g, "c").replace(/ğ/g, "g").replace(/ı/g, "i").replace(/ö/g, "o").replace(/ş/g, "s").replace(/ü/g, "u").replace(/[^a-z0-9]/g, "").slice(0, 20);
/* TheSportsDB'den sonuç çekme — ücretsiz anahtar, Süper Lig id 4339 */
const TSDB = { anahtar: "123", lig: "4339", sezon: "2026-2027" };
const sadeAd = (x) => (x || "").toLowerCase()
    .replace(/ı/g, "i").replace(/İ/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g")
    .replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c")
    .replace(/[^a-z]/g, "");
/* Kod -> API'de geçebilecek adlar */
const TAKIM_ADLARI = {
    GS: ["galatasaray"],
    FB: ["fenerbahce"],
    BJK: ["besiktas"],
    TS: ["trabzonspor"],
    IBFK: ["basaksehir", "istanbulbasaksehir", "medipolbasaksehir"],
    GOZ: ["goztepe"],
    SAM: ["samsunspor"],
    RIZ: ["rizespor", "caykurrizespor"],
    KON: ["konyaspor", "ittifakholdingkonyaspor"],
    ALA: ["alanyaspor", "corendonalanyaspor"],
    KOC: ["kocaelispor"],
    GFK: ["gaziantep", "gaziantepfk", "gazisehirgaziantep"],
    KSM: ["kasimpasa"],
    GNC: ["genclerbirligi"],
    EYP: ["eyupspor"],
    ERZ: ["erzurumspor", "buyuksehirbelediyeerzurumspor"],
    AMD: ["amedspor", "amedsk", "amedsportif"],
    CRM: ["corum", "corumfk"],
};
/* Bizim takım kodumuzu sadeleştirip sözlükte arar */
function apiEslesme(apiAdi) {
    const a = sadeAd(apiAdi);
    if (!a)
        return null;
    for (const kod in TAKIM_ADLARI) {
        for (const ad of TAKIM_ADLARI[kod]) {
            if (a === ad || a.includes(ad) || ad.includes(a))
                return kod;
        }
    }
    return null;
}
/* PIN karması — tuzu lig ve kişi adından geliyor */
async function pinKarma(lig, kisi, pin) {
    const metin = "kupon|" + lig + "|" + kisi + "|" + pin;
    try {
        const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(metin));
        return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
    }
    catch (e) {
        let h = 5381;
        for (let i = 0; i < metin.length; i++)
            h = ((h << 5) + h + metin.charCodeAt(i)) >>> 0;
        return "y" + h.toString(16);
    }
}
const avatarBul = (isim) => AVATARLAR[slug(isim || "")] || null;
function Yuz({ isim, boy = 42, vurgu = false }) {
    const src = avatarBul(isim);
    const ortak = {
        width: boy, height: boy, borderRadius: "50%", flexShrink: 0,
        border: vurgu ? "2px solid var(--aksan)" : "1px solid var(--cizgi)",
        boxShadow: vurgu ? "0 0 0 3px color-mix(in oklab, var(--banko) 32%, transparent)" : "none",
    };
    if (src)
        return React.createElement("img", { src: src, alt: isim, style: { ...ortak, objectFit: "cover", display: "block" } });
    return (React.createElement("div", { style: { ...ortak, background: "var(--kat2)", color: "var(--sol)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Fraunces,Georgia,serif", fontWeight: 700, fontSize: boy * 0.42 } }, (isim || "?").trim().charAt(0).toUpperCase()));
}
function CatismaFiguru() {
    const s = (tag, props) => React.createElement(tag, props);
    return React.createElement("svg", {
        className: "pr-catisma-svg", viewBox: "0 0 140 78", fill: "none",
        stroke: "currentColor", strokeWidth: 2.25, strokeLinecap: "round", strokeLinejoin: "round",
        "aria-hidden": true,
    },
        s("circle", { cx: 34, cy: 15, r: 7 }),
        s("path", { d: "M34 22 L47 48" }),
        s("path", { d: "M47 48 L31 74 M47 48 L61 74" }),
        s("path", { d: "M38 33 L16 44" }),
        s("path", { d: "M38 29 L80 8", strokeWidth: 2.8 }),
        s("circle", { cx: 106, cy: 15, r: 7 }),
        s("path", { d: "M106 22 L93 48" }),
        s("path", { d: "M93 48 L79 74 M93 48 L111 74" }),
        s("path", { d: "M102 33 L124 44" }),
        s("path", { d: "M102 29 L60 8", strokeWidth: 2.8 }));
}
function RuletFiguru({ don = false }) {
    const s = (tag, props) => React.createElement(tag, props);
    const ticks = [];
    for (let i = 0; i < 18; i++) {
        ticks.push(s("line", {
            key: i, x1: 60, y1: 8, x2: 60, y2: i % 3 === 0 ? 18 : 14,
            stroke: "currentColor",
            strokeWidth: i % 3 === 0 ? 2 : 1.15,
            transform: "rotate(" + (i * 20) + " 60 60)",
            opacity: i % 3 === 0 ? 1 : 0.5,
        }));
    }
    return React.createElement("svg", {
        className: "rl-cark" + (don ? " don" : ""),
        viewBox: "0 0 120 120", fill: "none", "aria-hidden": true,
    },
        s("circle", { cx: 60, cy: 60, r: 56, stroke: "currentColor", strokeWidth: 2 }),
        s("circle", { cx: 60, cy: 60, r: 44, stroke: "currentColor", strokeWidth: 1.2, opacity: 0.5 }),
        s("circle", { cx: 60, cy: 60, r: 16, stroke: "currentColor", strokeWidth: 1.6 }),
        s("circle", { cx: 60, cy: 60, r: 4.5, fill: "currentColor", stroke: "none" }),
        ticks,
        s("circle", { cx: 97, cy: 27, r: 3.3, fill: "currentColor", stroke: "none" }));
}
function Konsol7Ikon() {
    const s = (tag, props) => React.createElement(tag, props);
    return React.createElement("svg", {
        className: "mg-kon7", viewBox: "0 0 72 44", fill: "none",
        stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round",
        "aria-hidden": true,
    },
        s("path", { d: "M16 17 C9 17 6 24 7 33 C8 39 16 40 19 33 L20 20 C20 17 18 17 16 17Z" }),
        s("path", { d: "M56 17 C63 17 66 24 65 33 C64 39 56 40 53 33 L52 20 C52 17 54 17 56 17Z" }),
        s("path", { d: "M19 12 H53 C58 12 60 15 60 19 V25 C60 29 56 32 51 32 H21 C16 32 12 29 12 25 V19 C12 15 14 12 19 12Z" }),
        s("rect", { x: 30, y: 16, width: 12, height: 7, rx: 1.6 }),
        s("path", { d: "M21 20.5 h7 M24.5 17 v7" }),
        s("circle", { cx: 50, cy: 18.2, r: 1.35, fill: "currentColor", stroke: "none" }),
        s("circle", { cx: 53.2, cy: 21.2, r: 1.35, fill: "currentColor", stroke: "none" }),
        s("circle", { cx: 46.8, cy: 21.2, r: 1.35, fill: "currentColor", stroke: "none" }),
        s("circle", { cx: 50, cy: 24.2, r: 1.35, fill: "currentColor", stroke: "none" }));
}
/* Puanlama */
function macPuani(tahmin, sonuc) {
    if (!tahmin || !sonuc)
        return 0;
    const [te, td] = tahmin, [se, sd] = sonuc;
    if (te === se && td === sd)
        return 5;
    const ts = Math.sign(te - td), ss = Math.sign(se - sd);
    if (ts !== ss)
        return 0;
    if (te - td === se - sd)
        return 3;
    return 2;
}
const bosSatir = () => ({ o: 0, g: 0, b: 0, m: 0, ag: 0, yg: 0, p: 0 });
/* Kupon Pro: pure, historical analytics. Current private picks are never included. */
const KAnaliz = (() => {
    const has = (o, k) => Object.prototype.hasOwnProperty.call(o || {}, k);
    const valid = x => Array.isArray(x) && x.length === 2 && x.every(n => Number.isInteger(n) && n >= 0);
    function rank(scores) {
        return Object.entries(scores || {}).sort((a,b) => b[1]-a[1] || a[0].localeCompare(b[0])).map(([slug,puan],i,all) => ({slug,puan,sira:1+all.filter(x=>x[1]>puan).length}));
    }
    function stats(weeks,who) {
        const r={hafta:0,mac:0,tam:0,sonuc:0,banko:0,bankoTam:0,bankoDogru:0,puan:0,enIyi:null,takimlar:{},form:[]};
        for(const h of weeks || []) {
            if(!has(h.tahminler,who)) continue;
            r.hafta++; const puan=Number((h.puanlar && h.puanlar[who]) || 0);r.puan+=puan;r.form.push({no:h.no,puan});
            if(!r.enIyi || puan>r.enIyi.puan)r.enIyi={no:h.no,puan};
            (h.maclar || []).forEach((m,i)=>{
                const t=h.tahminler[who] && h.tahminler[who][i],s=h.sonuclar && h.sonuclar[i];if(!valid(t)||!valid(s))return;
                const tam=t[0]===s[0]&&t[1]===s[1],dogru=Math.sign(t[0]-t[1])===Math.sign(s[0]-s[1]);
                r.mac++;r.tam+=+tam;r.sonuc+=+dogru;
                if(h.jokerler && h.jokerler[who]===i){r.banko++;r.bankoTam+=+tam;r.bankoDogru+=+dogru;}
                for(const idx of [m.e,m.d]){const v=r.takimlar[idx]||(r.takimlar[idx]={mac:0,tam:0,dogru:0});v.mac++;v.tam+=+tam;v.dogru+=+dogru;}
            });
        }
        r.form=r.form.slice(-5);return r;
    }
    function duel(weeks,a,b){
        const r={a:0,b:0,berabere:0,puanA:0,puanB:0,haftalar:[]};
        for(const h of weeks||[]){if(!has(h.tahminler,a)||!has(h.tahminler,b))continue;
            const pa=Number((h.puanlar && h.puanlar[a])||0),pb=Number((h.puanlar && h.puanlar[b])||0);
            pa>pb?r.a++:pb>pa?r.b++:r.berabere++;r.puanA+=pa;r.puanB+=pb;r.haftalar.push({no:h.no,a:pa,b:pb});
        }return r;
    }
    function summary(weeks,index){
        const h=weeks[index];if(!h)return null;
        const sirali=rank(h.puanlar),lider=sirali.filter(x=>x.sira===1),tekler=[],surprizler=[];
        (h.maclar||[]).forEach((m,i)=>{
            const sn=h.sonuclar && h.sonuclar[i];if(!valid(sn))return;
            const rows=Object.entries(h.tahminler||{}).filter(([,th])=>valid(th[i]));
            const tam=rows.filter(([,th])=>th[i][0]===sn[0]&&th[i][1]===sn[1]);
            const dogru=rows.filter(([,th])=>Math.sign(th[i][0]-th[i][1])===Math.sign(sn[0]-sn[1]));
            if(tam.length===1 && rows.length>1)tekler.push({i,slug:tam[0][0]});
            if(rows.length>1)surprizler.push({i,dogru:dogru.length,toplam:rows.length,oran:dogru.length/rows.length});
        });
        surprizler.sort((a,b)=>a.oran-b.oran||a.i-b.i);
        const once={},sonra={};for(let j=0;j<=index;j++)for(const [sl,p] of Object.entries(weeks[j].puanlar||{})){sonra[sl]=(sonra[sl]||0)+p;if(j<index)once[sl]=(once[sl]||0)+p;}
        const eski=Object.fromEntries(rank(once).map(x=>[x.slug,x.sira]));
        const hareket=rank(sonra).map(x=>({...x,fark:has(eski,x.slug)?eski[x.slug]-x.sira:null}));
        return {h,sirali,lider,tekler,surpriz:surprizler[0]||null,hareket};
    }
    const percent=(a,b)=>b?Math.round(100*a/b)+'%':'—';
    const stamp=weeks=>JSON.stringify((weeks||[]).map(h=>[h.no,h.sonuclar]));
    const eventTime=o=>{
        const raw=o.strTimestamp || (o.dateEvent&&o.strTime?String(o.dateEvent)+'T'+String(o.strTime).trim():null);
        if(!raw)return null;
        const ts=String(raw).trim().replace(' ','T');
        if(/^\d{10,13}$/.test(ts)){const n=Number(ts);return n<1e12?n*1000:n;}
        if(/[zZ]$|[+-]\d{2}:?\d{2}$/.test(ts)){const n=Date.parse(ts);return Number.isFinite(n)?n:null;}
        const n=Date.parse(ts+'+03:00');
        return Number.isFinite(n)?n:null;
    };
    function finalScore(o){
        if(!['FT','AET','PEN','MATCH FINISHED','FINISHED'].includes(String(o.strStatus||'').toUpperCase().trim()))return null;
        if(o.intHomeScore==null||o.intAwayScore==null||String(o.intHomeScore).trim()===''||String(o.intAwayScore).trim()==='')return null;
        const s=[Number(o.intHomeScore),Number(o.intAwayScore)];return valid(s)?s:null;
    }
    return {rank,stats,duel,summary,percent,stamp,eventTime,finalScore,valid};
})();
async function sporVerisi(hafta,signal){
    const url=`https://www.thesportsdb.com/api/v1/json/${TSDB.anahtar}/eventsround.php?id=${TSDB.lig}&r=${hafta}&s=${TSDB.sezon}`;
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
    const cancel=()=>controller.abort();if(signal)signal.addEventListener('abort',cancel,{once:true});
    try{
        if(signal && signal.aborted)throw new Error('İstek iptal edildi.');
        const r=await fetch(url,{signal:controller.signal});
        if(!r.ok)throw new Error(r.status===429?'Sonuç servisi yoğun. Birkaç dakika sonra tekrar dene.':'Sonuç servisine ulaşılamadı ('+r.status+').');
        const d=await r.json();
        const list=d.events;if(!Array.isArray(list)||!list.length)throw new Error('Bu hafta için veri yok. Hazır fikstürü veya elle girişi kullanabilirsin.');
        const events=list.filter(o=>String(o.idLeague)===TSDB.lig && String(o.strSeason)===TSDB.sezon && Number(o.intRound)===Number(hafta));
        if(!events.length)throw new Error('Servisten gelen sezon/hafta verisi eşleşmiyor. Elle kontrol et.');return events;
    }finally{clearTimeout(timer);if(signal)signal.removeEventListener('abort',cancel);}
}
function dosyaIndir(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),60000);}
async function kuponZipPaylas(){
    const r=await fetch("/kupon-github.zip");
    if(!r.ok)throw new Error("dosya yok");
    const blob=await r.blob();
    const file=new File([blob],"kupon-github.zip",{type:"application/zip"});
    if(navigator.canShare&&navigator.canShare({files:[file]})){
        await navigator.share({files:[file],title:"kupon-github.zip"});
        return "paylasildi";
    }
    throw new Error("paylasim yok");
}
async function kuponHtmlKopyala(){
    const r=await fetch("/kupon.html");
    if(!r.ok)throw new Error("dosya yok");
    const html=await r.text();
    if(navigator.clipboard&&navigator.clipboard.writeText){
        try{await navigator.clipboard.writeText(html);return;}catch(_){/* iOS iframe */}
    }
    const ta=document.createElement("textarea");
    ta.value=html;
    ta.setAttribute("readonly","");
    ta.style.cssText="position:fixed;left:0;top:0;width:1px;height:1px;opacity:0";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    ta.setSelectionRange(0,html.length);
    const ok=document.execCommand("copy");
    ta.remove();
    if(!ok)throw new Error("kopyalanamadi");
}
async function kuponHtmlIndir(){
    try{
        return await kuponZipPaylas();
    }catch(e){
        if(e&&e.name==="AbortError")return "iptal";
    }
    await kuponHtmlKopyala();
    return "kopyalandi";
}

export function Kupon() {
    const [ekran, setEkran] = useState("giris");
    const [sekme, setSekme] = useState("merkez");
    const [lig, setLig] = useState("");
    const [isim, setIsim] = useState("");
    const [ben, setBen] = useState(null);
    const [kurulum, setKurulum] = useState(null);
    const [aktif, setAktif] = useState(null);
    const [tablo, setTablo] = useState(null);
    const [portfoy, setPortfoy] = useState({});
    const [kuponlar, setKuponlar] = useState({});
    const [benimKupon, setBenimKupon] = useState(null);
    const [bilgi, setBilgi] = useState("");
    const [mesgul, setMesgul] = useState(false);
    const [yukleniyor, setYukleniyor] = useState(false);
    const [yeniMac, setYeniMac] = useState({ liste: [], bekleyen: null });
    const [sonucGiris, setSonucGiris] = useState(null);
    const [takimDuzen, setTakimDuzen] = useState(null);
    const [portfoySecim, setPortfoySecim] = useState([]);
    const [resmi, setResmi] = useState(null);
    const [resmiTaslak, setResmiTaslak] = useState(null);
    const [kuponOnay, setKuponOnay] = useState(false);
    const [portfoyAcik, setPortfoyAcik] = useState(false);
    const [pinEkrani, setPinEkrani] = useState(null);
    const [pin, setPin] = useState("");
    const [pin2, setPin2] = useState("");
    const [pinHata, setPinHata] = useState("");
    const [beklenenGiris, setBeklenenGiris] = useState(String(TAKMA_ADLAR.length));
    const [cekiyor, setCekiyor] = useState(false);
    const [acikHafta, setAcikHafta] = useState(null);
    const [duzeltHafta, setDuzeltHafta] = useState(null);
    const [magaza, setMagaza] = useState(MAGAZA_BOS);
    const [zekatMiktar, setZekatMiktar] = useState("");
    const [zekatOnay, setZekatOnay] = useState(false);
    const [erzakOnay, setErzakOnay] = useState(false);
    const [satinOnay, setSatinOnay] = useState(null);
    const [anket, setAnket] = useState({});
    const [mansetKapali, setMansetKapali] = useState(false);
    const [transfer, setTransfer] = useState(null);
    const [trSat, setTrSat] = useState(null);
    const [trAl, setTrAl] = useState(null);
    const [trOnay, setTrOnay] = useState(false);
    const [ayakta, setAyakta] = useState(AYAKTA_BOS);
    const [aySec, setAySec] = useState(null);
    const [ayGirisOnay, setAyGirisOnay] = useState(false);
    const [aySecOnay, setAySecOnay] = useState(false);
    /* Sonuç girme yetkisi ligi kuran kişide. Eski kayıtlarda kuran alanı
       yoksa oyuncu listesinin ilk kişisi kurucu sayılır. */
    const kurucuSlug = (kurulum && kurulum.kuran)
        || (kurulum && kurulum.oyuncular && kurulum.oyuncular[0] && kurulum.oyuncular[0].slug)
        || null;
    const kurucuMu = !MISAFIR && !!(ben && kurucuSlug && ben.slug === kurucuSlug);
    const kurucuAdi = (() => {
        const o = ((kurulum && kurulum.oyuncular) || []).find(x => x.slug === kurucuSlug);
        return o ? o.isim : "grubu kuran ki\u015Fi";
    })();
    const takimlar = (kurulum === null || kurulum === void 0 ? void 0 : kurulum.takimlar) || VARSAYILAN_TAKIMLAR;
    const T = (i) => takimlar[i] || { ad: "?", kod: "?", guc: 60 };
    const islemRef = useRef(false);
    const [sonTeslim, setSonTeslim] = useState("");
    const [simdi, setSimdi] = useState(Date.now());
    useEffect(() => {
        const teslimAcik = !!(aktif && Number.isFinite(aktif.sonTeslim) && Date.now() < aktif.sonTeslim);
        const trAcik = !!(transfer && !transfer.uygulandi && Date.now() < transfer.kapanis);
        const t = setInterval(() => setSimdi(Date.now()), (teslimAcik || trAcik) ? 1000 : 30000);
        return () => clearInterval(t);
    }, [aktif && aktif.sonTeslim, transfer && transfer.kapanis, transfer && transfer.uygulandi]);
    useEffect(() => { setMansetKapali(false); }, [(tablo && tablo.haftalar && tablo.haftalar.length) || 0]);
    useEffect(() => { setAySec(null); setAySecOnay(false); setAyGirisOnay(false); }, [aktif && aktif.hafta]);
    const teslimKapali = !aktif || !Number.isFinite(aktif.sonTeslim) || simdi >= aktif.sonTeslim;
    const ilkMacZaman = (function () {
        if (!aktif) return null;
        const baslar = (aktif.maclar || []).map(function (m) { return Number.isFinite(m.baslangic) ? m.baslangic : null; }).filter(function (t) { return t != null; });
        if (baslar.length) return Math.min.apply(null, baslar);
        return Number.isFinite(aktif.sonTeslim) ? aktif.sonTeslim : null;
    })();
    const ilkMacBasladi = ilkMacZaman != null && simdi >= ilkMacZaman;
    const ruletKapali = teslimKapali || ilkMacBasladi;
    const teslimZamani = () => Date.parse(sonTeslim + ":00+03:00");
    function kurucuKontrol() {
        if (!kurucuMu) throw new Error("Bu işlemi yalnızca " + kurucuAdi + " yapabilir.");
    }
    async function guvenliIslem(fn) {
        if (MISAFIR) { setBilgi("Misafir görünümü salt okunur."); return; }
        if (islemRef.current) return;
        islemRef.current = true; setMesgul(true);
        try { await fn(); }
        catch (e) { setBilgi(e.message || "İşlem tamamlanamadı. Tekrar dene."); }
        finally { islemRef.current = false; setMesgul(false); }
    }
    async function teslimBelirle() {
        kurucuKontrol();
        const zaman = teslimZamani();
        if (!Number.isFinite(zaman)) throw new Error("İlk maçın tarih ve saatini gir.");
        const kayit = await depo.get(`kpn:${lig}:aktif`);
        const a = kayit && okuJSON(kayit.value, null);
        if (!a || a.hafta !== aktif.hafta || Number.isFinite(a.sonTeslim)) throw new Error("Hafta değişti veya teslim saati zaten belirlenmiş. Sayfayı yenile.");
        const yeni = { ...a, sonTeslim: zaman };
        await depo.kosulluSet(`kpn:${lig}:aktif`, JSON.stringify(yeni), kayit.value);
        setAktif(yeni); setSimdi(Date.now());
        setBilgi("Teslim saati kaydedildi. Bu saatten sonra yeni kupon alınmaz.");
    }
    function TeslimAlani() {
        return React.createElement("label", { style: { display: "block", marginTop: 12, fontSize: 13 } },
            "İlk maçın başlangıcı · Türkiye saati",
            React.createElement("input", { type: "datetime-local", className: "kp-gir", value: sonTeslim,
                onChange: e => setSonTeslim(e.target.value), style: { marginTop: 8 }, required: true }));
    }
    /* Pro screens and read-only automatic result checking. */
    const [merkezSekme,setMerkezSekme]=useState('ozet');
    const [ozetHafta,setOzetHafta]=useState('');
    const [rakip,setRakip]=useState('');
    const [istatistikKisi,setIstatistikKisi]=useState('');
    const [otomatik,setOtomatik]=useState(()=>{try{return localStorage.getItem('kpn:otomatik')!=='0';}catch{return true;}});
    const [sporDurum,setSporDurum]=useState({hafta:null,sonuclar:{},zaman:null,hata:'',mesgul:false});
    const [paylasim,setPaylasim]=useState(null);
    const [kartUrl,setKartUrl]=useState('');
    const [duzeltNeden,setDuzeltNeden]=useState('');
    const [ekGunluk,setEkGunluk]=useState([]);
    const [gunlukDurum,setGunlukDurum]=useState('');
    const sporRef=useRef(false);
    useEffect(()=>{try{localStorage.setItem('kpn:otomatik',otomatik?'1':'0');}catch{}},[otomatik]);
    useEffect(()=>{
        if(!paylasim){setKartUrl('');return;}
        const u=URL.createObjectURL(paylasim.blob);setKartUrl(u);return()=>URL.revokeObjectURL(u);
    },[paylasim]);
    useEffect(()=>{setSporDurum({hafta:null,sonuclar:{},zaman:null,hata:'',mesgul:false});setPaylasim(null);setEkGunluk([]);setOzetHafta('');setRakip('');setIstatistikKisi('');},[lig]);
    useEffect(()=>{
        if(!otomatik || !aktif || ekran!=='oyun')return;
        const baslar=(aktif.maclar||[]).map(m=>Number.isFinite(m.baslangic)?m.baslangic:null).filter(t=>t!=null);
        const ilk=baslar.length?Math.min(...baslar):(Number.isFinite(aktif.sonTeslim)?aktif.sonTeslim:Date.now());
        let iptal=false;const controller=new AbortController();
        let intervalId,timeoutId;
        async function run(){
            if(document.hidden||sporRef.current||iptal)return;sporRef.current=true;
            try{const events=await sporVerisi(aktif.hafta,controller.signal);if(!iptal)setSporDurum({hafta:aktif.hafta,sonuclar:sonucHaritasi(events),zaman:Date.now(),hata:'',mesgul:false});}
            catch(e){if(!iptal)setSporDurum(v=>({...v,hata:e.message,mesgul:false}));}
            finally{sporRef.current=false;}
        }
        function start(){run();intervalId=setInterval(run,180000);}
        const delay=ilk-Date.now();
        if(delay>0)timeoutId=setTimeout(start,delay);else start();
        return()=>{iptal=true;clearInterval(intervalId);clearTimeout(timeoutId);controller.abort();};
    },[otomatik,aktif && aktif.hafta,lig,ekran]);
    function sonucHaritasi(events){
        const map={};for(const o of events){const e=apiEslesme(o.strHomeTeam),d=apiEslesme(o.strAwayTeam),s=KAnaliz.finalScore(o);if(e&&d&&s)map[e+'>'+d]=s;}return map;
    }
    async function sporYenile(){
        if(!aktif||sporRef.current)return;sporRef.current=true;setSporDurum(v=>({...v,mesgul:true}));
        try{const events=await sporVerisi(aktif.hafta);setSporDurum({hafta:aktif.hafta,sonuclar:sonucHaritasi(events),zaman:Date.now(),hata:'',mesgul:false});}
        catch(e){setSporDurum(v=>({...v,hata:e.message,mesgul:false}));}finally{sporRef.current=false;}
    }
    async function fiksturCek(){
        kurucuKontrol();const events=await sporVerisi(gelecekHafta),seen=new Set(),liste=[];let baslangic=Infinity;
        for(const o of events){
            const ec=apiEslesme(o.strHomeTeam),dc=apiEslesme(o.strAwayTeam);
            const e=takimlar.findIndex(t=>kodEslesmesi(t.kod)===ec),d=takimlar.findIndex(t=>kodEslesmesi(t.kod)===dc);
            if(e<0||d<0||e===d||seen.has(e)||seen.has(d))throw new Error('Fikstür eksik veya takım eşleşmesi belirsiz. Hazır listeyi kontrol ederek kullan.');
            const time=KAnaliz.eventTime(o);if(time===null)throw new Error('Bazı maçların saati belli değil. İlk maç saatini elle gir.');
            seen.add(e);seen.add(d);liste.push({e,d,baslangic:time,olay:o.idEvent});baslangic=Math.min(baslangic,time);
        }
        if(liste.length!==Math.floor(takimlar.length/2))throw new Error('Servis tam haftayı döndürmedi. Eksik fikstür yüklenmedi.');
        if(baslangic<=Date.now())throw new Error('Bu haftanın ilk maçı başlamış. Geçmiş maçlar için yeni tahmin haftası açılmaz.');
        liste.sort((a,b)=>a.baslangic-b.baslangic);setYeniMac({liste,bekleyen:null});
        setSonTeslim(new Date(baslangic+3*3600000).toISOString().slice(0,16));setBilgi('Fikstür ve Türkiye saati yüklendi. Kontrol edip haftayı aç.');
    }
    function audit(type,detail,changes=[]){return {id:Date.now()+'-'+Math.random().toString(36).slice(2),zaman:Date.now(),kisi:ben.isim,tur:type,detay:detail,degisiklikler:changes};}
    async function gunlukYaz(entry){
        try{await depo.kosulluSet(`kpn:${lig}:gunluk:${entry.id}`,JSON.stringify(entry),null);setEkGunluk(v=>[entry,...v]);}
        catch{setBilgi('İşlem kaydedildi; işlem geçmişi kaydedilemedi. Bağlantını kontrol et.');}
    }
    async function gunlukYukle(){
        setGunlukDurum('Yükleniyor…');
        try{const l=await depo.list(`kpn:${lig}:gunluk:`);const keys=((l && l.keys)||[]).sort().reverse().slice(0,50);const rows=await depo.getMany(keys);setEkGunluk(rows.filter(x=>x && x.value).map(x=>okuJSON(x.value,null)).filter(Boolean));setGunlukDurum('Son 50 ek işlem gösterilir.');}
        catch{setGunlukDurum('İşlem geçmişi alınamadı. Tekrar dene.');}
    }
    async function kartHazirla(h){
        const c=document.createElement('canvas');c.width=1080;
        const list=KAnaliz.rank(h.puanlar),shown=list.slice(0,10);c.height=510+shown.length*88;
        const g=c.getContext('2d');if(!g)throw new Error('Bu cihaz görsel oluşturmayı desteklemiyor.');
        g.fillStyle='#F3E8D6';g.fillRect(0,0,c.width,c.height);
        g.fillStyle='#9C4B3A';g.fillRect(64,64,56,4);g.font='italic 72px Georgia,serif';g.fillStyle='#2C241C';g.fillText('Kupon',64,168);
        g.fillStyle='#7A6E60';g.font='22px system-ui';g.fillText(lig.toUpperCase().slice(0,20)+'  ·  '+TSDB.sezon,64,214);
        g.fillStyle='#2C241C';g.font='bold 40px system-ui';g.fillText(h.no+'. HAFTANIN SONUÇLARI',64,292);
        g.fillStyle='#7A6E60';g.font='22px system-ui';g.fillText('Haftalık tahmin puanı  ·  eşit puanlar aynı sırada',64,336);
        shown.forEach((x,i)=>{
            const y=407+i*88;g.fillStyle=x.sira===1?'#FFF8EC':'#EDE0CC';g.fillRect(64,y-33,952,70);
            g.fillStyle='#2C241C';g.font='bold 30px ui-monospace,monospace';g.fillText(String(x.sira).padStart(2,'0'),86,y+12);
            const oyuncu=kurulum.oyuncular.find(o=>o.slug===x.slug);
            const name=((h.isimler && h.isimler[x.slug])||(oyuncu && oyuncu.isim)||x.slug).slice(0,24);g.fillText(name,164,y+12);
            g.textAlign='right';g.fillText(x.puan+' P',985,y+12);g.textAlign='left';
        });
        g.fillStyle='#7A6E60';g.font='22px system-ui';g.fillText(list.length>10?'İlk 10 oyuncu • Tam tablo oyunda':'Arkadaşlar arasında, sezon boyunca.',64,c.height-48);
        const blob=await new Promise(resolve=>c.toBlob(resolve,'image/png'));if(!blob)throw new Error('Görsel hazırlanamadı.');
        setPaylasim({blob,name:'kupon-hafta-'+h.no+'.png',hafta:h.no});setBilgi('Haftalık kart hazır. İndir veya paylaş.');
    }
    async function kartPaylas(){
        if(!paylasim)return;const f=new File([paylasim.blob],paylasim.name,{type:'image/png'});
        try{if(navigator.canShare && navigator.canShare({files:[f]}))await navigator.share({files:[f],title:'Kupon • '+paylasim.hafta+'. hafta'});else dosyaIndir(paylasim.blob,paylasim.name);}
        catch(e){if(e.name!=='AbortError')setBilgi('Paylaşım açılamadı. Görseli indirip paylaşabilirsin.');}
    }
    function yedekIndir(){
        const data={format:'kupon-arsiv-v1',zaman:new Date().toISOString(),lig,sezon:TSDB.sezon,takimlar,oyuncular:kurulum.oyuncular,tablo,resmi,portfoy:portfoyAcik?portfoy:undefined,magaza,ayakta};
        dosyaIndir(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),'kupon-'+lig+'-arsiv.json');
    }
    const H=React.createElement;
    const prText=(text)=>H('p',{className:'pr-muted'},text);
    const prMetric=(label,value,sub)=>H('div',{className:'pr-metric'},H('span',null,label),H('strong',null,value),sub&&H('small',null,sub));
    function merkezGorunumu(){
        if (!kurulum || !ben) return H('div',{className:'kp-kat'},prText('Grup yükleniyor.'));
        const weeks=(tablo && tablo.haftalar)||[],index=ozetHafta===''?weeks.length-1:weeks.findIndex(h=>String(h.no)===ozetHafta),sum=KAnaliz.summary(weeks,index);
        const name=sl=>{
            const o=kurulum.oyuncular.find(x=>x.slug===sl);
            return (o && o.isim) || (sum && sum.h && sum.h.isimler && sum.h.isimler[sl]) || sl;
        };
        const who=istatistikKisi||ben.slug,st=KAnaliz.stats(weeks,who),opponents=kurulum.oyuncular.filter(o=>o.slug!==ben.slug),other=opponents.some(o=>o.slug===rakip)?rakip:(opponents[0] && opponents[0].slug);
        const du=other?KAnaliz.duel(weeks,ben.slug,other):null;
        const match=(h,i)=>T(h.maclar[i].e).ad+' '+h.sonuclar[i].join('–')+' '+T(h.maclar[i].d).ad;
        return H('section',{className:'pr-root'},
            H('div',{className:'pr-hero'},
                H('div',{className:'pr-catisma'},React.createElement(CatismaFiguru),H('h1',{className:'kp-h'},'Sezon merkezi.')),
                gazeteGorunumu(true)),
            anketGorunumu(),
            H('div',{className:'pr-tabs','aria-label':'Sezon merkezi bölümleri'},[['ozet','Haftalık özet'],['rekabet','Rekabet'],['istatistik','İstatistik'],['koleksiyon','Koleksiyon'],['gecmis','İşlemler'],['ayar','Ayarlar']].map(([id,label])=>H('button',{key:id,className:merkezSekme===id?'on':'','aria-pressed':merkezSekme===id,onClick:()=>{setMerkezSekme(id);if(id==='gecmis')gunlukYukle();}},label))),
            merkezSekme==='ozet'&&H(React.Fragment,null,
                weeks.length?H('label',{className:'pr-label'},'Hafta seç',H('select',{className:'kp-gir',value:sum?String(sum.h.no):'',onChange:e=>{setOzetHafta(e.target.value);setPaylasim(null);}},[...weeks].reverse().map(h=>H('option',{key:h.no,value:String(h.no)},h.no+'. hafta')))):null,
                !sum?H('div',{className:'kp-kat'},H('h2',null,'İlk hafta henüz kapanmadı.'),prText('İlk kuponlar puanlanınca kazanan ve öne çıkan tahminler burada durur.')):H(React.Fragment,null,
                    H('div',{className:'pr-winner'},H('div',{className:'kp-et'},sum.lider.length>1?'HAFTANIN ORTAK LİDERLERİ':'HAFTANIN LİDERİ'),H('h2',null,sum.lider.length?sum.lider.map(x=>name(x.slug)).join(' & '):'Kupon verilmedi'),H('strong',{className:'pr-big'},((sum.lider[0] && sum.lider[0].puan)||0)+' puan'),prText(sum.h.no+'. hafta • Yalnızca haftalık tahmin puanı')),
                    sum.surpriz&&H('div',{className:'kp-kat'},H('div',{className:'kp-et'},'EN AZ BİLİNEN SONUÇ'),H('h3',null,match(sum.h,sum.surpriz.i)),prText(sum.surpriz.toplam+' kişiden '+sum.surpriz.dogru+' kişi sonucu bildi. Bu değerlendirme grubun tahminlerine dayanır.')),
                    sum.tekler.length>0&&H('div',{className:'kp-kat'},H('div',{className:'kp-et'},'TEK BİLENLER'),sum.tekler.map(x=>H('div',{className:'pr-row',key:x.i},H('strong',null,name(x.slug)),H('span',null,match(sum.h,x.i))))),
                    H('div',{className:'kp-kat'},H('div',{className:'kp-et'},'KUPON KLASMANINDA HAREKET'),prText('Bu haftaya kadar biriken tahmin puanları; portföy hariç.'),sum.hareket.map(x=>H('div',{className:'pr-row',key:x.slug},H('span',null,x.sira+'. '+name(x.slug)),H('strong',{className:x.fark>0?'pr-green':''},x.fark===null?'Yeni':x.fark>0?'↑ '+x.fark:x.fark<0?'↓ '+Math.abs(x.fark):'—')))),
                    sum.h.kartlar&&Object.keys(sum.h.kartlar).length?H('div',{className:'kp-kat'},H('div',{className:'kp-et'},'OLAY KARTLARI'),Object.keys(sum.h.kartlar).map(sl=>{const k=sum.h.kartlar[sl],kp=(sum.h.kartPuan&&sum.h.kartPuan[sl])||0,m=sum.h.maclar[k.mac];return H('div',{className:'pr-row',key:sl},H('span',null,name(sl)+' · '+kartEtiket(k.tur)+(m?' · '+T(m.e).kod+'–'+T(m.d).kod:'')),H('strong',{className:kp>0?'pr-green':''},kp>0?'+'+kp:'0'));})):null,
                    H('button',{className:'kp-dg',disabled:mesgul,onClick:()=>guvenliIslem(()=>kartHazirla(sum.h))},'Haftalık paylaşım kartı hazırla'),
                    paylasim&&paylasim.hafta===sum.h.no&&H('div',{className:'kp-kat',style:{marginTop:12}},kartUrl&&H('img',{className:'pr-card-preview',src:kartUrl,alt:sum.h.no+'. haftanın sonuç kartı'}),H('div',{className:'pr-actions'},H('button',{className:'kp-dg2',onClick:()=>dosyaIndir(paylasim.blob,paylasim.name)},'PNG indir'),H('button',{className:'kp-dg2',onClick:kartPaylas},'Paylaş'))))),
            merkezSekme==='rekabet'&&H(React.Fragment,null,
                !du?H('div',{className:'kp-kat'},prText('Karşılaştırma için gruba bir oyuncu daha katılmalı.')):H(React.Fragment,null,
                    H('label',{className:'pr-label'},'Rakibin',H('select',{className:'kp-gir',value:other,onChange:e=>setRakip(e.target.value)},opponents.map(o=>H('option',{key:o.slug,value:o.slug},o.isim)))),
                    H('div',{className:'pr-versus'},H('span',null,ben.isim),H('strong',null,du.a+' : '+du.b),H('span',null,name(other))),
                    H('div',{className:'pr-grid'},prMetric('Beraberlik',du.berabere,'hafta'),prMetric('Ortak katılım',du.haftalar.length,'hafta')),
                    prText('Yalnızca ikinizin de kupon verdiği haftalar karşılaştırılır. Portföy dahil değildir.'),
                    H('div',{className:'kp-kat'},H('div',{className:'pr-row'},H('strong',null,'Ortak haftalarda toplam'),H('strong',null,du.puanA+' – '+du.puanB)),[...du.haftalar].reverse().map(h=>H('div',{className:'pr-row',key:h.no},H('span',null,h.no+'. hafta'),H('strong',null,h.a+' – '+h.b)))),!du.haftalar.length&&prText('İkinizin de katıldığı ilk hafta tamamlanınca karşılaştırma başlayacak.'))),
            merkezSekme==='istatistik'&&H(React.Fragment,null,
                H('label',{className:'pr-label'},'Oyuncu',H('select',{className:'kp-gir',value:who,onChange:e=>setIstatistikKisi(e.target.value)},kurulum.oyuncular.map(o=>H('option',{key:o.slug,value:o.slug},o.isim)))),
                H('div',{className:'pr-grid'},prMetric('Tam skor',KAnaliz.percent(st.tam,st.mac),st.tam+'/'+st.mac+' maç'),prMetric('Doğru sonuç',KAnaliz.percent(st.sonuc,st.mac),st.sonuc+'/'+st.mac+' maç'),prMetric('Banko tam skor',KAnaliz.percent(st.bankoTam,st.banko),st.bankoTam+'/'+st.banko+' banko'),prMetric('En iyi hafta',st.enIyi?st.enIyi.puan+' p':'—',st.enIyi?st.enIyi.no+'. hafta':'Henüz veri yok')),
                H('div',{className:'kp-kat'},H('div',{className:'kp-et'},'SON 5 KATILIM'),!st.form.length?prText('İlk kuponun puanlanınca istatistiklerin burada durur.'):H('div',{className:'pr-form'},st.form.map(x=>H('div',{key:x.no},H('strong',null,x.puan),H('span',null,x.no+'. hafta'))))),
                H('div',{className:'kp-kat'},H('div',{className:'kp-et'},'TAKIM BAZINDA TAHMİN BAŞARISI'),prText('Doğru sonuç oranı; az maçlı örnekler yanıltıcı olabilir.'),Object.entries(st.takimlar).sort((a,b)=>b[1].dogru/b[1].mac-a[1].dogru/a[1].mac||b[1].mac-a[1].mac).map(([idx,x])=>H('div',{className:'pr-row',key:idx},H('span',null,T(+idx).ad),H('strong',null,KAnaliz.percent(x.dogru,x.mac)+' · '+x.dogru+'/'+x.mac))))),
            merkezSekme==='koleksiyon'&&(function(){
                const oy=((kurulum&&kurulum.oyuncular)||[]);
                const kol=oy.map(o=>({o,k:koleksiyon(o.slug)}));
                const sahipler={};
                ROZET_TANIM.forEach(r=>{sahipler[r.id]=[];});
                kol.forEach(x=>x.k.rozet.forEach(r=>{if(sahipler[r.id])sahipler[r.id].push(x.o);}));
                const baron=oy.slice().sort((a,b)=>portfoyPuan(b.slug)-portfoyPuan(a.slug))[0];
                const tamSay=sl=>((tablo&&tablo.haftalar)||[]).reduce((s,h)=>s+((h.detay&&h.detay[sl])||[]).filter(tamSkorPuani).length,0);
                const kirmizi=oy.slice().sort((a,b)=>tamSay(b.slug)-tamSay(a.slug))[0];
                const mansetSay=sl=>{
                    let n=0;
                    ((tablo&&tablo.haftalar)||[]).forEach(h=>{
                        const od=haftaOdul(h);
                        if(od.some(x=>x.unvan==='alim'&&x.slug===sl))n++;
                        if(od.some(x=>x.unvan==='dallama'&&x.slug===sl))n++;
                        if((rezaletListesi(h)[0]||{}).slug===sl)n++;
                    });
                    return n;
                };
                const gazete=oy.slice().sort((a,b)=>mansetSay(b.slug)-mansetSay(a.slug))[0];
                return H(React.Fragment,null,
                    H('div',{className:'kp-kat'},H('div',{className:'kp-et'},'Rozetler'),prText('Kalıcı başarılar. Zor basılır; eşitlikte veya erken sezonda verilmez. Kimde hangisi varsa ve ne gerektiği aşağıda.'),
                        ROZET_TANIM.map(r=>H('div',{key:r.id,className:'rz-soz'},
                            H('div',{className:'rz-soz-ust'},
                                H('span',{className:'rz-cip'},r.ad),
                                H('span',{className:'rz-soz-kim'},
                                    sahipler[r.id].length
                                        ? sahipler[r.id].map(o=>H('span',{key:o.slug,title:o.isim},H(Yuz,{isim:o.isim,boy:26})))
                                        : H('em',null,'Henüz yok'))),
                            H('p',{className:'rz-soz-acik'},r.acik)))),
                    H('div',{className:'kp-kat'},H('div',{className:'kp-et'},'Çerçeveler · sezon sonu'),prText('Şimdilik kim önde, sezon bitince basılır.'),
                        H('div',{className:'cr-sat'},H('span',null,'Altın · şampiyon'),H('strong',null,(klasman[0]&&klasman[0].isim)||'—')),
                        H('div',{className:'cr-sat'},H('span',null,'Kırmızı mühür · tam skor'),H('strong',null,kirmizi?kirmizi.isim+' · '+tamSay(kirmizi.slug):'—')),
                        H('div',{className:'cr-sat'},H('span',null,'Yeşil · portföy'),H('strong',null,baron?baron.isim+' · '+portfoyPuan(baron.slug):'—')),
                        H('div',{className:'cr-sat'},H('span',null,'Manşet'),H('strong',null,gazete?gazete.isim+' · '+mansetSay(gazete.slug):'—'))));
            })(),
            merkezSekme==='gecmis'&&H('div',{className:'kp-kat'},H('h2',null,'İşlem geçmişi'),prText('Bu sürümden itibaren kaydedilen işlemler. Eski değişiklikler geriye dönük oluşturulmaz.'),
                H('button',{className:'kp-dg2',onClick:gunlukYukle},'Geçmişi yenile'),prText(gunlukDurum),
                [...(tablo.gecmis||[]),...ekGunluk].filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i).sort((a,b)=>b.zaman-a.zaman).map(x=>H('article',{className:'pr-log',key:x.id},H('strong',null,x.tur),prText(x.kisi+' · '+new Date(x.zaman).toLocaleString('tr-TR',{timeZone:'Europe/Istanbul'})),H('p',null,x.detay),(x.degisiklikler||[]).map((d,i)=>H('p',{key:i,className:'pr-muted'},d)))),
                !(tablo.gecmis||[]).length&&!ekGunluk.length&&prText('Henüz kayıtlı işlem yok.')),
            merkezSekme==='ayar'&&H(React.Fragment,null,
                H('div',{className:'kp-kat'},H('h2',null,'Sonuç takibi'),H('label',{className:'pr-toggle'},H('input',{type:'checkbox',checked:otomatik,onChange:e=>setOtomatik(e.target.checked)}),'Uygulama açıkken sonuçları otomatik kontrol et'),prText('Üç dakikada bir kontrol edilir. Yalnızca tamamlandı olarak işaretlenen maçlar alınır. Sonuçları kurucu onaylar; hafta kendiliğinden kapanmaz.'),prText('Veri kaynağı: TheSportsDB • '+TSDB.sezon+'. Servis sınırı veya eksik veri durumunda elle giriş kullanılabilir.')),
                H('div',{className:'kp-kat'},H('h2',null,'Arşivin'),prText('Tamamlanmış haftaları ve açık portföyleri JSON olarak indir. PIN ve gizli kuponlar dahil edilmez.'),H('button',{className:'kp-dg2',onClick:yedekIndir},'Sezon arşivini indir')),
                H('div',{className:'kp-kat'},H('h2',null,'Oyun kuralları'),prText('Tam skor 5, doğru gol farkı 3, doğru sonuç 2 puan. Banko iki kat puan verir. En az 5 maçlık haftada tüm sonuçları bilen +5 puan alır.'),prText('Portföy: 70 krediyle 4 takım. Yalnız bir kişinin seçtiği takımın puanı %25 artar. Kuponlar teslimden sonra değiştirilemez. İlk maç başladığında hâlâ kuponu olmayan kişiden 100 €, rulet eli olmayan kişiden 50 € kesilir. Rulet girişi de aynı Keriz Parası kasasına yazılır; ruleti kazanan bu kasayı alır.'),prText('Beraberlik tahmininde doğru sonucu bilmek, gol farkını da bilmek olduğundan 3 puandır. Haftalık ödül eşitlikte o sıraların havuzunu böler. Bankosu tam tutan 1.nin ödülü ikiye katlanır — bu tutar kasaya eklenir.'),prText('Mağaza: biriken ödülle sınırlı stoktan mal alınır. Nakit düşer, servet (nakit + malların bedeli) durur. Zekât yalnızca son kapanan haftanın sonuncusuna gider, en az 0,01 €, geri alınamaz. Market torbası (50 €) isteğe bağlıdır; her kapalı haftada para sıralamasının en düşüğüne gidebilir — zekât alanla aynı kişi olabilir. Nakit yazılmaz, evine erzak sayılır. Herkes o hafta en fazla bir kez gönderir.'),prText('Manşet her kapalı haftanın gazete başlığıdır. Korkunç tahmin mührü, gol uzaklığı 5+ (bankoda 4+) ve 0 puanda basılır. Bidon D\'or anketi: yeni haftada kim Bidon olacak; oy verince kim kime basmış görünür.'),prText('Olay kartı kupona zorunlu. Gol avcısı +3 (haftanın en gollü maçı; eşitlikte hepsi). 0–0 avcısı +4 (haftada 0–0 yoksa puan yok). Sürpriz avcısı +4: kazanan tarafın maç önü yüzdesi %30 veya altı; beraberlik sürprizdir eğer bir taraf %60+ idiyse; birden fazlaysa en düşük gerçekleşen yüzde haftanın sürprizi. Yüzdeler uygulamanın kendi modeli (geçen sezon + lig puanı + son 5), kupon açılınca kilitlenir. Kart kördür; puan klasmana ve haftalık ödüle girer.'),prText('Rozetler sezon içinde basılır ve zor verilir: Baba Vanga (bir haftada 4 tam skor), Wow (8 tutan kart), Hz. Banko (5 ardışık tam banko), Küllerinden doğan (ilk 10 haftayı kupon klasmanında sonuncu kapatıp sonra ilk 2), Portföy Baron’u (10. haftadan sonra 20+ farkla tek lider), Derbi kasabı (derbi skorunu birebir), Kara Kartal modu (sezon boyunca 10 Beşiktaş tam skoru). Ne gerektiği Koleksiyon’da yazıyor. Çerçeveler sezon sonunda: Altın şampiyon, Kırmızı mühür, Yeşil portföy, Manşet.'),prText('Rulet: kupon ve portföyden ayrı. Tura giriş ' + paraYaz(AYAKTA_UCRET) + ', nakitten düşer, Keriz Parası kasasına yazılır. Her hafta bir takım seçersin; yalnız galibiyet yaşatır, berabere ve mağlubiyet eler. Bir takımı turda bir kez kullanırsın. Seçmezsen elenirsin. Her hafta zorunlu. Eller kör: masada yalnız kimlerin girdiği görünür, kimse kimsenin takımını görmez. Kader o kişinin maçı bitince düşer — haftanın tüm maçları beklenmez. Aynı takımı birden fazla kişi seçebilir. Son kalan Keriz Parası kasasını alır (rulet girişleri + katılmayanların cezası). Herkes elenirse kazanan olmaz, kasa sonraki tura kalır.'),prText('Transfer: 17. hafta kapanınca 3 gün, sezonda bir kez. Bir sat, bir al, 5 kredi komisyon. Sattığın takımı geri alamazsın. Seçimler kör; herkes kilitleyince veya süre bitince açılır. Pas da kilitler.'),),
                kurucuMu&&H('div',{className:'kp-kat'},H('h2',null,'Grup ve portföy'),prText('Kör seçim, kayıtlı herkes kilitleyip beklenen kişi sayısına ulaşınca açılır. Sayıyı burada düzelt; gerekirse portföyleri şimdi aç.'),H('label',{className:'pr-label'},'Gruptaki oyuncu sayısı',H('input',{className:'kp-gir',type:'number',min:2,max:18,inputMode:'numeric',value:beklenenGiris,onChange:e=>setBeklenenGiris(e.target.value.replace(/\D/g,'').slice(0,2))})),H('button',{className:'kp-dg2',disabled:mesgul,onClick:()=>guvenliIslem(()=>beklenenAyarla(beklenenGiris))},'Kişi sayısını kaydet'),prText(kilitleyen+' / '+beklenenOyuncu+' kilitledi · kayıtlı '+toplamOyuncu+' kişi.'),!portfoyAcik&&H('button',{className:'kp-dg2',style:{marginTop:8,width:'100%'},disabled:mesgul,onClick:()=>guvenliIslem(portfoyleriAcSimdi)},'Portföyleri şimdi aç')),
                kurucuMu&&H('div',{className:'kp-kat'},H('h2',null,'Kurucu bilgisi'),prText('Kurucunun PIN kodu ve tarayıcı saati bu sürümde sunucu kilidi değildir. Gizli kuponlar için veri tabanı yetkisi ayrıca kurulmalıdır.'))));
    }
    function gazeteGorunumu(zorla) {
        const weeks = (tablo && tablo.haftalar) || [];
        if (!weeks.length || (mansetKapali && !zorla)) return null;
        const m = mansetUret(weeks[weeks.length - 1]);
        if (!m) return null;
        const tarih = new Date(weeks[weeks.length - 1].kapanis || Date.now()).toLocaleDateString("tr-TR", { timeZone: "Europe/Istanbul", day: "numeric", month: "long", year: "numeric" });
        return H("article", { className: "kp-gazete", "aria-label": "Haftanın manşeti" },
            !zorla ? H("button", { className: "kp-gazete-kapa", type: "button", "aria-label": "Kapat", onClick: () => setMansetKapali(true) }, "×") : null,
            H("div", { className: "kp-gazete-name" }, "Kupon"),
            H("div", { className: "kp-gazete-ust" },
                H("span", null, "Spor eki"),
                H("span", null, m.no + ". sayı"),
                H("span", null, tarih)),
            H("h2", { className: "kp-gazete-bas" }, m.baslik),
            H("div", { className: "kp-gazete-govde" },
                H("p", { className: "kp-gazete-dip" }, m.dip),
                m.rez[0] ? H("div", { className: "kp-gazete-rz" },
                    H("span", { className: "kp-rz-muhur" }, RZ_MUHUR),
                    H("span", { className: "kp-gazete-rz-yazi" }, m.rez[0].isim + " · " + m.rez[0].ev + " " + m.rez[0].t[0] + "–" + m.rez[0].t[1] + " yazdı, " + m.rez[0].sn[0] + "–" + m.rez[0].sn[1] + " oldu")) : null));
    }
    function anketGorunumu() {
        if (!aktif || !kurulum) return null;
        const hf = String(aktif.hafta);
        const oylar = (anket && anket[hf]) || {};
        const benim = oylar[ben.slug];
        const aday = ((kurulum && kurulum.oyuncular) || []);
        const say = {};
        Object.values(oylar).forEach(sl => { say[sl] = (say[sl] || 0) + 1; });
        return H("div", { className: "kp-kat" },
            H("div", { className: "kp-et" }, "Bidon D'or anketi"),
            H("p", { style: { fontSize: 15, fontWeight: 600, margin: "0 0 12px", lineHeight: 1.4 } }, "Yeni haftada kim Bidon olacak?"),
            benim
                ? H(React.Fragment, null,
                    Object.entries(oylar).map(([veren, alan]) => H("div", { key: veren, className: "pr-row" },
                        H("span", null, oyuncuAd(veren) + " → " + oyuncuAd(alan)),
                        H("strong", { className: "kp-mono" }, (say[alan] || 0)))))
                : H("div", { style: { display: "flex", flexWrap: "wrap", gap: 8 } },
                    aday.map(o => H("button", {
                        key: o.slug, className: "kp-dg2", type: "button",
                        style: { width: "auto", padding: "10px 14px", margin: 0 },
                        disabled: mesgul,
                        onClick: () => guvenliIslem(() => anketOyVer(o.slug)),
                    }, o.isim))));
    }

    /* ---------- otomatik yenileme ----------
       Veri eskiden yalnızca sayfa ilk açıldığında çekiliyordu; telefon sekmeyi
       bellekte tuttuğu için kullanıcı uygulamayı "açtığında" eski hafta kalıyordu. */
    useEffect(() => {
        if (!lig || !ben) return;
        let mesgul = false;
        const tazele = async () => {
            if (mesgul || document.hidden || islemRef.current) return;
            mesgul = true;
            try { await veriYukle(lig, ben.slug); } catch (e) { }
            mesgul = false;
        };
        const gorunurluk = () => { if (!document.hidden) tazele(); };
        document.addEventListener("visibilitychange", gorunurluk);
        window.addEventListener("focus", tazele);
        const saat = setInterval(tazele, 60000);
        return () => {
            document.removeEventListener("visibilitychange", gorunurluk);
            window.removeEventListener("focus", tazele);
            clearInterval(saat);
        };
    }, [lig, ben]);
    /* ---------- açılış ---------- */
    useEffect(() => {
        (async () => {
            try {
                if (MISAFIR) {
                    setYukleniyor(true);
                    const lg = misafirLigOku();
                    if (lg) {
                        setLig(lg);
                        try { await misafirAc(lg); }
                        catch (e) { setBilgi(e.message || "Grup bulunamadı."); setEkran("giris"); }
                    } else setEkran("giris");
                    setYukleniyor(false);
                    return;
                }
                const k = await depo.get("kpn:kimlik", false);
                if (k === null || k === void 0 ? void 0 : k.value) {
                    const p = okuJSON(k.value, null);
                    if (!p || !p.lig || !p.isim) throw new Error("kimlik");
                    setYukleniyor(true);
                    setLig(p.lig);
                    setIsim(p.isim);
                    await girisDene(p.lig, p.isim, true);
                }
            }
            catch (e) { }
            setYukleniyor(false);
        })();
    }, []);
    async function veriYukle(lg, benSlug) {
        const [ku, ak, tb, pf, rs, pa, mg, an, tr, ay] = await Promise.all([
            depo.get(`kpn:${lg}:kurulum`), depo.get(`kpn:${lg}:aktif`),
            depo.get(`kpn:${lg}:tablo`), depo.get(`kpn:${lg}:portfoy`),
            depo.get(`kpn:${lg}:resmi`), depo.get(`kpn:${lg}:portfoyAcik`),
            depo.get(`kpn:${lg}:magaza`), depo.get(`kpn:${lg}:anket`),
            depo.get(`kpn:${lg}:transfer`), depo.get(`kpn:${lg}:ayakta`),
        ]);
        const kur = okuJSON(ku === null || ku === void 0 ? void 0 : ku.value, null);
        const akt = okuJSON(ak === null || ak === void 0 ? void 0 : ak.value, null);
        const tbl = okuJSON(tb === null || tb === void 0 ? void 0 : tb.value, { toplam: {}, haftalar: [], ligTablo: {} }) || { toplam: {}, haftalar: [], ligTablo: {} };
        const pfy = okuJSON(pf === null || pf === void 0 ? void 0 : pf.value, {}) || {};
        const rsm = okuJSON(rs === null || rs === void 0 ? void 0 : rs.value, null);
        setKurulum(kur);
        if (kur && kur.beklenen) setBeklenenGiris(String(kur.beklenen));
        const etkin=akt && !tbl.haftalar.some(h=>h.no===akt.hafta) ? akt : null;
        setAktif(etkin);
        setTablo(tbl);
        setPortfoy(pfy);
        setResmi(rsm);
        setPortfoyAcik((pa === null || pa === void 0 ? void 0 : pa.value) === "1");
        const mgv = okuJSON(mg === null || mg === void 0 ? void 0 : mg.value, MAGAZA_BOS) || MAGAZA_BOS;
        setMagaza({
            alimlar: Array.isArray(mgv.alimlar) ? mgv.alimlar : [],
            zekat: Array.isArray(mgv.zekat) ? mgv.zekat : [],
            erzak: Array.isArray(mgv.erzak) ? mgv.erzak : [],
            cezalar: Array.isArray(mgv.cezalar) ? mgv.cezalar : [],
        });
        setAnket(okuJSON(an === null || an === void 0 ? void 0 : an.value, {}) || {});
        setTransfer(okuJSON(tr === null || tr === void 0 ? void 0 : tr.value, null));
        setAyakta(ayaktaNorm(okuJSON(ay === null || ay === void 0 ? void 0 : ay.value, AYAKTA_BOS)));
        if (etkin) await kuponlariYukle(lg, etkin.hafta, benSlug);
        else {setKuponlar({});setBenimKupon(null);}
        return { kur, akt:etkin, tbl, pfy };
    }
    async function resmiKaydet() {
        kurucuKontrol();
        const temiz = {};
        Object.entries(resmiTaslak).forEach(([i, v]) => { if (v !== "" && v !== null && !isNaN(+v))
            temiz[i] = +v; });
        const kayit = { puanlar: temiz, guncelleyen: ben.isim, zaman: Date.now(), haftaSayisi: tablo.haftalar.length, tabloIzi: KAnaliz.stamp(tablo.haftalar) };
        await depo.set(`kpn:${lig}:resmi`, JSON.stringify(kayit));
        setResmi(kayit);
        setResmiTaslak(null);
        setBilgi("Resmi puanlar kaydedildi. Portföy puanları artık buradan hesaplanıyor.");
        await gunlukYaz(audit('Resmî puanlar güncellendi', Object.keys(temiz).length+' takımın puanı kaydedildi.',Object.entries(temiz).map(([i,p])=>T(+i).ad+': '+(resmi && resmi.puanlar && resmi.puanlar[i] != null ? resmi.puanlar[i] : '—')+' → '+p)));
    }
    async function resmiSil() {
        kurucuKontrol();
        await depo.set(`kpn:${lig}:resmi`, JSON.stringify(null));
        setResmi(null);
        setResmiTaslak(null);
        setBilgi("Resmi puanlar silindi. Portföy yine kupon sonuçlarından hesaplanıyor.");
        await gunlukYaz(audit('Resmî puanlar kaldırıldı','Portföy hesabı girilmiş maç sonuçlarına döndü.'));
    }
    async function kuponlariYukle(lg, hafta, benSlug) {
        try {
            const l = await depo.list(`kpn:${lg}:kupon:${hafta}:`);
            const rows = await depo.getMany((l === null || l === void 0 ? void 0 : l.keys) || []);
            const out = {};
            for (const v of rows) {
                const p = okuJSON(v && v.value, null);
                if (!p || !p.slug) continue;
                out[p.slug] = p.slug === benSlug
                    ? p
                    : { slug: p.slug, isim: p.isim, yatirildi: true };
            }
            setKuponlar(out);
            if (benSlug && out[benSlug] && out[benSlug].tahminler)
                setBenimKupon(out[benSlug]);
            else
                setBenimKupon(null);
        }
        catch (e) { throw e; }
    }
    async function misafirAc(lg) {
        const kod = String(lg || "").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20);
        if (!kod) throw new Error("Grup kodunu gir.");
        setMesgul(true);
        try {
            const { kur } = await veriYukle(kod, "");
            if (!kur) throw new Error("Bu grup kodu yok veya henüz kurulmamış.");
            setLig(kod);
            setBen({ slug: "", isim: "Misafir", misafir: true });
            setEkran("oyun");
            setSekme("merkez");
        } finally { setMesgul(false); }
    }
    /* Kimlik denetimi: PIN yoksa kurdurur, varsa cihaz doğrulanmamışsa sorar */
    async function girisDene(lg, ad, otomatik) {
        if (!lg.trim() || !ad.trim())
            return;
        setMesgul(true);
        setPinHata("");
        setPin("");
        setPin2("");
        const s = slug(ad);
        try {
            const kayit = await depo.get(`kpn:${lg}:kimlik:${s}`);
            const sunucuKayit = okuJSON(kayit === null || kayit === void 0 ? void 0 : kayit.value, null);
            const sunucu = sunucuKayit && sunucuKayit.karma ? sunucuKayit.karma : null;
            const cihaz = localStorage.getItem(`kpn:cihaz:${lg}:${s}`);
            if (sunucu && cihaz === sunucu) {
                setMesgul(false);
                await ligeGir(lg, ad, otomatik);
                return;
            }
            setPinEkrani({ lig: lg, isim: ad.trim(), slug: s, yeni: !sunucu, sunucu });
            setEkran("pin");
        }
        catch (e) {
            setBilgi("Bağlantı kurulamadı. İnternetini kontrol edip tekrar dene.");
        }
        setMesgul(false);
    }
    async function pinOnayla() {
        const { lig: lg, isim, slug: s, yeni, sunucu } = pinEkrani;
        if (!/^\d{4}$/.test(pin)) {
            setPinHata("PIN 4 rakam olmalı.");
            return;
        }
        setMesgul(true);
        setPinHata("");
        try {
            const karma = await pinKarma(lg, s, pin);
            if (yeni) {
                if (pin !== pin2) {
                    setPinHata("İki PIN aynı değil.");
                    setMesgul(false);
                    return;
                }
                await depo.kosulluSet(`kpn:${lg}:kimlik:${s}`, JSON.stringify({ karma, olusturma: Date.now() }), null);
            }
            else if (karma !== sunucu) {
                setPinHata("PIN yanlış.");
                setPin("");
                setMesgul(false);
                return;
            }
            localStorage.setItem(`kpn:cihaz:${lg}:${s}`, karma);
            setMesgul(false);
            await ligeGir(lg, isim, false);
            setPinEkrani(null);
            setPin("");
            setPin2("");
            return;
        }
        catch (e) {
            setPinHata("Kaydedilemedi, tekrar dene.");
        }
        setMesgul(false);
    }
    async function ligeGir(lg, ad, sessiz) {
        if (!lg.trim() || !ad.trim())
            return;
        setMesgul(true);
        const s = slug(ad);
        const kimlik = { lig: lg, isim: ad.trim(), slug: s };
        setBen(kimlik);
        const { kur } = await veriYukle(lg, s);
        if (!kur) {
            setTakimDuzen(VARSAYILAN_TAKIMLAR.map(t => ({ ...t })));
            setEkran("takimlar");
        }
        else {
            // katılımcı listesine ekle
            if (!kur.oyuncular.some(o => o.slug === s)) {
                const y = { ...kur, oyuncular: [...kur.oyuncular, { slug: s, isim: ad.trim() }] };
                await depo.kosulluSet(`kpn:${lg}:kurulum`, JSON.stringify(y), JSON.stringify(kur));
                setKurulum(y);
            }
            const pf = await depo.get(`kpn:${lg}:portfoy`);
            const pfy = okuJSON(pf === null || pf === void 0 ? void 0 : pf.value, {}) || {};
            if (!pfy[s]) {
                setPortfoySecim([]);
                setEkran("portfoyKur");
            }
            else
                setEkran("oyun");
        }
        await depo.set("kpn:kimlik", JSON.stringify(kimlik), false);
        setMesgul(false);
    }
    async function kurulumBitir() {
        const n = Math.max(2, Math.min(18, parseInt(beklenenGiris, 10) || TAKMA_ADLAR.length));
        const kadro = takimDuzen.filter(t => (t.ad || "").trim() && (t.kod || "").trim()).map(t => ({
            ad: t.ad.trim(), kod: String(t.kod).trim().toUpperCase(),
            gp: Number.isFinite(+t.gp) ? Math.max(0, Math.min(102, +t.gp)) : 35,
            yeni: !!t.yeni,
        }));
        if (kadro.length < 2) throw new Error("En az iki takım olmalı.");
        const mevcut = await depo.get(`kpn:${lig}:kurulum`);
        if (mevcut && mevcut.value) throw new Error("Bu grup kodu zaten alınmış. Başka bir kod dene veya o gruba PIN ile gir.");
        const kur = { ad: lig, takimlar: kadro, oyuncular: [{ slug: ben.slug, isim: ben.isim }], kuran: ben.slug, beklenen: n };
        await depo.kosulluSet(`kpn:${lig}:kurulum`, JSON.stringify(kur), null);
        const tab = { toplam: {}, haftalar: [], ligTablo: {} };
        const tabKayit = await depo.get(`kpn:${lig}:tablo`);
        if (!(tabKayit && tabKayit.value))
            await depo.set(`kpn:${lig}:tablo`, JSON.stringify(tab));
        setKurulum(kur);
        setTablo(tab);
        setPortfoySecim([]);
        setEkran("portfoyKur");
    }
    async function beklenenAyarla(n) {
        kurucuKontrol();
        const n2 = Math.max(2, Math.min(18, parseInt(n, 10) || 0));
        if (n2 < 2) throw new Error("En az 2 kişi olmalı.");
        const kayit = await depo.get(`kpn:${lig}:kurulum`);
        const kur = okuJSON(kayit && kayit.value, null);
        if (!kur) throw new Error("Kurulum bulunamadı. Sayfayı yenile.");
        const y = { ...kur, beklenen: n2 };
        await depo.kosulluSet(`kpn:${lig}:kurulum`, JSON.stringify(y), kayit.value);
        setKurulum(y);
        setBeklenenGiris(String(n2));
        setBilgi("Grup " + n2 + " kişi olarak kaydedildi. Portföyler herkes kilitleyince açılır.");
    }
    async function portfoyleriAcSimdi() {
        kurucuKontrol();
        if (portfoyAcik) { setBilgi("Portföyler zaten açık."); return; }
        await depo.set(`kpn:${lig}:portfoyAcik`, "1");
        setPortfoyAcik(true);
        setBilgi("Portföyler açıldı. Artık herkes birbirinin takımlarını görüyor.");
        await gunlukYaz(audit("Portföyler açıldı", "Kurucu kör seçimi sonlandırdı."));
    }
    async function portfoyKaydet() {
        const maliyet = portfoySecim.reduce((s, i) => s + fiyat(takimlar[i]), 0);
        if (portfoySecim.length !== PORTFOY_ADET) {
            setBilgi(`${PORTFOY_ADET} takım seçmelisin.`);
            return;
        }
        if (maliyet > KREDI) {
            setBilgi("Kredi yetmiyor.");
            return;
        }
        const kayit = await depo.get(`kpn:${lig}:portfoy`);
        const guncel = (kayit && kayit.value ? okuJSON(kayit.value, {}) : {}) || {};
        if (guncel[ben.slug]) throw new Error("Portföyün zaten kilitli. Sayfayı yenile.");
        const y = { ...guncel, [ben.slug]: { isim: ben.isim, takimlar: portfoySecim, harcanan: maliyet } };
        await depo.kosulluSet(`kpn:${lig}:portfoy`, JSON.stringify(y), kayit ? kayit.value : null);
        setPortfoy(y);
        setEkran("oyun");
        setSekme("kupon");
    }
    /* ---------- hafta aç ---------- */
    async function haftayiAc() {
        kurucuKontrol();
        if (yeniMac.liste.length === 0) {
            setBilgi("En az bir maç ekle.");
            return;
        }
        const hafta = ((tablo === null || tablo === void 0 ? void 0 : tablo.haftalar.length) || 0) + 1;
        const zaman = teslimZamani();
        if (!Number.isFinite(zaman) || zaman <= Date.now()) throw new Error("İlk maç için gelecekte bir tarih ve saat gir.");
        const mevcut = await depo.get(`kpn:${lig}:aktif`);
        const mevcutAktif = mevcut && okuJSON(mevcut.value, null);
        if (mevcutAktif && !tablo.haftalar.some(h=>h.no===mevcutAktif.hafta)) throw new Error("Açık bir hafta zaten var. Sayfayı yenile.");
        if(yeniMac.liste.some(m=>Number.isFinite(m.baslangic)&&zaman>m.baslangic))throw new Error('Teslim saati ilk maç başlangıcından sonra olamaz.');
        const a = { hafta, maclar: yeniMac.liste, kuran: ben.isim, acilis: Date.now(), sonTeslim: zaman, oranlar: macOranlari(yeniMac.liste, takimlar, (tablo && tablo.haftalar) || []) };
        await depo.kosulluSet(`kpn:${lig}:aktif`, JSON.stringify(a), mevcut ? mevcut.value : null);
        setAktif(a);
        setKuponlar({});
        setBenimKupon(null);
        setYeniMac({ liste: [], bekleyen: null });
        await gunlukYaz(audit('Hafta açıldı',hafta+'. hafta · son teslim '+new Date(zaman).toLocaleString('tr-TR',{timeZone:'Europe/Istanbul'})));
    }
    function takimTikla(i) {
        if (yeniMac.liste.length >= 12)
            return;
        if (yeniMac.bekleyen === null)
            setYeniMac({ ...yeniMac, bekleyen: i });
        else if (yeniMac.bekleyen === i)
            setYeniMac({ ...yeniMac, bekleyen: null });
        else
            setYeniMac({ liste: [...yeniMac.liste, { e: yeniMac.bekleyen, d: i }], bekleyen: null });
    }
    const kullanilan = new Set(yeniMac.liste.reduce((a, m) => a.concat([m.e, m.d]), []).concat(yeniMac.bekleyen !== null ? [yeniMac.bekleyen] : []));
    const gelecekHafta = ((tablo === null || tablo === void 0 ? void 0 : tablo.haftalar.length) || 0) + 1;
    const hazir = HAZIR_FIKSTUR[gelecekHafta];
    const hazirCozum = useMemo(() => {
        if (!hazir)
            return null;
        const bul = (kod) => takimlar.findIndex(t => t.kod === kod);
        const liste = [];
        for (const [e, d] of hazir.maclar) {
            const ei = bul(e), di = bul(d);
            if (ei < 0 || di < 0)
                return null;
            liste.push({ e: ei, d: di });
        }
        return liste;
    }, [hazir, takimlar]);
    /* ---------- kupon doldur ---------- */
    const [taslak, setTaslak] = useState(null);
    useEffect(() => {
        if (aktif && !benimKupon)
            setTaslak({ tahminler: aktif.maclar.map(() => [1, 1]), joker: 0, kart: { tur: null, mac: null } });
        else if (benimKupon)
            setTaslak(null);
        setKuponOnay(false);
    }, [aktif === null || aktif === void 0 ? void 0 : aktif.hafta, benimKupon]);
    async function kuponVer() {
        const kayit = await depo.get(`kpn:${lig}:aktif`);
        const a = kayit && okuJSON(kayit.value, null);
        if (!a || a.hafta !== aktif.hafta || !Number.isFinite(a.sonTeslim) || Date.now() >= a.sonTeslim)
            throw new Error("Kupon teslim süresi kapalı. Sayfayı yenile.");
        if(JSON.stringify(a.maclar.map(m=>[m.e,m.d]))!==JSON.stringify(aktif.maclar.map(m=>[m.e,m.d])))throw new Error('Maç listesi değişti. Sayfayı yenile.');
        const onceki = await depo.get(`kpn:${lig}:kupon:${aktif.hafta}:${ben.slug}`);
        if (onceki && onceki.value) throw new Error("Kuponun zaten kayıtlı. Değiştirilemez; sayfayı yenile.");
        if (!taslak || taslak.tahminler.length !== a.maclar.length || !taslak.tahminler.every(x => x.length === 2 && x.every(n => Number.isInteger(n) && n >= 0 && n <= 9)))
            throw new Error("Tahminleri kontrol et.");
        if (!taslak.kart || !taslak.kart.tur || taslak.kart.mac == null)
            throw new Error("Olay kartı seç: tür ve maç.");
        if (!KARTLAR.some(x => x.id === taslak.kart.tur) || +taslak.kart.mac < 0 || +taslak.kart.mac >= a.maclar.length)
            throw new Error("Olay kartı geçersiz.");
        const k = { slug: ben.slug, isim: ben.isim, hafta: aktif.hafta, tahminler: taslak.tahminler, joker: taslak.joker, kart: { tur: taslak.kart.tur, mac: +taslak.kart.mac }, zaman: Date.now() };
        await depo.kosulluSet(`kpn:${lig}:kupon:${aktif.hafta}:${ben.slug}`, JSON.stringify(k), null);
        setBenimKupon(k);
        setKuponlar({ ...kuponlar, [ben.slug]: k });
        setBilgi("Kuponun yatırıldı ve kilitlendi. Bol şans.");
        setKuponOnay(false);
    }
    /* ---------- haftayı kapat ---------- */
    /* Kendi takım kodumuzu sözlükteki anahtara çevirir (GÖZ -> GOZ gibi) */
    const kodEslesmesi = (kod) => {
        const sade = (kod || "").replace(/Ö/g, "O").replace(/Ç/g, "C").replace(/İ/g, "I").replace(/Ğ/g, "G").replace(/Ü/g, "U").replace(/Ş/g, "S");
        return sade;
    };
    const ayaktaMacRef = useRef(false);
    useEffect(() => {
        if (MISAFIR) return;
        if (ekran !== "oyun" || !aktif || !(ayakta.canli || []).length) return;
        if (sporDurum.hafta !== aktif.hafta) return;
        const map = sporDurum.sonuclar || {};
        const sonuclar = (aktif.maclar || []).map(function (m) {
            const key = kodEslesmesi(T(m.e).kod) + ">" + kodEslesmesi(T(m.d).kod);
            const s = map[key];
            return s && s[0] != null && s[1] != null ? s : [null, null];
        });
        if (!sonuclar.some(function (s) { return s && s[0] != null; })) return;
        if (ayaktaMacRef.current) return;
        ayaktaMacRef.current = true;
        ayaktaSonucIsle({ no: aktif.hafta, maclar: aktif.maclar, sonuclar: sonuclar }, { teslimKapali: ruletKapali, zorla: false })
            .catch(function () {})
            .finally(function () { ayaktaMacRef.current = false; });
    }, [sporDurum.zaman, aktif && aktif.hafta, ekran, teslimKapali, ruletKapali]);
    async function sonucCek() {
        setCekiyor(true);setBilgi('');
        try {
            const events=await sporVerisi(aktif.hafta),harita=sonucHaritasi(events);
            const y=(sonucGiris||aktif.maclar.map(()=>[null,null])).map(x=>[...x]);let bulunan=0;
            aktif.maclar.forEach((m,i)=>{const key=kodEslesmesi(T(m.e).kod)+'>'+kodEslesmesi(T(m.d).kod);if(harita[key]){y[i]=harita[key];bulunan++;}});
            setSonucGiris(y);setSporDurum({hafta:aktif.hafta,sonuclar:harita,zaman:Date.now(),hata:'',mesgul:false});
            setBilgi(bulunan+' / '+aktif.maclar.length+' maç için kesinleşmiş sonuç alındı. Eksikleri kontrol edip elle tamamla.');
        } catch(e){setBilgi(e.message+' Skorları elle girebilirsin.');}
        finally{setCekiyor(false);}
    }
        /* Bir haftanın puanlarını saklı tahminlerden yeniden hesaplar */
    function haftaPuanla(maclar, sonuclar, tahminler, jokerler) {
        const puanlar = {}, detay = {};
        Object.keys(tahminler || {}).forEach(slug => {
            const th = tahminler[slug] || [];
            const jk = (jokerler || {})[slug];
            let toplam = 0, dogruSonuc = 0;
            const dt = maclar.map((_, i) => {
                let p = macPuani(th[i], sonuclar[i]);
                if (p >= 2) dogruSonuc++;
                if (jk === i) p *= 2;
                toplam += p;
                return p;
            });
            if (dogruSonuc === maclar.length && maclar.length >= 5) toplam += 5;
            puanlar[slug] = toplam; detay[slug] = dt;
        });
        return { puanlar, detay };
    }

    /* Tüm tabloyu haftalardan sıfırdan kurar: toplam puanlar + lig tablosu */
    function tabloyuKur(haftalar) {
        const toplam = {}, ligTablo = {};
        const islenmis = [];
        haftalar.forEach(h => {
            const oranlar = (h.oranlar && h.oranlar.length === (h.maclar || []).length)
                ? h.oranlar
                : macOranlari(h.maclar, takimlar, islenmis);
            h.oranlar = oranlar;
            const { puanlar, detay } = haftaPuanla(h.maclar, h.sonuclar, h.tahminler, h.jokerler);
            h.kartPuan = {};
            Object.keys(puanlar).forEach(sl => {
                const kp = kartPuan((h.kartlar || {})[sl], h.sonuclar, oranlar);
                h.kartPuan[sl] = kp;
                puanlar[sl] += kp;
            });
            h.puanlar = puanlar; h.detay = detay;
            Object.entries(puanlar).forEach(([sl, p]) => { toplam[sl] = (toplam[sl] || 0) + p; });
            h.maclar.forEach((m, i) => {
                const eg = h.sonuclar[i][0], dg = h.sonuclar[i][1];
                if (eg === null || dg === null) return;
                [m.e, m.d].forEach(t => { if (!ligTablo[t]) ligTablo[t] = bosSatir(); });
                const E = ligTablo[m.e], D = ligTablo[m.d];
                E.o++; D.o++; E.ag += eg; E.yg += dg; D.ag += dg; D.yg += eg;
                if (eg > dg) { E.g++; E.p += 3; D.m++; }
                else if (eg === dg) { E.b++; D.b++; E.p++; D.p++; }
                else { D.g++; D.p += 3; E.m++; }
            });
            islenmis.push(h);
        });
        return { toplam, haftalar, ligTablo };
    }

    /* Kapanmış bir haftanın skorunu düzelt */
    async function haftaSkorDuzelt(idx,yeniSonuclar) {
        kurucuKontrol();
        if(!duzeltNeden.trim())throw new Error('Skor düzeltme nedenini yaz.');
        if(!(tablo && tablo.haftalar[idx])||!yeniSonuclar.every(KAnaliz.valid))throw new Error('Tüm sonuçları geçerli sayılarla gir.');
        const record=await depo.get(`kpn:${lig}:tablo`),current=record&&okuJSON(record.value, null);
        if(!current||JSON.stringify(current)!==JSON.stringify(tablo))throw new Error('Tablo başka bir cihazda değişti. Yenileyip tekrar dene.');
        const old=current.haftalar[idx],changes=old.maclar.map((m,i)=>({m,i})).filter(({i})=>JSON.stringify(old.sonuclar[i])!==JSON.stringify(yeniSonuclar[i])).map(({m,i})=>T(m.e).kod+' – '+T(m.d).kod+': '+old.sonuclar[i].join('–')+' → '+yeniSonuclar[i].join('–'));
        if(!changes.length){setDuzeltHafta(null);return;}
        const copy=JSON.parse(JSON.stringify(current.haftalar));copy[idx].sonuclar=yeniSonuclar;
        const yeni=tabloyuKur(copy);
        const ranks=Object.fromEntries(KAnaliz.rank(current.toplam).map(x=>[x.slug,x.sira]));
        KAnaliz.rank(yeni.toplam).forEach(x=>{const oy=kurulum.oyuncular.find(o=>o.slug===x.slug);if(ranks[x.slug]!==x.sira)changes.push(((oy && oy.isim)||x.slug)+': kupon klasmanı '+ranks[x.slug]+'. → '+x.sira+'.');});
        yeni.gecmis=[...(current.gecmis||[]),audit('Skor düzeltildi',old.no+'. hafta · '+duzeltNeden.trim(),changes)];
        await depo.kosulluSet(`kpn:${lig}:tablo`,JSON.stringify(yeni),record.value);
        setTablo(yeni);setDuzeltHafta(null);setDuzeltNeden('');setBilgi(old.no+'. hafta yeniden hesaplandı.');
    }
    async function haftayiKapat() {
        kurucuKontrol();
        if(!sonucGiris||!sonucGiris.every(KAnaliz.valid))throw new Error('Tüm maçların kesin sonuçlarını gir.');
        const [activeRecord,tableRecord]=await Promise.all([depo.get(`kpn:${lig}:aktif`),depo.get(`kpn:${lig}:tablo`)]);
        const a=activeRecord&&okuJSON(activeRecord.value, null),current=tableRecord&&okuJSON(tableRecord.value, null);
        if(!a||a.hafta!==aktif.hafta||!current)throw new Error('Hafta değişti. Sayfayı yenile.');
        if(!Number.isFinite(a.sonTeslim)||Date.now()<a.sonTeslim)throw new Error('Önce kupon teslim süresi dolmalı.');
        if(current.haftalar.some(h=>h.no===a.hafta))throw new Error('Bu hafta zaten puanlanmış. Sayfayı yenile.');
        if(a.maclar.length!==sonucGiris.length)throw new Error('Maç listesi değişti. Sayfayı yenile.');
        const l=await depo.list(`kpn:${lig}:kupon:${a.hafta}:`);
        const rows=await depo.getMany(((l && l.keys)||[])),hepsi={};
        rows.forEach(v=>{const kp=okuJSON(v&&v.value, null);if(kp&&kp.slug)hepsi[kp.slug]=kp;});
        const h={no:a.hafta,maclar:a.maclar,sonuclar:sonucGiris,jokerler:Object.fromEntries(Object.values(hepsi).map(k=>[k.slug,k.joker])),tahminler:Object.fromEntries(Object.values(hepsi).map(k=>[k.slug,k.tahminler])),kartlar:Object.fromEntries(Object.values(hepsi).filter(k=>k.kart).map(k=>[k.slug,k.kart])),oranlar:a.oranlar||macOranlari(a.maclar,takimlar,(current.haftalar)||[]),isimler:Object.fromEntries(Object.values(hepsi).map(k=>[k.slug,k.isim])),kapanis:Date.now()};
        const yeni=tabloyuKur([...current.haftalar,h]);yeni.gecmis=[...(current.gecmis||[]),audit('Hafta kapatıldı',a.hafta+'. hafta · '+Object.keys(hepsi).length+' kupon puanlandı.')];
        await depo.kosulluSet(`kpn:${lig}:tablo`,JSON.stringify(yeni),tableRecord.value);
        // Archive is authoritative. A failed cleanup cannot score the same week twice.
        try{await depo.kosulluSet(`kpn:${lig}:aktif`,JSON.stringify(null),activeRecord.value);}catch{}
        setTablo(yeni);setAktif(null);setSonucGiris(null);setBenimKupon(null);setKuponlar({});setAcikHafta(yeni.haftalar.length-1);setSekme('merkez');setMerkezSekme('ozet');setOzetHafta(String(a.hafta));
        try {
            const ayMes = await ayaktaHaftaBitir(h);
            setBilgi(a.hafta + '. hafta kapandı.' + (ayMes ? ' ' + ayMes : ''));
        } catch (e) {
            setBilgi(a.hafta + '. hafta kapandı. Rulet güncellenemedi: ' + (e && e.message ? e.message : 'hata'));
        }
    }
    /* ---------- hesaplamalar ---------- */
    const ligSirali = useMemo(() => {
        if (!tablo)
            return [];
        return Object.entries(tablo.ligTablo).map(([i, s]) => ({ i: +i, ...s, av: s.ag - s.yg }))
            .sort((a, b) => b.p - a.p || b.av - a.av || b.ag - a.ag);
    }, [tablo]);
    const takimPuan = (i) => {
        var _a, _b;
        const r = (_a = resmi && resmi.tabloIzi === KAnaliz.stamp(tablo.haftalar) ? resmi.puanlar : null) === null || _a === void 0 ? void 0 : _a[i];
        return (r !== undefined && r !== null) ? r : (((_b = tablo === null || tablo === void 0 ? void 0 : tablo.ligTablo[i]) === null || _b === void 0 ? void 0 : _b.p) || 0);
    };
    // Kör seçim: portföyler ancak kayıtlı herkes kilitleyince açılır, sonra açık kalır
    const kilitleyen = ((kurulum === null || kurulum === void 0 ? void 0 : kurulum.oyuncular) || []).filter(o => portfoy[o.slug]).length;
    const toplamOyuncu = ((kurulum === null || kurulum === void 0 ? void 0 : kurulum.oyuncular) || []).length;
    const beklenenOyuncu = ((kurulum === null || kurulum === void 0 ? void 0 : kurulum.beklenen) || TAKMA_ADLAR.length);
    const hepsiKilitli = toplamOyuncu >= beklenenOyuncu && kilitleyen >= beklenenOyuncu;
    useEffect(() => {
        if (hepsiKilitli && !portfoyAcik && lig) {
            setPortfoyAcik(true);
            depo.set(`kpn:${lig}:portfoyAcik`, "1").catch(() => { });
        }
    }, [hepsiKilitli, portfoyAcik, lig]);
    const sahipSayisi = (i) => portfoyAcik ? Object.values(portfoy).filter(p => p.takimlar.includes(+i)).length : 0;
    const takimKatki = (i) => {
        const b = takimPuan(i);
        return sahipSayisi(i) === 1 ? Math.round(b * TEK_SAHIP_CARPAN) : b;
    };
    const portfoyPuan = (s) => { var _a; return (((_a = portfoy[s]) === null || _a === void 0 ? void 0 : _a.takimlar) || []).reduce((t, i) => t + takimKatki(i), 0); };
    const klasman = useMemo(() => {
        if (!kurulum || !tablo)
            return [];
        return kurulum.oyuncular.map(o => {
            const kupon = tablo.toplam[o.slug] || 0;
            const pf = portfoyPuan(o.slug);
            return { ...o, kupon, portfoy: pf, genel: kupon + pf };
        }).sort((a, b) => b.genel - a.genel);
    }, [kurulum, tablo, portfoy, resmi]);
    /* ================= EK GÖRÜNÜMLER =================
       Hepsi mevcut veriden türetilir; puanlama ve kayıt mantığına dokunmaz. */

    const CIZGI_RENK = ["#E8E2D4", "#7D9B6A", "#C4B07A", "#C45C4A", "#9C9488"];

    /* Hafta hafta biriken kupon puanı — sezon grafiği için */
    const sezonSerisi = useMemo(() => {
        const h = (tablo && tablo.haftalar) || [];
        if (h.length < 2) return null;
        const oyuncular = ((kurulum && kurulum.oyuncular) || []);
        const seriler = oyuncular.map((o, k) => {
            let birikim = 0;
            const nokta = h.map(x => { birikim += (x.puanlar && x.puanlar[o.slug]) || 0; return birikim; });
            return { slug: o.slug, isim: o.isim, renk: CIZGI_RENK[k % CIZGI_RENK.length], nokta, son: birikim };
        });
        const enYuksek = Math.max(1, ...seriler.map(s => s.son));
        return { seriler, haftalar: h.map(x => x.no), enYuksek };
    }, [tablo, kurulum]);

    /* Portföydeki her takımın fiyatına göre performansı.
       fiyat = beklenenPuan - FIYAT_TABAN olduğu için beklenti geri türetilebilir. */
    function portfoyKarne(slug) {
        const pf = portfoy[slug];
        if (!pf || !pf.takimlar) return null;
        const gecen = ((tablo && tablo.haftalar) || []).length;
        return pf.takimlar.map(i => {
            const t = T(i);
            const f = fiyat(t);
            const sezonBeklenti = f + FIYAT_TABAN;
            const lt = (tablo && tablo.ligTablo && tablo.ligTablo[i]) || null;
            const oynanan = (lt && lt.o) || gecen;
            const oran = Math.min(1, oynanan / 34);
            const simdiBeklenen = sezonBeklenti * oran;
            const gercek = takimPuan(i);
            const tekSahip = sahipSayisi(i) === 1;
            return {
                idx: i, ad: t.ad, kod: t.kod, fiyat: f,
                sezonBeklenti, simdiBeklenen, gercek, oynanan,
                fark: gercek - simdiBeklenen,
                katki: takimKatki(i), tekSahip,
            };
        }).sort((a, b) => b.fark - a.fark);
    }

    /* Bir haftada bir maçın tam skorunu yalnız bir kişi bildiyse onu döndürür */
    function tekBilen(h, i) {
        const dogru = [];
        Object.entries(h.tahminler || {}).forEach(([sl, th]) => {
            const t = th && th[i], sn = h.sonuclar[i];
            if (t && sn && t[0] === sn[0] && t[1] === sn[1]) dogru.push(sl);
        });
        if (dogru.length !== 1) return null;
        const say = Object.keys(h.tahminler || {}).length;
        if (say < 2) return null;
        return (h.isimler && h.isimler[dogru[0]]) || dogru[0];
    }

    /* ---------- haftalık ödül ----------
       Yalnızca kupon puanına göre; portföy hesaba katılmaz.
       Beraberlikte eşit olanların kapladığı sıraların ödülleri toplanıp
       aralarında eşit bölüşülür; haftalık dağıtılan toplam sabit kalır. */
    const ODULLER = [500, 250, 150, 75, 1];
    const haftaOdul = (h) => {
        const e = Object.entries((h && h.puanlar) || {});
        if (!e.length) return [];
        const ad = (sl) => (h.isimler && h.isimler[sl]) || sl;
        const sirali = e.slice().sort((a, b) => b[1] - a[1]);
        const cikti = [];
        let i = 0;
        while (i < sirali.length) {
            let k = i;
            while (k + 1 < sirali.length && sirali[k + 1][1] === sirali[i][1]) k++;
            let havuz = 0;
            for (let d = i; d <= k; d++) havuz += (ODULLER[d] || 0);
            const pay = havuz / (k - i + 1);
            for (let d = i; d <= k; d++) {
                cikti.push({
                    slug: sirali[d][0], isim: ad(sirali[d][0]), puan: sirali[d][1],
                    sira: i + 1, odul: pay, esit: k > i,
                });
            }
            i = k + 1;
        }
        const puanlar = cikti.map(x => x.puan);
        const enAz = Math.min(...puanlar), enCok = Math.max(...puanlar);
        cikti.forEach(x => {
            x.unvan = (x.puan === enCok) ? "alim"
                : (cikti.length >= 2 && enCok !== enAz && x.puan === enAz) ? "dallama" : "";
        });
        /* Banko bonusu: haftanın 1.si olup bankosunun tam skorunu da tutturana ödül ikiye katlanır.
           detay dizisi banko çarpanını zaten içerir (tam skor 5 × banko 2 = 10). */
        cikti.forEach(x => {
            if (x.sira !== 1) return;
            const jk = h.jokerler && h.jokerler[x.slug];
            const dt = h.detay && h.detay[x.slug];
            if (jk !== undefined && jk !== null && dt && dt[jk] === 10) {
                x.odul *= 2;
                x.bankoBonus = true;
            }
        });
        /* Bidon d'Or'a ek onur: o hafta tek puan bile alamayan sonuncuya büyük boy patlıcan. */
        cikti.forEach(x => {
            if (x.unvan === "dallama" && x.puan === 0) x.patlican = true;
        });
        return cikti;
    };
    function rezaletListesi(h) {
        const out = [];
        ((h && h.maclar) || []).forEach((m, i) => {
            const sn = h.sonuclar && h.sonuclar[i];
            if (!sn || sn[0] == null || sn[1] == null) return;
            Object.entries(h.tahminler || {}).forEach(([sl, th]) => {
                const t = th && th[i];
                if (!t || t[0] == null || t[1] == null) return;
                const uzak = Math.abs(+t[0] - +sn[0]) + Math.abs(+t[1] - +sn[1]);
                const p = (h.detay && h.detay[sl] && h.detay[sl][i]) || 0;
                const banko = (h.jokerler && h.jokerler[sl]) === i;
                if (p === 0 && (uzak >= 5 || (banko && uzak >= 4))) {
                    out.push({
                        slug: sl, isim: (h.isimler && h.isimler[sl]) || sl,
                        i, t, sn, uzak, banko,
                        ev: T(m.e).kod, dep: T(m.d).kod,
                    });
                }
            });
        });
        return out.sort((a, b) => b.uzak - a.uzak || b.banko - a.banko);
    }
    function mansetUret(h) {
        if (!h) return null;
        const od = haftaOdul(h);
        const alim = od.filter(x => x.unvan === "alim");
        const bidon = od.filter(x => x.unvan === "dallama");
        const rez = rezaletListesi(h);
        const A = alim[0] ? alim[0].isim : "";
        const B = bidon[0] ? bidon[0].isim : "";
        const R = rez[0] ? rez[0].isim : "";
        const liste = [];
        if (A) {
            liste.push(A + " Show");
            liste.push("Patron " + A);
            if (alim[0].bankoBonus) liste.push("Baba Vanga " + A);
            liste.push(A + " kasayı süpürdü");
            liste.push(A + " bu hafta konuşuyor");
        }
        if (B) {
            liste.push(B + " Sıçtı");
            liste.push("Gariban " + B);
            liste.push("Bidon " + B);
            liste.push(B + " yine sonuncu");
            if (bidon[0].patlican) liste.push("Sıfır puan: " + B);
        }
        if (A && B) liste.push(A + " Show, " + B + " Sıçtı");
        if (R) {
            liste.push(R + " ne yazdı öyle");
            liste.push("Kâhin değil: " + R);
            if (rez[0].banko) liste.push(R + " bankoyu gömdü");
        }
        if (!liste.length) liste.push(h.no + ". hafta bitti. Kimse yere serilmedi.");
        const dipler = [];
        if (alim.length) dipler.push("Alîm ulema: " + alim.map(x => x.isim).join(", ") + ".");
        if (bidon.length) dipler.push("Bidon d'Or: " + bidon.map(x => x.isim).join(", ") + ".");
        if (rez[0]) dipler.push(rez[0].isim + " " + rez[0].ev + "–" + rez[0].dep + " için " + rez[0].t[0] + "–" + rez[0].t[1] + " yazdı, " + rez[0].sn[0] + "–" + rez[0].sn[1] + " geldi.");
        if (!dipler.length) dipler.push("Sayfa mürekkep kokuyor, skandal yok.");
        let tohum = 0;
        const anahtar = [h.no, A, B, R, rez[0] ? rez[0].uzak : 0].join("|");
        for (let i = 0; i < anahtar.length; i++) tohum = (tohum * 31 + anahtar.charCodeAt(i)) >>> 0;
        return {
            no: h.no,
            baslik: liste[tohum % liste.length],
            dip: dipler.join(" "),
            alim: alim.map(x => x.isim),
            bidon: bidon.map(x => x.isim),
            rez,
        };
    }
    async function anketOyVer(hedef) {
        if (!ben) throw new Error("Giriş yok.");
        if (!aktif) throw new Error("Açık hafta yok.");
        if (!hedef) throw new Error("Bir isim seç.");
        const hf = String(aktif.hafta);
        let sonHata = null;
        for (let deneme = 0; deneme < 3; deneme++) {
            const kayit = await depo.get(`kpn:${lig}:anket`);
            const onceki = (kayit && okuJSON(kayit.value, {})) || {};
            const haftaOylari = Object.assign({}, onceki[hf] || {});
            if (haftaOylari[ben.slug]) throw new Error("Bu hafta oyunu verdin.");
            haftaOylari[ben.slug] = hedef;
            const yeni = Object.assign({}, onceki, { [hf]: haftaOylari });
            try {
                await depo.kosulluSet(`kpn:${lig}:anket`, JSON.stringify(yeni), kayit ? kayit.value : null);
                setAnket(yeni);
                setBilgi("Oyun kaydoldu. Kim kime basmış, aşağıda.");
                return;
            } catch (e) {
                sonHata = e;
                if (deneme === 2 || !String(e && e.message).includes("başka bir cihaz")) throw e;
            }
        }
        throw sonHata;
    }
    const paraYaz = (n) => (Math.round(n * 100) / 100).toString().replace(".", ",") + " \u20AC";
    /* Sezonun para ekonomisi: haftalık toplam ve şu ana kadar dağıtılan */
    const HAFTALIK_KASA = ODULLER.reduce((a, b) => a + b, 0);
    const SEZON_KASA = HAFTALIK_KASA * 34;
    const dagitilan = useMemo(() => {
        return ((tablo && tablo.haftalar) || []).reduce((t, h) =>
            t + haftaOdul(h).reduce((s, x) => s + x.odul, 0), 0);
    }, [tablo]);

    const kasa = useMemo(() => {
        const k = {};
        ((tablo && tablo.haftalar) || []).forEach(h => {
            haftaOdul(h).forEach(x => { k[x.slug] = (k[x.slug] || 0) + x.odul; });
        });
        return k;
    }, [tablo]);
    const magazaUrun = (id) => MAGAZA_URUNLER.find(u => u.id === id);
    const kalanStok = (id, mag = magaza) => {
        const u = magazaUrun(id);
        if (!u) return 0;
        return Math.max(0, u.stok - (mag.alimlar || []).filter(a => a.urun === id).length);
    };
    const nakitHesap = (slug, mag = magaza, ay = ayakta) => {
        const gelir = kasa[slug] || 0;
        const harcama = (mag.alimlar || []).filter(a => a.slug === slug).reduce((s, a) => s + (+a.fiyat || 0), 0);
        const verilen = (mag.zekat || []).filter(z => z.veren === slug).reduce((s, z) => s + (+z.miktar || 0), 0);
        const alinan = (mag.zekat || []).filter(z => z.alan === slug).reduce((s, z) => s + (+z.miktar || 0), 0);
        const torba = (mag.erzak || []).filter(z => z.veren === slug).reduce((s, z) => s + (+z.miktar || 0), 0);
        const ayGiris = ((ay && ay.girisler) || []).filter(g => g.slug === slug).reduce((s, g) => s + (+g.miktar || 0), 0);
        const ayOdul = ((ay && ay.gecmis) || []).filter(g => g.kazanan === slug).reduce((s, g) => s + (+g.kasa || 0), 0);
        const ceza = (mag.cezalar || []).filter(c => c.slug === slug).reduce((s, c) => s + (+c.miktar || 0), 0);
        return Math.round((gelir - harcama - verilen - torba + alinan - ayGiris + ayOdul - ceza) * 100) / 100;
    };
    const servetHesap = (slug, mag = magaza) => {
        const mal = (mag.alimlar || []).filter(a => a.slug === slug).reduce((s, a) => s + (+a.fiyat || 0), 0);
        return Math.round((nakitHesap(slug, mag) + mal) * 100) / 100;
    };
    const sahipMallar = (slug, mag = magaza) =>
        (mag.alimlar || []).filter(a => a.slug === slug).map(a => magazaUrun(a.urun)).filter(Boolean);
    async function magazaKaydet(mutator, mesaj) {
        let sonHata = null;
        for (let deneme = 0; deneme < 3; deneme++) {
            const kayit = await depo.get(`kpn:${lig}:magaza`);
            const onceki = (kayit && okuJSON(kayit.value, MAGAZA_BOS)) || MAGAZA_BOS;
            const taslak = {
                alimlar: [...(onceki.alimlar || [])],
                zekat: [...(onceki.zekat || [])],
                erzak: [...(onceki.erzak || [])],
                cezalar: (onceki.cezalar || []).map(function (c) { return Object.assign({}, c); }),
            };
            const yeni = mutator(taslak);
            if (JSON.stringify(yeni) === JSON.stringify({
                alimlar: onceki.alimlar || [],
                zekat: onceki.zekat || [],
                erzak: onceki.erzak || [],
                cezalar: onceki.cezalar || [],
            })) {
                setMagaza({
                    alimlar: onceki.alimlar || [],
                    zekat: onceki.zekat || [],
                    erzak: onceki.erzak || [],
                    cezalar: onceki.cezalar || [],
                });
                return onceki;
            }
            try {
                await depo.kosulluSet(`kpn:${lig}:magaza`, JSON.stringify(yeni), kayit ? kayit.value : null);
                setMagaza(yeni);
                if (mesaj) setBilgi(mesaj);
                return yeni;
            } catch (e) {
                sonHata = e;
                if (deneme === 2 || !String(e && e.message).includes("başka bir cihaz")) throw e;
            }
        }
        throw sonHata;
    }
    function kerizOdenenIdler(ay) {
        const s = {};
        ((ay || ayakta).gecmis || []).forEach(function (g) {
            (g.kerizIds || []).forEach(function (id) { s[id] = true; });
        });
        return s;
    }
    function kerizBekleyenListe(mag, ay) {
        const odendi = kerizOdenenIdler(ay);
        return ((mag || magaza).cezalar || []).filter(function (c) {
            return c && c.id && !c.odendi && !odendi[c.id];
        });
    }
    function kerizBekleyen(mag, ay) {
        return kerizBekleyenListe(mag, ay).reduce(function (s, c) { return s + (+c.miktar || 0); }, 0);
    }
    function kerizToplam(mag, ay) {
        const a = ay || ayakta;
        return Math.round((kerizBekleyen(mag, a) + (+(a && a.kasa) || 0)) * 100) / 100;
    }
    async function kerizKes() {
        if (MISAFIR) return "";
        if (!aktif || !lig || !kurulum) return "";
        if (!ilkMacBasladi) return "";
        const oy = (kurulum.oyuncular || []);
        if (!oy.length) return "";
        const [kuponList, ayKayit] = await Promise.all([
            depo.list("kpn:" + lig + ":kupon:" + aktif.hafta + ":"),
            depo.get("kpn:" + lig + ":ayakta"),
        ]);
        const keys = (kuponList && kuponList.keys) || [];
        const rows = keys.length ? await depo.getMany(keys) : [];
        const veren = {};
        rows.forEach(function (v) {
            const p = okuJSON(v && v.value, null);
            if (p && p.slug) veren[p.slug] = true;
        });
        const ay = ayaktaNorm(ayKayit && okuJSON(ayKayit.value, AYAKTA_BOS));
        const hf = String(aktif.hafta);
        const picks = (ay.secimler && ay.secimler[hf]) || {};
        const eklenen = [];
        await magazaKaydet(function (m) {
            if (!Array.isArray(m.cezalar)) m.cezalar = [];
            function varMi(slug, tur) {
                return m.cezalar.some(function (c) { return c.slug === slug && +c.hafta === +aktif.hafta && c.tur === tur; });
            }
            oy.forEach(function (o) {
                if (!veren[o.slug] && !varMi(o.slug, "kupon")) {
                    m.cezalar.push({ id: "kz-kupon-" + aktif.hafta + "-" + o.slug, slug: o.slug, hafta: aktif.hafta, tur: "kupon", miktar: CEZA_KUPON, zaman: Date.now() });
                    eklenen.push({ isim: o.isim, tur: "kupon", miktar: CEZA_KUPON });
                }
                if (picks[o.slug] == null && !varMi(o.slug, "rulet")) {
                    m.cezalar.push({ id: "kz-rulet-" + aktif.hafta + "-" + o.slug, slug: o.slug, hafta: aktif.hafta, tur: "rulet", miktar: CEZA_RULET, zaman: Date.now() });
                    eklenen.push({ isim: o.isim, tur: "rulet", miktar: CEZA_RULET });
                }
            });
            return m;
        });
        if (eklenen.length) {
            const txt = eklenen.map(function (x) { return x.isim + " · " + (x.tur === "kupon" ? "kupon yok" : "rulet yok") + " · " + paraYaz(x.miktar); }).join(" · ");
            await gunlukYaz(audit("Keriz Parası", aktif.hafta + ". hf · ilk maç · " + txt));
            setBilgi("Keriz Parası · " + txt);
            return txt;
        }
        return "";
    }
    const kerizRef = useRef(0);
    useEffect(function () {
        if (MISAFIR) return;
        if (ekran !== "oyun" || !aktif || !ilkMacBasladi) return;
        if (Date.now() - kerizRef.current < 15000) return;
        kerizRef.current = Date.now();
        kerizKes().catch(function () {});
    }, [aktif && aktif.hafta, ilkMacBasladi, ekran]);
    function kerizKutusu() {
        const bekleyen = kerizBekleyenListe(magaza, ayakta);
        const girisler = ((ayakta && ayakta.girisler) || []).filter(function (g) { return +g.tur === +(ayakta.tur || 1); });
        const toplam = kerizToplam(magaza, ayakta);
        const ad = function (sl) {
            const o = ((kurulum && kurulum.oyuncular) || []).find(function (x) { return x.slug === sl; });
            return (o && o.isim) || sl;
        };
        const satirlar = bekleyen.slice().sort(function (a, b) { return b.zaman - a.zaman; }).map(function (c) {
            return H("div", { key: c.id, className: "pr-row" },
                H("span", null, ad(c.slug) + " · " + c.hafta + ". hf · " + (c.tur === "kupon" ? "kupon yok" : "rulet yok")),
                H("strong", null, paraYaz(c.miktar)));
        }).concat(girisler.map(function (g, i) {
            return H("div", { key: "g-" + g.slug + "-" + i, className: "pr-row" },
                H("span", null, ad(g.slug) + " · rulet girişi"),
                H("strong", null, paraYaz(g.miktar)));
        }));
        return H("div", { className: "kp-kat kz-kasa" },
            H("div", { className: "kp-et" }, "Kasa: Keriz Parası"),
            H("strong", { className: "kz-tutar" }, paraYaz(toplam)),
            H("p", { className: "pr-muted" }, "Rulet girişi (" + paraYaz(AYAKTA_UCRET) + ") ile kuponu/" + "ruleti olmayanların cezası (" + paraYaz(CEZA_KUPON) + " / " + paraYaz(CEZA_RULET) + ") burada birikir. Ruleti kazanan alır. Herkes elenirse sonraki tura kalır."),
            satirlar.length ? satirlar.slice(0, 12) : H("p", { className: "pr-muted", style: { marginBottom: 0 } }, "Henüz birikim yok."));
    }
    function kerizSerit() {
        return H("div", { className: "kp-kat kz-kasa", style: { padding: "10px 14px" } },
            H("div", { className: "pr-row", style: { padding: 0, border: "none" } },
                H("span", { style: { fontWeight: 700 } }, "Kasa: Keriz Parası"),
                H("strong", { className: "kz-tutar", style: { fontSize: 20, margin: 0 } }, paraYaz(kerizToplam(magaza, ayakta)))));
    }
    async function satinAl(id) {
        if (!ben) throw new Error("Giriş yok.");
        const u = magazaUrun(id);
        if (!u) throw new Error("Ürün bulunamadı.");
        await magazaKaydet((m) => {
            if (kalanStok(id, m) <= 0) throw new Error(u.ad + " tükendi.");
            const n = nakitHesap(ben.slug, m);
            if (n < u.fiyat) throw new Error("Bakiyen yetmiyor. " + paraYaz(n) + " var.");
            m.alimlar.push({
                id: Date.now() + "-" + Math.random().toString(36).slice(2),
                slug: ben.slug, urun: id, fiyat: u.fiyat, zaman: Date.now(),
            });
            return m;
        }, u.ad + " senin. Kasadan " + paraYaz(u.fiyat) + " düştü — servetin duruyor.");
        setSatinOnay(null);
        await gunlukYaz(audit("Mağaza", ben.isim + " " + u.ad + " aldı · " + paraYaz(u.fiyat)));
    }
    async function zekatGonder() {
        if (!ben) throw new Error("Giriş yok.");
        const weeks = (tablo && tablo.haftalar) || [];
        if (!weeks.length) throw new Error("İlk hafta kapanınca zekât açılır.");
        const h = weeks[weeks.length - 1];
        if (!h) throw new Error("Hafta bulunamadı.");
        const sonuncular = haftaOdul(h).filter(x => x.unvan === "dallama");
        if (!sonuncular.length) throw new Error("Bu haftada sonuncu yok.");
        if (sonuncular.some(x => x.slug === ben.slug))
            throw new Error("Bu hafta sonuncusun — zekât veremezsin, alırsın.");
        const miktar = parseFloat(String(zekatMiktar).replace(",", "."));
        if (!Number.isFinite(miktar) || miktar < 0.01)
            throw new Error("Miktar en az 0,01 € olmalı.");
        const yuvar = Math.round(miktar * 100) / 100;
        await magazaKaydet((m) => {
            if ((m.zekat || []).some(z => z.veren === ben.slug && +z.hafta === +h.no))
                throw new Error(h.no + ". hafta için zekâtını zaten verdin.");
            const n = nakitHesap(ben.slug, m);
            if (n < yuvar) throw new Error("Bakiyen yetmiyor. " + paraYaz(n) + " var.");
            const pay = Math.round((yuvar / sonuncular.length) * 100) / 100;
            sonuncular.forEach((x, i) => {
                const p = i === 0 ? Math.round((yuvar - pay * (sonuncular.length - 1)) * 100) / 100 : pay;
                m.zekat.push({
                    id: Date.now() + "-" + i + "-" + Math.random().toString(36).slice(2),
                    veren: ben.slug, alan: x.slug, miktar: p, hafta: h.no, zaman: Date.now(),
                });
            });
            return m;
        }, h.no + ". haftanın sonuncusuna " + paraYaz(yuvar) + " zekât gitti.");
        setZekatMiktar("");
        setZekatOnay(false);
        const adlar = sonuncular.map(x => x.isim).join(", ");
        await gunlukYaz(audit("Zekât", ben.isim + " → " + adlar + " · " + paraYaz(yuvar) + " · " + h.no + ". hafta"));
    }
    function erzakHedefKisi(mag = magaza) {
        const weeks = (tablo && tablo.haftalar) || [];
        const oy = (kurulum && kurulum.oyuncular) || [];
        if (!weeks.length || !oy.length) return null;
        const hNo = weeks[weeks.length - 1].no;
        const kilit = {
            alimlar: mag.alimlar || [],
            zekat: mag.zekat || [],
            erzak: (mag.erzak || []).filter(z => +z.hafta !== +hNo),
        };
        return oy.slice().sort((a, b) =>
            (servetHesap(a.slug, kilit) - servetHesap(b.slug, kilit))
            || (nakitHesap(a.slug, kilit) - nakitHesap(b.slug, kilit))
            || a.slug.localeCompare(b.slug))[0];
    }
    async function erzakGonder() {
        if (!ben) throw new Error("Giriş yok.");
        const weeks = (tablo && tablo.haftalar) || [];
        if (!weeks.length) throw new Error("İlk hafta kapanınca erzak açılır.");
        const h = weeks[weeks.length - 1];
        await magazaKaydet((m) => {
            const hedef = erzakHedefKisi(m);
            if (!hedef) throw new Error("Erzak için hedef yok.");
            if (hedef.slug === ben.slug) throw new Error("Para sıralamasında en sondasın — erzak alırsın, gönderemezsin.");
            if ((m.erzak || []).some(z => z.veren === ben.slug && +z.hafta === +h.no))
                throw new Error(h.no + ". hafta için torbanı zaten gönderdin.");
            const n = nakitHesap(ben.slug, m);
            if (n < ERZAK_FIYAT) throw new Error("Bakiyen yetmiyor. " + paraYaz(n) + " var.");
            m.erzak.push({
                id: Date.now() + "-" + Math.random().toString(36).slice(2),
                veren: ben.slug, alan: hedef.slug, miktar: ERZAK_FIYAT, hafta: h.no, zaman: Date.now(),
            });
            return m;
        }, erzakHedefKisi().isim + " evine 50 €'luk erzak gitti. Nakit yazılmaz.");
        setErzakOnay(false);
        const hedef = erzakHedefKisi();
        await gunlukYaz(audit("Erzak", ben.isim + " → " + (hedef ? hedef.isim : "?") + " · " + h.no + ". hf · " + paraYaz(ERZAK_FIYAT)));
    }
    async function ayaktaKaydet(mutator, mesaj) {
        let sonHata = null;
        for (let deneme = 0; deneme < 3; deneme++) {
            const kayit = await depo.get("kpn:" + lig + ":ayakta");
            const onceki = ayaktaNorm(kayit && okuJSON(kayit.value, AYAKTA_BOS));
            const taslak = JSON.parse(JSON.stringify(onceki));
            const yeni = mutator(taslak);
            if (JSON.stringify(yeni) === JSON.stringify(onceki)) {
                setAyakta(onceki);
                return onceki;
            }
            try {
                await depo.kosulluSet("kpn:" + lig + ":ayakta", JSON.stringify(yeni), kayit ? kayit.value : null);
                setAyakta(yeni);
                if (mesaj) setBilgi(mesaj);
                return yeni;
            } catch (e) {
                sonHata = e;
                if (deneme === 2 || String(e && e.message).indexOf("başka bir cihaz") < 0) throw e;
            }
        }
        throw sonHata;
    }
    function ayaktaGirisAcik() {
        if (!aktif || ruletKapali) return false;
        if (ayakta.turBitisHafta != null && +ayakta.turBitisHafta === +aktif.hafta) return false;
        if (ayakta.baslangicHafta == null) return true;
        return +ayakta.baslangicHafta === +aktif.hafta;
    }
    async function ayaktaGir() {
        if (!ben) throw new Error("Giriş yok.");
        if (!aktif || ruletKapali) throw new Error("İlk maç başladı. Rulet bu hafta kapandı.");
        if (!ayaktaGirisAcik()) throw new Error("Bu tur başladı. Sonraki turda girersin.");
        const y = await ayaktaKaydet(function (a) {
            if (a.girenler.indexOf(ben.slug) >= 0) throw new Error("Bu turdasın.");
            const n = nakitHesap(ben.slug, magaza, a);
            if (n < AYAKTA_UCRET) throw new Error("Giriş " + paraYaz(AYAKTA_UCRET) + ". Bakiyen " + paraYaz(n) + ".");
            a.girenler.push(ben.slug);
            a.canli.push(ben.slug);
            a.girisler.push({ slug: ben.slug, tur: a.tur, miktar: AYAKTA_UCRET, zaman: Date.now() });
            a.kasa = Math.round((a.kasa + AYAKTA_UCRET) * 100) / 100;
            if (a.baslangicHafta == null) a.baslangicHafta = +aktif.hafta;
            return a;
        }, "Tura girdin. " + paraYaz(AYAKTA_UCRET) + " Keriz Parası kasasına yazıldı. Bu hafta bir takım seç.");
        setAyGirisOnay(false);
        await gunlukYaz(audit("Rulet", ben.isim + " tur " + y.tur + " · giriş " + paraYaz(AYAKTA_UCRET)));
    }
    async function ayaktaKilitle() {
        if (!ben) throw new Error("Giriş yok.");
        if (!aktif || ruletKapali) throw new Error("İlk maç başladı. El kilitlenemez.");
        if (aySec == null) throw new Error("Takım seç.");
        const idx = +aySec;
        await ayaktaKaydet(function (a) {
            if (a.canli.indexOf(ben.slug) < 0) throw new Error("Bu turda hayatta değilsin.");
            const hf = String(aktif.hafta);
            if (!a.secimler[hf]) a.secimler[hf] = {};
            if (a.secimler[hf][ben.slug] != null) throw new Error("Bu hafta seçimin kilitli.");
            const kullan = a.kullanilan[ben.slug] || [];
            if (kullan.indexOf(idx) >= 0) throw new Error("Bu takımı bu turda kullandın.");
            const oynar = (aktif.maclar || []).some(function (m) { return +m.e === idx || +m.d === idx; });
            if (!oynar) throw new Error("Bu takım bu hafta oynamıyor.");
            a.secimler[hf][ben.slug] = idx;
            a.kullanilan[ben.slug] = kullan.concat([idx]);
            return a;
        }, T(idx).ad + " kilitlendi. Elin gizli — maçın bitince masaya düşer.");
        setAySec(null);
        setAySecOnay(false);
        await gunlukYaz(audit("Rulet kilit", ben.isim + " · kör · " + aktif.hafta + ". hf"));
    }
    async function ayaktaSonucIsle(h, opts) {
        if (MISAFIR) return "";
        const teslim = !!(opts && opts.teslimKapali);
        const zorla = !!(opts && opts.zorla);
        if (!h || h.no == null) return "";
        let ilanlar = [];
        let bitis = "";
        const magKayit = await depo.get("kpn:" + lig + ":magaza");
        const magSnap = (magKayit && okuJSON(magKayit.value, MAGAZA_BOS)) || MAGAZA_BOS;
        const y = await ayaktaKaydet(function (a) {
            const r = ayaktaUygulaSonuclar(a, h, teslim, zorla);
            ilanlar = r.ilanlar;
            bitis = r.bitisMesaj;
            if (bitis === "kazandi" && a.gecmis && a.gecmis.length) {
                const g = a.gecmis[a.gecmis.length - 1];
                if (g && g.kazanan && !g.devir && !g.kerizEklendi) {
                    const bekleyen = kerizBekleyenListe(magSnap, a);
                    const ids = bekleyen.map(function (c) { return c.id; }).filter(Boolean);
                    const extra = bekleyen.reduce(function (s, c) { return s + (+c.miktar || 0); }, 0);
                    g.kasa = Math.round((+g.kasa + extra) * 100) / 100;
                    g.kerizIds = ids;
                    g.kerizEklendi = true;
                }
            }
            return r.a;
        });
        if (bitis === "kazandi") {
            const g = y && y.gecmis && y.gecmis[y.gecmis.length - 1];
            const ids = (g && g.kerizIds) || [];
            if (ids.length) {
                const set = {};
                ids.forEach(function (id) { set[id] = true; });
                await magazaKaydet(function (m) {
                    m.cezalar = (m.cezalar || []).map(function (c) {
                        if (set[c.id] && !c.odendi) {
                            c.odendi = true;
                            c.odemeZaman = Date.now();
                        }
                        return c;
                    });
                    return m;
                });
            }
        }
        if (ilanlar.length || bitis) {
            const parca = ilanlar.map(function (x) {
                const ad = oyuncuAd(x.slug);
                const takimAd = x.takim != null ? T(x.takim).ad : "";
                if (x.neden === "G") return ad + " kaldı · " + ruletNedenYaz(x.neden, takimAd);
                return ad + " elendi · " + ruletNedenYaz(x.neden, takimAd);
            });
            if (bitis === "kazandi" && y && y.gecmis && y.gecmis.length) {
                const g = y.gecmis[y.gecmis.length - 1];
                parca.push(oyuncuAd(g.kazanan) + " ruleti kazandı · Keriz Parası " + paraYaz(g.kasa));
            } else if (bitis === "devir") {
                parca.push("Herkes elendi. Keriz Parası sonraki tura devretti.");
            }
            const txt = parca.join(" · ");
            await gunlukYaz(audit("Rulet", h.no + ". hf · " + txt));
            setBilgi(txt);
            return txt;
        }
        return "";
    }
    async function ayaktaHaftaBitir(h) {
        return ayaktaSonucIsle(h, { teslimKapali: true, zorla: true });
    }
    const aktifOranlar = useMemo(() => {
        if (!aktif || !aktif.maclar) return [];
        if (aktif.oranlar && aktif.oranlar.length === aktif.maclar.length) return aktif.oranlar;
        return macOranlari(aktif.maclar, takimlar, (tablo && tablo.haftalar) || []);
    }, [aktif, tablo, takimlar]);
    function transferFiyat(idx) {
        const weeks = ((tablo && tablo.haftalar) || []).length || 1;
        const p = takimPuan(idx);
        return Math.max(1, Math.round(p * (34 / weeks) - FIYAT_TABAN));
    }
    const transferAcik = !!(transfer && !transfer.uygulandi && Date.now() < transfer.kapanis);
    async function transferPencereAc() {
        if ((tablo && tablo.haftalar || []).length < TRANSFER_SONRA) throw new Error("Pencere " + TRANSFER_SONRA + ". hafta kapanınca açılır.");
        if (transfer && transfer.acilis) throw new Error("Pencere zaten açıldı.");
        const kayit = await depo.get(`kpn:${lig}:transfer`);
        if (kayit && okuJSON(kayit.value, null)) throw new Error("Pencere başka cihazda açılmış. Yenile.");
        const y = { acilis: Date.now(), kapanis: Date.now() + TRANSFER_GUN_MS, kilitler: {}, uygulandi: false };
        await depo.kosulluSet(`kpn:${lig}:transfer`, JSON.stringify(y), kayit ? kayit.value : null);
        setTransfer(y);
        setBilgi("Transfer penceresi 3 gün açık. Seçimler kör.");
        await gunlukYaz(audit("Transfer", "Pencere açıldı · 3 gün"));
    }
    async function transferKilitle(pas) {
        if (!ben) throw new Error("Giriş yok.");
        if (!transferAcik) throw new Error("Pencere kapalı.");
        const p = portfoy[ben.slug];
        if (!p) throw new Error("Portföyün yok.");
        if (p.transfer) throw new Error("Bu sezon hakkını kullandın.");
        if ((transfer.kilitler || {})[ben.slug]) throw new Error("Transferin kilitli.");
        let kayitIcerik = { pas: true };
        if (!pas) {
            if (trSat == null || trAl == null) throw new Error("Satılacak ve alınacak takımı seç.");
            if (+trSat === +trAl) throw new Error("Aynı takım.");
            if (!(p.takimlar || []).map(Number).includes(+trSat)) throw new Error("Satacağın takım sende yok.");
            if ((p.takimlar || []).map(Number).includes(+trAl)) throw new Error("O takım zaten sende.");
            if ((p.yasak || []).map(Number).includes(+trAl)) throw new Error("Sattığın takımı geri alamazsın.");
            const satF = transferFiyat(+trSat), alF = transferFiyat(+trAl);
            const kalan = KREDI - (p.harcanan || 0) + satF - alF - TRANSFER_KOMISYON;
            if (kalan < 0) throw new Error("Kredi yetmiyor. Komisyon " + TRANSFER_KOMISYON + "k. Kalan " + kalan + "k.");
            kayitIcerik = { sat: +trSat, al: +trAl, satF, alF, pas: false };
        }
        const kayit = await depo.get(`kpn:${lig}:transfer`);
        const cur = (kayit && okuJSON(kayit.value, null)) || transfer;
        if ((cur.kilitler || {})[ben.slug]) throw new Error("Transferin kilitli.");
        const y = { ...cur, kilitler: { ...(cur.kilitler || {}), [ben.slug]: { ...kayitIcerik, zaman: Date.now() } } };
        await depo.kosulluSet(`kpn:${lig}:transfer`, JSON.stringify(y), kayit ? kayit.value : null);
        setTransfer(y);
        setTrOnay(false);
        setBilgi(pas ? "Bu sezon transfer yok, kilitlendi." : "Transfer kilitlendi. Pencere kapanınca açılır.");
        await gunlukYaz(audit("Transfer kilit", ben.isim + (pas ? " · pas" : " · kör")));
        await transferUygula(false).catch(() => {});
    }
    async function transferUygula(zorla) {
        const trKayit = await depo.get(`kpn:${lig}:transfer`);
        const cur = (trKayit && okuJSON(trKayit.value, null)) || transfer;
        if (!cur || cur.uygulandi) { setTransfer(cur); return; }
        const bitti = Date.now() >= cur.kapanis;
        const kilitSay = Object.keys(cur.kilitler || {}).length;
        const pfSay = Object.keys(portfoy || {}).length;
        if (!zorla && !bitti && !(pfSay > 0 && kilitSay >= pfSay)) return;
        const pfKayit = await depo.get(`kpn:${lig}:portfoy`);
        const pf = (pfKayit && okuJSON(pfKayit.value, {})) || {};
        const yPf = { ...pf };
        Object.entries(cur.kilitler || {}).forEach(([sl, k]) => {
            if (!yPf[sl] || k.pas || yPf[sl].transfer) return;
            const tk = (yPf[sl].takimlar || []).map(Number);
            const i = tk.indexOf(+k.sat);
            if (i < 0) return;
            tk[i] = +k.al;
            yPf[sl] = {
                ...yPf[sl],
                takimlar: tk,
                harcanan: (yPf[sl].harcanan || 0) - (k.satF || 0) + (k.alF || 0) + TRANSFER_KOMISYON,
                transfer: { sat: +k.sat, al: +k.al },
                yasak: [ ...((yPf[sl].yasak) || []), +k.sat ],
            };
        });
        const yTr = { ...cur, uygulandi: true, acilisBitis: Date.now() };
        await depo.kosulluSet(`kpn:${lig}:portfoy`, JSON.stringify(yPf), pfKayit ? pfKayit.value : null);
        await depo.kosulluSet(`kpn:${lig}:transfer`, JSON.stringify(yTr), trKayit ? trKayit.value : JSON.stringify(cur));
        setPortfoy(yPf);
        setTransfer(yTr);
        setBilgi("Transferler açıldı.");
        await gunlukYaz(audit("Transfer açıldı", Object.keys(cur.kilitler || {}).length + " kilit uygulandı."));
    }
    useEffect(() => {
        if (!lig || !ben || !tablo) return;
        if ((tablo.haftalar || []).length < TRANSFER_SONRA) return;
        if (transfer && !transfer.uygulandi) transferUygula(false).catch(() => {});
        if (!transfer) transferPencereAc().catch(() => {});
    }, [lig, ben, tablo && tablo.haftalar && tablo.haftalar.length, transfer && transfer.uygulandi]);
    const transferSuresiBitti = !!(transfer && !transfer.uygulandi && simdi >= transfer.kapanis);
    useEffect(() => {
        if (transferSuresiBitti) transferUygula(false).catch(() => {});
    }, [transferSuresiBitti]);
    function koleksiyon(slug) {
        const weeks = (tablo && tablo.haftalar) || [];
        const oy = ((kurulum && kurulum.oyuncular) || []);
        const roz = [];
        let kartOk = 0, kara = 0, streak = 0, maxStreak = 0;
        weeks.forEach(h => {
            const dt = (h.detay && h.detay[slug]) || [];
            const tam = dt.filter(tamSkorPuani).length;
            if (tam >= 4) roz.push({ id: "kahin" });
            const kp = kartPuan((h.kartlar || {})[slug], h.sonuclar, h.oranlar);
            if (kp > 0) kartOk++;
            const jk = h.jokerler && h.jokerler[slug];
            if (jk != null && dt[jk] === 10) { streak++; maxStreak = Math.max(maxStreak, streak); }
            else streak = 0;
            (h.maclar || []).forEach((m, i) => {
                if (T(m.e).kod !== "BJK" && T(m.d).kod !== "BJK") return;
                if (tamSkorPuani(dt[i] || 0)) kara++;
            });
        });
        if (kartOk >= 8) roz.push({ id: "surpriz" });
        if (maxStreak >= 5) roz.push({ id: "banko" });
        if (kara >= 10) roz.push({ id: "kartal" });
        /* Küllerinden: ilk 10 hafta sonuncu, sonra ilk 2 */
        if (weeks.length >= 10 && oy.length > 1) {
            const birik = {};
            oy.forEach(o => { birik[o.slug] = 0; });
            weeks.slice(0, 10).forEach(h => {
                oy.forEach(o => { birik[o.slug] += (h.puanlar && h.puanlar[o.slug]) || 0; });
            });
            const sira10 = KAnaliz.rank(birik);
            const me10 = sira10.find(x => x.slug === slug);
            const sonSira = Math.max(...sira10.map(x => x.sira));
            if (me10 && me10.sira === sonSira) {
                weeks.slice(10).forEach(h => {
                    oy.forEach(o => { birik[o.slug] += (h.puanlar && h.puanlar[o.slug]) || 0; });
                    const me = KAnaliz.rank(birik).find(x => x.slug === slug);
                    if (me && me.sira <= 2) roz.push({ id: "kuller" });
                });
            }
        }
        /* Portföy Baron’u: 10. haftadan sonra 20+ farkla tek lider */
        if (weeks.length >= 10 && oy.length > 1) {
            const pfs = oy.map(o => ({ slug: o.slug, p: portfoyPuan(o.slug) })).sort((a, b) => b.p - a.p);
            if (pfs[0].slug === slug && (pfs[0].p - pfs[1].p) >= 20) roz.push({ id: "baron" });
        }
        /* Derbi kasabı: derbi maçının tam skoru */
        weeks.forEach(h => {
            const dt = (h.detay && h.detay[slug]) || [];
            (h.maclar || []).forEach((m, i) => {
                if (!BUYUK4.includes(T(m.e).kod) || !BUYUK4.includes(T(m.d).kod)) return;
                if (tamSkorPuani(dt[i] || 0)) roz.push({ id: "derbi" });
            });
        });
        const uniq = [];
        roz.forEach(r => {
            if (uniq.some(x => x.id === r.id)) return;
            uniq.push({ id: r.id, ad: rozetAd(r.id) });
        });
        return { rozet: uniq, kartOk, kara, maxStreak };
    }
    /* ---------- stil ---------- */
    const stil = `
.kp{
  --bg:#F3E8D6;--kat:#FFF8EC;--kat2:#EDE0CC;--cizgi:#DCCBB4;--fg:#2C241C;--sol:#7A6E60;
  --aksan:#9C4B3A;--aksan-fg:#FFF8EC;--banko:#A67C2D;--kirmizi:#C45C4A;--yesil:#4F7A48;
  --kagit:#FFF6E8;--murekkep:#2C241C;--kagit-sol:#7A6E60;
  --r-xs:4px;--r-sm:8px;--r-md:12px;--r-lg:20px;
  --ease:cubic-bezier(.22,1,.36,1);
  background:var(--bg);
  background-image:radial-gradient(90% 48% at 50% -8%,#FFF6E6 0%,transparent 70%);
  color:var(--fg);
  font-family:Figtree,system-ui,sans-serif;
  height:100%;min-height:100%;max-height:100%;
  height:100dvh;max-height:100dvh;
  width:100%;max-width:100%;min-width:0;
  display:flex;flex-direction:column;
  overflow:hidden;
  -webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;
}
html,body,#kok{height:100%;height:100dvh;max-height:100%;max-height:100dvh;overflow:hidden;overscroll-behavior:none;margin:0;background:#F3E8D6;}
.kp *{box-sizing:border-box;}
.kp h1,.kp h2,.kp h3{text-wrap:balance;}
.kp p{text-wrap:pretty;}
.kp-mono{font-family:'IBM Plex Mono',ui-monospace,monospace;font-variant-numeric:tabular-nums;}
.kp-h{font-family:Fraunces,Georgia,serif;font-weight:560;font-optical-sizing:auto;letter-spacing:-.03em;line-height:1.08;}
.kp-mark{font-family:Fraunces,Georgia,serif;font-style:italic;font-weight:560;font-optical-sizing:auto;letter-spacing:-.04em;line-height:.9;font-size:clamp(3.4rem,12vw,4.75rem);color:var(--fg);margin:0;}
.kp-masthead{padding:8px 0 6px;border-bottom:1px solid var(--cizgi);margin-bottom:22px;}
.kp-mast-meta{font-family:'IBM Plex Mono',monospace;font-size:10px;letter-spacing:.16em;text-transform:uppercase;color:var(--sol);margin-bottom:14px;}
.kp-mast-sub{font-size:14px;color:var(--sol);margin:10px 0 0;letter-spacing:.02em;}
.kp-ust{z-index:30;background:color-mix(in oklab,var(--bg) 94%,transparent);border-bottom:1px solid var(--cizgi);padding:14px 16px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-shrink:0;}
.kp-misafir{display:inline-flex;align-items:center;justify-content:center;min-width:50px;height:50px;border-radius:50%;border:1px solid var(--cizgi);font-size:9px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--sol);}
.kp-ic{padding:16px 16px 24px;max-width:620px;margin:0 auto;width:100%;min-width:0;flex:1 1 auto;min-height:0;overflow-x:hidden;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;}
.kp-masa-col{flex:1 1 auto;min-width:0;min-height:0;display:flex;flex-direction:column;overflow:hidden;width:100%;}
.kp-masa{display:flex;flex-direction:column;gap:0;}
.kp-kat{background:var(--kat);border:1px solid var(--cizgi);border-radius:var(--r-lg);padding:16px;margin-bottom:12px;}
.kp-et{font-family:'IBM Plex Mono',monospace;font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--banko);font-weight:700;margin-bottom:10px;}

.kp-kagit{position:relative;background:var(--kagit);color:var(--murekkep);border-radius:var(--r-sm);padding:26px 16px 18px;margin-bottom:12px;box-shadow:0 12px 32px rgba(80,50,20,.12);font-family:'IBM Plex Mono',monospace;border-top:3px solid var(--kirmizi);}
.kp-kagit:before,.kp-kagit:after{display:none;}
.kp-kbas{display:flex;justify-content:space-between;font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:var(--kagit-sol);border-bottom:1px solid color-mix(in oklab,var(--murekkep) 18%,transparent);padding-bottom:10px;margin-bottom:6px;}
.kp-msatir{display:grid;grid-template-columns:28px 1fr auto 1fr 30px;gap:6px;align-items:center;padding:10px 0;border-bottom:1px solid color-mix(in oklab,var(--murekkep) 10%,transparent);font-size:13px;}
.kp-msatir:last-child{border-bottom:none;}
.kp-ev{text-align:right;font-weight:600;}
.kp-dep{text-align:left;font-weight:600;}
.kp-sayac{display:flex;align-items:center;gap:3px;}
.kp-sbtn{width:32px;height:44px;border:1px solid color-mix(in oklab,var(--murekkep) 22%,transparent);background:transparent;color:var(--murekkep);border-radius:var(--r-xs);font-size:16px;line-height:1;cursor:pointer;font-family:'IBM Plex Mono',monospace;transition:background .15s var(--ease);}
.kp-sbtn:active{background:color-mix(in oklab,var(--murekkep) 8%,transparent);transform:scale(.98);}
.kp-skor{font-size:18px;font-weight:700;min-width:20px;text-align:center;font-variant-numeric:tabular-nums;}
.kp-joker{width:32px;height:44px;border-radius:var(--r-xs);border:1.5px solid color-mix(in oklab,var(--murekkep) 22%,transparent);background:transparent;color:var(--kagit-sol);font-size:12px;font-weight:700;cursor:pointer;font-family:'IBM Plex Mono',monospace;transition:background .15s var(--ease),color .15s var(--ease),border-color .15s var(--ease);}
.kp-joker.on{background:var(--kirmizi);border-color:var(--kirmizi);color:#F3EEE4;}
.kp-muhur{position:absolute;right:12px;top:42px;transform:rotate(-12deg);border:2px solid var(--kirmizi);color:var(--kirmizi);font-family:Fraunces,Georgia,serif;font-style:italic;font-weight:700;font-size:13px;letter-spacing:.04em;padding:7px 12px;border-radius:2px;opacity:.9;background:color-mix(in oklab,var(--kagit) 70%,transparent);}
.kp-gazete{position:relative;background:#FBF4E6;background-image:repeating-linear-gradient(0deg,transparent,transparent 26px,rgba(44,36,28,.045) 27px),linear-gradient(180deg,#FFFDF6 0%,#F6EBDA 100%);color:#1A1610;border:1px solid #2C241C;padding:0;margin:10px 0 14px;box-shadow:5px 6px 0 #2C241C;}
.kp-gazete-name{font-family:Fraunces,Georgia,serif;font-weight:700;font-size:clamp(1.8rem,8vw,2.4rem);letter-spacing:.18em;text-transform:uppercase;text-align:center;padding:14px 16px 2px;line-height:1;}
.kp-gazete-ust{display:flex;justify-content:space-between;align-items:baseline;gap:8px;font-family:'IBM Plex Mono',monospace;font-size:9px;letter-spacing:.14em;text-transform:uppercase;border-top:1px solid #2C241C;border-bottom:3px double #2C241C;padding:6px 14px;color:#6F675C;}
.kp-gazete-bas{font-family:Fraunces,Georgia,serif;font-style:italic;font-weight:700;font-size:clamp(1.45rem,6.4vw,2.05rem);line-height:1.12;letter-spacing:-.035em;margin:0;padding:16px 16px 12px;text-align:center;color:#7D2F24;}
.kp-gazete-govde{display:grid;grid-template-columns:1fr;gap:10px;padding:0 16px 16px;border-top:1px solid rgba(44,36,28,.18);}
.kp-gazete-dip{font-size:13.5px;line-height:1.55;color:#3A322A;margin:10px 0 0;font-family:Fraunces,Georgia,serif;font-style:italic;}
.kp-gazete-rz{display:flex;align-items:center;gap:10px;border:1px dashed #7D2F24;padding:7px 10px;margin-top:8px;width:fit-content;max-width:100%;}
.kp-gazete-rz-yazi{font-size:12.5px;line-height:1.4;color:#3A322A;}
.kp-gazete-kapa{position:absolute;top:4px;right:4px;background:none;border:none;color:#6F675C;font-size:18px;min-width:36px;min-height:36px;cursor:pointer;}
.kp-rz-muhur{display:inline-block;flex-shrink:0;transform:rotate(-6deg);border:2px solid #7D2F24;color:#7D2F24;font-family:Fraunces,Georgia,serif;font-style:italic;font-weight:700;font-size:11px;letter-spacing:.02em;line-height:1;padding:5px 8px;white-space:nowrap;}
.kp-rz-cip{border-color:#7D2F24!important;color:#7D2F24!important;background:color-mix(in oklab,#7D2F24 10%,transparent)!important;}
.ol-oran{font-family:'IBM Plex Mono',monospace;font-size:9px;letter-spacing:.04em;color:var(--kagit-sol);text-align:center;padding-top:2px;}
.ol-kart{display:grid;grid-template-columns:1fr;gap:8px;margin-top:12px;}
.ol-sec{border:1px solid var(--cizgi);background:var(--kat);border-radius:var(--r-sm);padding:10px 12px;text-align:left;cursor:pointer;width:100%;min-height:44px;}
.ol-sec.on{border-color:var(--aksan);background:color-mix(in oklab,var(--aksan) 10%,var(--kat));}
.ol-sec b{display:block;font-size:13px;}
.ol-sec span{display:block;font-size:11.5px;color:var(--sol);margin-top:3px;line-height:1.4;}
.rz-cip{display:inline-flex;align-items:center;font-family:'IBM Plex Mono',monospace;font-size:8.5px;font-weight:700;letter-spacing:.06em;padding:2px 6px;border-radius:99px;border:1px solid var(--cizgi);color:var(--fg);margin-left:4px;vertical-align:middle;}
.cr-sat{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--cizgi);font-size:13.5px;}
.rz-soz{padding:12px 0;border-bottom:1px solid var(--cizgi);}
.rz-soz:last-child{border-bottom:none;}
.rz-soz-ust{display:flex;align-items:center;justify-content:space-between;gap:10px;}
.rz-soz-kim{display:flex;align-items:center;gap:4px;flex-shrink:0;}
.rz-soz-kim em{font-size:11.5px;color:var(--sol);font-style:italic;font-family:Figtree,sans-serif;font-weight:400;letter-spacing:0;}
.rz-soz-acik{margin:6px 0 0;font-size:12.5px;line-height:1.45;color:var(--sol);}
.rz-soz .rz-cip{margin-left:0;}
.tr-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:8px;}
.ay-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;margin-top:10px;}
.ay-tak{border:1px solid var(--cizgi);background:var(--kat);border-radius:12px;padding:12px 8px;text-align:center;min-height:64px;cursor:pointer;width:100%;min-width:0;}
.ay-tak.on{border-color:#7D2F24;background:color-mix(in oklab,#7D2F24 12%,var(--kat));color:#7D2F24;}
.ay-tak.pas{opacity:.34;cursor:default;}
.ay-tak b{display:block;font-family:'IBM Plex Mono',monospace;font-size:15px;font-weight:700;letter-spacing:.04em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.ay-tak span{display:block;font-size:10px;color:var(--sol);margin-top:3px;line-height:1.25;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.ay-tak.on span{color:#7D2F24;}
.ay-kisi{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--cizgi);}
.ay-kisi:last-child{border-bottom:none;}
.ay-kilit{position:sticky;bottom:0;z-index:6;background:linear-gradient(180deg,transparent 0%,var(--bg) 18%,var(--bg) 100%);padding:16px 0 4px;margin-top:8px;}
.rl-hero{padding:16px 16px 14px;margin-bottom:12px;background:#FAF1E0;border:1px solid #2C241C;box-shadow:3px 3px 0 #2C241C;}
.rl-ust{display:flex;align-items:center;gap:14px;}
.rl-cark{width:84px;height:84px;flex-shrink:0;color:#7D2F24;display:block;overflow:visible;transform-origin:50% 50%;}
.rl-cark.don{animation:rl-don 32s linear infinite;}
@keyframes rl-don{to{transform:rotate(360deg);}}
.rl-bas{min-width:0;flex:1;}
.rl-hero h1{font-family:Fraunces,Georgia,serif;font-style:italic;font-weight:700;font-size:clamp(2.15rem,11vw,2.85rem);letter-spacing:-.045em;line-height:.9;margin:0;color:#7D2F24;}
.rl-hero p{margin:8px 0 0;font-size:13.5px;line-height:1.5;color:var(--sol);}
.rl-meta{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px;}
.rl-meta div{background:var(--kat);border:1px solid var(--cizgi);border-radius:var(--r-md);padding:12px 14px;min-width:0;}
.rl-meta b{display:block;font-family:'IBM Plex Mono',monospace;font-size:10px;letter-spacing:.14em;color:var(--banko);}
.rl-meta strong{display:block;font-family:'IBM Plex Mono',monospace;font-size:22px;font-weight:700;margin-top:4px;letter-spacing:-.03em;font-variant-numeric:tabular-nums;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.rl-meta em{display:block;font-style:normal;font-size:11.5px;color:var(--sol);margin-top:4px;}
.rl-yuzler{display:flex;align-items:center;flex-wrap:wrap;gap:6px;margin-top:12px;}
.rl-yuzler span{font-size:12px;color:var(--sol);}

.kp-dg{background:var(--aksan);color:var(--aksan-fg);border:none;border-radius:var(--r-md);padding:15px;font-family:Figtree,sans-serif;font-size:15px;font-weight:600;cursor:pointer;width:100%;letter-spacing:.01em;transition:transform .15s var(--ease),filter .15s var(--ease);min-height:48px;}
.kp-dg:hover{filter:brightness(1.04);}
.kp-dg:active{transform:scale(.98);}
.kp-dg:disabled{background:var(--cizgi);color:var(--sol);cursor:default;transform:none;filter:none;}
.kp-dg2{background:transparent;color:var(--fg);border:1px solid var(--cizgi);border-radius:var(--r-md);padding:12px 14px;font-family:Figtree,sans-serif;font-size:13px;font-weight:600;cursor:pointer;transition:border-color .15s var(--ease),background .15s var(--ease);min-height:44px;}
.kp-dg2:hover{border-color:color-mix(in oklab,var(--fg) 28%,transparent);background:color-mix(in oklab,var(--fg) 4%,transparent);}
.kp-cip{background:var(--kat2);border:1px solid var(--cizgi);color:var(--sol);border-radius:var(--r-sm);padding:11px 4px;font-size:12px;font-weight:600;cursor:pointer;font-family:'IBM Plex Mono',monospace;text-align:center;transition:background .15s var(--ease),color .15s var(--ease),border-color .15s var(--ease);min-height:44px;}
.kp-cip.on{background:var(--aksan);border-color:var(--aksan);color:var(--aksan-fg);}
.kp-cip.pas{opacity:.28;cursor:default;}
.kp-gir{background:var(--kat2);border:1px solid var(--cizgi);color:var(--fg);padding:13px;border-radius:var(--r-sm);width:100%;font-size:16px;font-family:Figtree,sans-serif;transition:border-color .15s var(--ease),box-shadow .15s var(--ease);}
.kp-gir:focus{outline:none;border-color:color-mix(in oklab,var(--aksan) 55%,var(--cizgi));box-shadow:0 0 0 3px color-mix(in oklab,var(--aksan) 18%,transparent);}
.kp-unvan{display:inline-flex;align-items:center;font-family:'IBM Plex Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.09em;padding:3px 8px;border-radius:99px;white-space:nowrap;}
.kp-unvan.iyi{background:color-mix(in oklab,var(--yesil) 16%,transparent);color:var(--yesil);border:1px solid color-mix(in oklab,var(--yesil) 32%,transparent);}
.kp-unvan.kotu{background:color-mix(in oklab,var(--kirmizi) 14%,transparent);color:var(--kirmizi);border:1px solid color-mix(in oklab,var(--kirmizi) 28%,transparent);}
.kp-patlican{width:22px;height:22px;border-radius:6px;object-fit:cover;vertical-align:middle;}
.kp-banko2x{display:inline-flex;align-items:center;font-family:'IBM Plex Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.09em;padding:3px 8px;border-radius:99px;white-space:nowrap;background:color-mix(in oklab,var(--banko) 16%,transparent);color:var(--banko);border:1px solid color-mix(in oklab,var(--banko) 32%,transparent);}
.kp-para{font-family:'IBM Plex Mono',monospace;font-size:14px;font-weight:700;color:var(--fg);white-space:nowrap;letter-spacing:-.01em;font-variant-numeric:tabular-nums;}
.kp-para.iyi{color:var(--yesil);}
.kp-para.kotu{color:var(--kirmizi);}
.kp-sira{display:flex;align-items:center;gap:9px;padding:7px 0;}

.gr-kut{background:var(--kat);border:1px solid var(--cizgi);border-radius:var(--r-lg);padding:14px 12px 10px;margin-bottom:12px;}
.gr-bas{font-family:'IBM Plex Mono',monospace;font-size:10px;letter-spacing:.12em;color:var(--sol);margin-bottom:10px;padding:0 2px;}
.gr-svg{display:block;width:100%;height:auto;overflow:visible;}
.gr-ef{display:flex;flex-wrap:wrap;gap:9px;margin-top:11px;padding:0 2px;}
.gr-ef span{display:inline-flex;align-items:center;gap:5px;font-size:11.5px;color:var(--fg);}
.gr-ef i{width:9px;height:3px;border-radius:2px;display:inline-block;}
.gr-ef b{font-family:'IBM Plex Mono',monospace;font-size:11px;color:var(--sol);font-weight:400;}

.kn-sat{display:grid;grid-template-columns:42px minmax(0,1fr) auto;gap:10px;align-items:start;padding:11px 0;border-bottom:1px solid var(--cizgi);}
.kn-sat:last-of-type{border-bottom:none;}
.kn-kod{font-family:'IBM Plex Mono',monospace;font-size:12.5px;font-weight:700;color:var(--sol);padding-top:2px;}
.kn-orta{min-width:0;}
.kn-ad{display:flex;flex-wrap:wrap;align-items:center;gap:6px;font-size:14px;color:var(--fg);line-height:1.3;}
.kn-alt{display:block;font-family:'IBM Plex Mono',monospace;font-size:10.5px;color:var(--sol);margin-top:4px;line-height:1.35;}
.kn-sag{text-align:right;white-space:nowrap;}
.kn-fark{font-family:'IBM Plex Mono',monospace;font-size:15px;font-weight:700;font-variant-numeric:tabular-nums;}
.kn-fark.iyi{color:var(--yesil);} .kn-fark.kotu{color:var(--kirmizi);} .kn-fark.orta{color:var(--sol);}
.kn-puan{font-family:'IBM Plex Mono',monospace;font-size:10.5px;color:var(--sol);margin-top:2px;}
.kn-tek{font-family:'IBM Plex Mono',monospace;font-size:8.5px;font-weight:700;color:var(--banko);border:1px solid color-mix(in oklab,var(--banko) 45%,transparent);border-radius:4px;padding:1px 4px;letter-spacing:.05em;white-space:nowrap;}

.tk-roz{display:inline-flex;align-items:center;gap:4px;font-family:'IBM Plex Mono',monospace;font-size:9px;font-weight:700;color:var(--banko);background:color-mix(in oklab,var(--banko) 14%,transparent);border:1px solid color-mix(in oklab,var(--banko) 34%,transparent);border-radius:99px;padding:2px 7px;margin-left:7px;letter-spacing:.05em;}

.pf-ust{position:sticky;top:0;z-index:30;background:color-mix(in oklab,var(--bg) 94%,transparent);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border-bottom:1px solid var(--cizgi);padding:12px 16px 13px;}
.pf-slotlar{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-bottom:11px;}
.pf-slot{height:56px;border-radius:var(--r-md);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;border:1px dashed var(--cizgi);background:var(--kat2);transition:border-color .16s var(--ease),background .16s var(--ease);}
.pf-slot.dolu{border-style:solid;border-color:var(--aksan);background:color-mix(in oklab,var(--aksan) 12%,transparent);cursor:pointer;}
.pf-slot-kod{font-family:'IBM Plex Mono',monospace;font-size:12.5px;font-weight:700;color:var(--aksan);}
.pf-slot-f{font-family:'IBM Plex Mono',monospace;font-size:10px;color:var(--sol);}
.pf-slot-bos{font-size:19px;color:var(--cizgi);line-height:1;}
.pf-butce{display:flex;align-items:center;gap:10px;}
.pf-cubuk{flex:1;height:6px;border-radius:99px;background:var(--kat2);overflow:hidden;}
.pf-cubuk i{display:block;height:100%;border-radius:99px;background:var(--aksan);transition:width .22s var(--ease),background .22s var(--ease);}
.pf-cubuk.dar i{background:var(--banko);}
.pf-cubuk.tas i{background:var(--kirmizi);}
.pf-kalan{font-family:'IBM Plex Mono',monospace;font-size:17px;font-weight:700;color:var(--aksan);white-space:nowrap;font-variant-numeric:tabular-nums;}
.pf-kalan.dar{color:var(--banko);} .pf-kalan.tas{color:var(--kirmizi);}
.pf-kalan span{font-size:9.5px;color:var(--sol);font-weight:600;margin-left:4px;letter-spacing:.06em;}
.pf-kusak{display:flex;align-items:baseline;gap:9px;margin:20px 0 9px;}
.pf-kusak b{font-family:Figtree,sans-serif;font-size:12px;font-weight:700;color:var(--fg);letter-spacing:.06em;text-transform:uppercase;}
.pf-kusak i{flex:1;height:1px;background:var(--cizgi);font-style:normal;}
.pf-kusak em{font-family:'IBM Plex Mono',monospace;font-size:10px;color:var(--sol);font-style:normal;}
.pf-satir{display:grid;grid-template-columns:46px minmax(0,1fr) auto;gap:11px;align-items:center;padding:12px 13px;margin-bottom:7px;border-radius:var(--r-md);background:var(--kat);border:1px solid var(--cizgi);transition:border-color .12s var(--ease),background .12s var(--ease);-webkit-tap-highlight-color:transparent;}
.pf-satir.secili{background:color-mix(in oklab,var(--aksan) 10%,var(--kat));border-color:var(--aksan);}
.pf-satir.kapali{opacity:.4;}
.pf-satir:not(.kapali){cursor:pointer;}
.pf-kod{font-family:'IBM Plex Mono',monospace;font-weight:700;font-size:13px;color:var(--sol);}
.pf-satir.secili .pf-kod{color:var(--fg);}
.pf-ad{font-size:14.5px;font-weight:500;color:var(--fg);}
.pf-alt{font-family:'IBM Plex Mono',monospace;font-size:10.5px;color:var(--sol);margin-top:3px;}
.pf-sebep{font-family:'IBM Plex Mono',monospace;font-size:10px;color:var(--kirmizi);margin-top:3px;}
.pf-fiyat{font-family:'IBM Plex Mono',monospace;font-weight:700;text-align:right;font-variant-numeric:tabular-nums;}
.pf-fiyat.t1{font-size:19px;color:var(--fg);}
.pf-fiyat.t2{font-size:17px;color:color-mix(in oklab,var(--fg) 82%,var(--sol));}
.pf-fiyat.t3{font-size:15px;color:var(--sol);}
.pf-fiyat.t4{font-size:14px;color:color-mix(in oklab,var(--sol) 80%,var(--cizgi));}
.pf-b4{font-family:'IBM Plex Mono',monospace;font-size:9px;font-weight:700;color:var(--banko);border:1px solid color-mix(in oklab,var(--banko) 50%,transparent);border-radius:4px;padding:2px 5px;margin-left:7px;vertical-align:middle;letter-spacing:.06em;}

.kp-kaydet{margin:0 0 18px;padding:16px 16px 14px;border:1px solid var(--cizgi);border-radius:var(--r-md);background:var(--kat);}
.kp-kaydet b{display:block;font-family:Fraunces,Georgia,serif;font-size:20px;font-weight:560;letter-spacing:-.02em;margin:0 0 6px;}
.kp-kaydet p{font-size:13px;color:var(--sol);line-height:1.5;margin:0 0 12px;}
.kp-kaydet .sira{display:flex;flex-direction:column;gap:8px;}
.kp-kaydet a.kp-dg,.kp-kaydet a.kp-dg2{display:block;text-align:center;text-decoration:none;box-sizing:border-box;}
.kp-giris-gorsel{position:relative;margin:8px 0 22px;border-radius:var(--r-sm);overflow:hidden;border:1px solid var(--cizgi);background:var(--kat);}
.kp-giris-gorsel img{display:block;width:100%;height:auto;filter:grayscale(.08) contrast(1.06) saturate(.92);}
.kp-giris-gorsel:after{content:"";position:absolute;left:0;right:0;bottom:0;height:42%;background:linear-gradient(to bottom,transparent,var(--bg));pointer-events:none;}

.kp-haftabas{padding:12px 8px;margin:0 -8px;border-radius:var(--r-sm);cursor:pointer;-webkit-tap-highlight-color:transparent;transition:background .14s var(--ease);}
.kp-haftabas:active{background:color-mix(in oklab,var(--fg) 5%,transparent);}
.kp-ac{width:30px;height:30px;flex-shrink:0;border-radius:50%;display:flex;align-items:center;justify-content:center;background:color-mix(in oklab,var(--aksan) 10%,transparent);border:1px solid var(--cizgi);color:var(--fg);font-size:15px;line-height:1;transition:transform .18s var(--ease),background .18s var(--ease);transform:rotate(-90deg);}
.kp-ac.acik{transform:rotate(0deg);background:color-mix(in oklab,var(--aksan) 18%,transparent);}

.kp-odul{position:relative;border-radius:var(--r-lg);overflow:hidden;margin-bottom:14px;border:1px solid var(--cizgi);min-height:190px;display:flex;align-items:flex-end;background:var(--kat);}
.kp-odul-bg{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:center 62%;filter:grayscale(.15) contrast(1.08) saturate(.9);}
.kp-odul:after{content:"";position:absolute;inset:0;background:linear-gradient(to top,rgba(44,36,28,.92) 0%,rgba(44,36,28,.78) 32%,rgba(44,36,28,.28) 62%,rgba(44,36,28,.08) 100%);}
.kp-odul-ic{position:relative;z-index:2;padding:16px;width:100%;}
.kp-odul-bas{font-family:'IBM Plex Mono',monospace;font-size:9.5px;letter-spacing:.16em;color:#E2C07A;font-weight:700;margin-bottom:4px;}
.kp-odul-mal{font-family:Fraunces,Georgia,serif;font-style:italic;font-size:24px;font-weight:560;color:#F6F0E6;letter-spacing:-.02em;line-height:1.1;}
.kp-odul-hedef{font-size:13px;font-weight:600;color:#D2C4B2;letter-spacing:0;}
.kp-odul-yildiz{font-family:Fraunces,Georgia,serif;font-style:italic;font-size:16px;font-weight:560;color:#E2C07A;}
.kp-odul-dip{font-size:10px;color:#D2C4B2;margin-top:3px;}
.kp-odul-ad{font-family:Fraunces,Georgia,serif;font-size:16px;font-weight:560;color:#F6F0E6;}
.kp-odul-alt{font-size:11.5px;color:#D2C4B2;margin-top:5px;line-height:1.5;}
.kp-odul-cizgi{height:1px;background:color-mix(in oklab,var(--banko) 24%,transparent);margin:11px 0 10px;}

.kp-govde{flex:1 0 auto;min-height:0;}
.kp-alt{position:relative;margin-top:0;background:var(--bg);border-top:1px solid var(--cizgi);display:flex;flex-wrap:nowrap;align-items:stretch;gap:0;padding:4px 4px calc(8px + env(safe-area-inset-bottom));z-index:40;flex-shrink:0;width:100%;min-width:0;max-width:100%;overflow-x:auto;overflow-y:hidden;-webkit-overflow-scrolling:touch;overscroll-behavior-x:contain;touch-action:pan-x;scrollbar-width:none;-ms-overflow-style:none;}
.kp-alt::-webkit-scrollbar{display:none;height:0;}
.kp-alt button{background:none;border:none;color:var(--sol);padding:12px 10px;min-height:48px;min-width:3.5rem;flex:1 0 auto;border-radius:0;font-family:Figtree,sans-serif;font-size:10px;font-weight:600;letter-spacing:.04em;text-transform:uppercase;white-space:nowrap;cursor:pointer;transition:color .14s var(--ease);box-shadow:inset 0 0 0 0 transparent;}
.kp-alt button:active{transform:scale(.97);}
.kp-alt button.on{color:var(--fg);background:transparent;box-shadow:inset 0 2px 0 var(--aksan);}

.kz-kasa{border-color:color-mix(in oklab,var(--banko) 45%,var(--cizgi))!important;}
.kz-tutar{display:block;font-family:'IBM Plex Mono',monospace;font-size:28px;font-weight:700;letter-spacing:-.04em;color:var(--banko);margin:4px 0 8px;font-variant-numeric:tabular-nums;}
.mg-bakiye{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px;}
.mg-bak{background:var(--kat);border:1px solid var(--cizgi);border-radius:var(--r-md);padding:14px 14px 12px;}
.mg-bak b{display:block;font-family:'IBM Plex Mono',monospace;font-size:11px;letter-spacing:.14em;color:var(--banko);font-weight:700;margin-bottom:6px;}
.mg-bak strong{display:block;font-family:'IBM Plex Mono',monospace;font-size:22px;font-weight:700;color:var(--fg);letter-spacing:-.03em;font-variant-numeric:tabular-nums;}
.mg-bak em{display:block;font-style:normal;font-size:11.5px;color:var(--sol);margin-top:6px;line-height:1.4;}
.mg-urun{display:grid;grid-template-columns:56px 1fr;gap:12px;align-items:center;padding:14px 4px;border-bottom:1px solid var(--cizgi);}
.mg-urun:last-of-type{border-bottom:none;}
.mg-gorsel{width:56px;height:56px;border-radius:var(--r-sm);border:1px solid var(--cizgi);background:var(--kat2);display:flex;align-items:center;justify-content:center;position:relative;}
.mg-lej{position:relative;border-radius:var(--r-lg);overflow:hidden;margin-bottom:14px;border:1px solid var(--cizgi);background:var(--kat);display:flex;flex-direction:column;}
.mg-lej-bg{display:block;width:100%;height:auto;aspect-ratio:2/3;object-fit:cover;object-position:center 12%;filter:none;}
.mg-lej:after{display:none;}
.mg-lej-ic{position:relative;z-index:2;padding:16px;width:100%;color:var(--fg);background:var(--kat);}
.mg-lej-ic .mg-ad{color:var(--fg);}
.mg-lej-ic .mg-alt{color:var(--sol);}
.mg-lej-ic .mg-fiyat{color:var(--banko);font-size:22px;margin-top:6px;}
.mg-lej-ic .mg-stok{color:var(--sol);}
.mg-lej-ic .mg-stok.yok{color:var(--kirmizi);}
.mg-lej-ic .kp-dg2{border-color:var(--cizgi);color:var(--fg);background:transparent;}
.mg-lej-ic .mg-onay{background:var(--kat);border-color:color-mix(in oklab,var(--banko) 40%,var(--cizgi));}
@media(min-width:900px){
.mg-lej{flex-direction:row;align-items:stretch;min-height:520px;}
.mg-lej-bg{width:min(44%,440px);flex:0 0 min(44%,440px);height:auto;min-height:520px;aspect-ratio:auto;object-fit:cover;object-position:center top;}
.mg-lej-ic{flex:1;display:flex;flex-direction:column;justify-content:flex-end;padding:28px 32px 24px;}
}
.mg-tel{width:22px;height:38px;border:2px solid var(--aksan);border-radius:5px;position:relative;}
.mg-tel:after{content:"";position:absolute;bottom:3px;left:50%;width:8px;height:2px;background:var(--aksan);transform:translateX(-50%);border-radius:1px;}
.mg-kon7{width:46px;height:28px;color:var(--banko);display:block;}
.mg-pc{width:34px;height:26px;border:2px solid var(--fg);border-radius:3px;position:relative;}
.mg-pc:before{content:"";position:absolute;left:-8px;bottom:0;width:6px;height:20px;border:2px solid var(--fg);border-radius:2px;}
.mg-pc:after{content:"";position:absolute;bottom:-5px;left:6px;width:18px;height:3px;background:var(--fg);border-radius:1px;}
.mg-ad{font-size:15px;font-weight:600;color:var(--fg);letter-spacing:-.01em;}
.mg-alt{font-size:12px;color:var(--sol);margin-top:3px;line-height:1.45;}
.mg-fiyat{font-family:'IBM Plex Mono',monospace;font-size:16px;font-weight:700;color:var(--banko);margin-top:8px;font-variant-numeric:tabular-nums;}
.mg-stok{font-family:'IBM Plex Mono',monospace;font-size:11px;letter-spacing:.1em;color:var(--sol);margin-top:4px;}
.mg-stok.yok{color:var(--kirmizi);}
.mg-yetmez,.mg-yetmez:disabled{opacity:1!important;color:var(--kirmizi)!important;border-color:var(--kirmizi)!important;background:color-mix(in oklab,var(--kirmizi) 12%,transparent)!important;font-weight:700;}
.mg-tukendi,.mg-tukendi:disabled{opacity:1!important;color:var(--sol)!important;border-color:var(--cizgi)!important;}
.mg-le{font-family:'IBM Plex Mono',monospace;font-size:13px;font-weight:700;letter-spacing:.12em;color:var(--banko);}
.mg-rozet{display:inline-block;font-family:'IBM Plex Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.08em;color:var(--banko);border:1px solid color-mix(in oklab,var(--banko) 50%,transparent);border-radius:4px;padding:1px 5px;margin-left:6px;vertical-align:middle;}
.mg-onay{border-color:var(--banko)!important;}
.kp :focus-visible{outline:2px solid var(--aksan);outline-offset:2px;}

.kp-bilgi{background:var(--kat);border-bottom:1px solid var(--cizgi);padding:10px 16px;font-size:13px;display:flex;justify-content:space-between;gap:10px;color:var(--fg);flex-shrink:0;}
.kp-bilgi button{background:none;border:none;color:var(--sol);cursor:pointer;font-size:17px;line-height:1;min-width:44px;min-height:44px;}

.pr-root{padding-top:4px;}
.pr-hero{padding:12px 12px 8px;margin-bottom:4px;background:#FAF1E0;border:1px solid #2C241C;box-shadow:3px 3px 0 #2C241C;}
.pr-hero h1{font-size:clamp(1.45rem,5vw,1.9rem);margin:0;font-family:Fraunces,Georgia,serif;font-style:italic;font-weight:700;letter-spacing:-.03em;line-height:1.08;color:#2C241C;}
.pr-hero .kp-gazete{margin:12px 0 4px;box-shadow:none;}
.pr-catisma{display:flex;align-items:center;gap:12px;margin:0;color:var(--fg);padding-bottom:8px;border-bottom:3px double #2C241C;}
.pr-catisma-svg{width:86px;height:48px;flex-shrink:0;color:#7D2F24;}
.pr-muted{font-size:13.5px;line-height:1.65;color:var(--sol);margin:8px 0;overflow-wrap:anywhere;}
.pr-tabs{display:flex;flex-wrap:nowrap;gap:0;overflow-x:auto;overflow-y:hidden;padding:4px 12px 0 0;border-bottom:1px solid var(--cizgi);margin:12px 0;width:100%;min-width:0;max-width:100%;-webkit-overflow-scrolling:touch;overscroll-behavior-x:contain;touch-action:pan-x;scrollbar-width:none;-ms-overflow-style:none;scroll-snap-type:x proximity;}
.pr-tabs::-webkit-scrollbar{display:none;height:0;}
.pr-tabs button{white-space:nowrap;flex:0 0 auto;scroll-snap-align:start;min-height:44px;background:transparent;color:var(--sol);border:none;border-bottom:2px solid transparent;border-radius:0;padding:9px 12px;font:600 12.5px Figtree,system-ui;cursor:pointer;margin-bottom:-1px;}
.pr-tabs button.on{background:transparent;border-bottom-color:#7D2F24;color:var(--fg);}
.pr-label{display:block;font-size:13px;margin:8px 0 16px;color:var(--sol);}
.pr-label select,.pr-label input{display:block;margin-top:8px;}
.pr-winner{background:#FAF1E0;border:1px solid #2C241C;border-left:4px solid #7D2F24;border-radius:0;padding:22px 18px;margin-bottom:14px;}
.pr-winner h2{font-size:26px;line-height:1.2;margin:6px 0;overflow-wrap:anywhere;font-family:Fraunces,Georgia,serif;font-style:italic;font-weight:700;}
.pr-versus{display:grid;grid-template-columns:1fr auto 1fr;gap:12px;align-items:center;text-align:center;padding:30px 10px;background:#FAF1E0;border:1px solid #2C241C;border-radius:0;box-shadow:3px 3px 0 #2C241C;}
.pr-big{font-size:36px;color:var(--fg);font-family:'IBM Plex Mono',monospace;font-variant-numeric:tabular-nums;}
.pr-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0;}
.pr-metric{padding:17px 14px;background:var(--kat);border:1px solid var(--cizgi);border-radius:var(--r-md);}
.pr-metric span,.pr-metric small{display:block;color:var(--sol);font-size:12px;line-height:1.5;}
.pr-metric strong{display:block;font:700 28px 'IBM Plex Mono',ui-monospace;color:var(--fg);margin:6px 0;font-variant-numeric:tabular-nums;}
.pr-row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--cizgi);font-size:13px;line-height:1.5;}
.pr-row span{overflow-wrap:anywhere;}
.pr-row strong{flex-shrink:0;font-variant-numeric:tabular-nums;}
.pr-green{color:var(--yesil);}
.pr-versus strong{font-size:32px;color:var(--fg);font-family:'IBM Plex Mono',monospace;font-variant-numeric:tabular-nums;}
.pr-versus span{font-size:15px;overflow-wrap:anywhere;}
.pr-form{display:flex;gap:8px;}
.pr-form>div{flex:1;background:var(--kat2);border-radius:var(--r-sm);text-align:center;padding:14px 0;}
.pr-form strong{display:block;font-size:23px;color:var(--fg);font-family:'IBM Plex Mono',monospace;}
.pr-form span{font-size:10px;color:var(--sol);}
.pr-log{border-top:1px solid var(--cizgi);padding:16px 0;font-size:13px;line-height:1.6;}
.pr-toggle{display:flex;align-items:center;gap:10px;font-size:14px;line-height:1.6;}
.pr-toggle input{width:24px;height:24px;accent-color:var(--aksan);flex-shrink:0;}
.pr-actions{display:flex;gap:8px;margin-top:12px;}
.pr-actions button{flex:1;}
.pr-card-preview{width:100%;height:auto;border-radius:var(--r-sm);display:block;}
.pr-root h2{font-size:21px;font-family:Fraunces,Georgia,serif;font-weight:560;}
.pr-root h3{font-size:17px;line-height:1.5;}
.kp button:disabled{opacity:.45;cursor:not-allowed;}
.kp-kat{overflow-wrap:anywhere;}
.kp-yukle{padding-top:80px;color:var(--sol);font-family:Fraunces,Georgia,serif;font-style:italic;font-size:20px;}

@media(min-width:420px){
.ay-grid{grid-template-columns:repeat(3,minmax(0,1fr));}
}
@media(max-width:480px){
.kp-msatir{grid-template-columns:32px minmax(32px,1fr) auto minmax(32px,1fr);gap:4px;}
.kp-msatir>div:last-child{display:none;}
.kp-sayac{display:grid!important;grid-template-columns:32px 32px 8px 32px 32px;gap:2px!important;}
.kp-sayac:has(button){grid-template-columns:32px 8px 32px;}
.kp-sayac:has(button)>:nth-child(1){grid-area:3/1;}
.kp-sayac:has(button)>:nth-child(2){grid-area:2/1;}
.kp-sayac:has(button)>:nth-child(3){grid-area:1/1;}
.kp-sayac:has(button)>:nth-child(4){grid-area:2/2;}
.kp-sayac:has(button)>:nth-child(5){grid-area:3/3;}
.kp-sayac:has(button)>:nth-child(6){grid-area:2/3;}
.kp-sayac:has(button)>:nth-child(7){grid-area:1/3;}
.kp-sayac:not(:has(button)){grid-template-columns:24px 8px 24px;}
}
@media (prefers-reduced-motion:reduce){
.kp *{transition:none!important;animation:none!important;}
}
@media (min-width:900px){
.kp-ic{max-width:980px;padding:22px 28px 40px;}
.kp-ust{padding:16px 28px;}
.kp-gazete-govde{grid-template-columns:1.15fr .85fr;gap:8px 28px;}
.kp-gazete-name{font-size:2.7rem;}
.ol-kart{grid-template-columns:repeat(3,minmax(0,1fr));}
.ay-grid{grid-template-columns:repeat(4,minmax(0,1fr));}
.pr-grid{grid-template-columns:repeat(4,minmax(0,1fr));}
.tr-grid{grid-template-columns:repeat(3,minmax(0,1fr));}
.pr-hero h1{font-size:2.15rem;}
}
@media (min-width:1100px){
.kp{flex-direction:row;}
.kp-masa-col{flex:1 1 auto;}
.kp-alt{order:-1;width:212px;flex:0 0 212px;flex-direction:column;justify-content:flex-start;align-items:stretch;border-top:none;border-right:1px solid var(--cizgi);padding:26px 12px 18px;overflow-x:hidden;overflow-y:auto;height:100%;max-height:100dvh;background:color-mix(in oklab,var(--kat) 70%,var(--bg));gap:3px;}
.kp-alt:before{content:"Kupon";display:block;font-family:Fraunces,Georgia,serif;font-style:italic;font-weight:560;font-size:28px;letter-spacing:-.03em;padding:2px 12px 18px;color:var(--fg);}
.kp-alt button{flex:0 0 auto;width:100%;min-width:0;text-align:left;font-size:12px;letter-spacing:.1em;padding:12px 14px;border-radius:10px;box-shadow:none;}
.kp-alt button.on{background:color-mix(in oklab,var(--aksan) 12%,var(--kat));box-shadow:inset 3px 0 0 var(--aksan);}
.kp-ust{padding:18px 40px;}
.kp-ic{max-width:none;margin:0;padding:28px 40px 56px;}
.kp-masa{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;}
.kp-masa>.kp-kat{margin-bottom:0;}
.kp-gazete{box-shadow:8px 8px 0 #2C241C;}
.kp-gazete-name{font-size:3.35rem;padding:22px 28px 4px;letter-spacing:.2em;}
.kp-gazete-ust{padding:8px 28px;}
.kp-gazete-bas{font-size:2.25rem;padding:20px 28px 14px;}
.kp-gazete-govde{padding:8px 28px 24px;}
.pr-hero{padding:20px 22px 12px;}
.pr-hero h1{font-size:2.4rem;}
.rl-hero h1{font-size:3.1rem;}
.kp-odul{min-height:260px;}
.kp-kupon-masa{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(280px,.75fr);gap:16px 24px;align-items:start;}
.kp-kupon-masa>.kp-kagit{margin-bottom:0;}
.kp-surum{display:none;}
.mg-bakiye{max-width:560px;}
.pr-tabs button{font-size:13.5px;padding:10px 16px;}
}

`;
    if (yukleniyor)
        return React.createElement("div", { className: "kp" },
            React.createElement("style", null, stil),
            React.createElement("div", { className: "kp-ic kp-yukle" }, "Yükleniyor…"));
    const Bilgi = () => bilgi ? (React.createElement("div", { className: "kp-bilgi" },
        React.createElement("span", null, bilgi),
        React.createElement("button", { onClick: () => setBilgi(""), "aria-label": "Kapat" }, "×"))) : null;
    /* ---------- GİRİŞ ---------- */
    if (ekran === "giris") {
        return (React.createElement("div", { className: "kp" },
            React.createElement("style", null, stil),
            React.createElement("div", { className: "kp-ic", style: { paddingTop: 28 } },
                React.createElement("header", { className: "kp-masthead" },
                    React.createElement("div", { className: "kp-mast-meta" }, new Date().toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "Europe/Istanbul" }), "  ·  Süper Lig 2026–27"),
                    React.createElement("h1", { className: "kp-mark" }, "Kupon"),
                    React.createElement("p", { className: "kp-mast-sub" }, "Haftalık tahmin  ·  sezonluk portföy")),
                React.createElement(Bilgi, null),
                !MISAFIR && React.createElement("div", { className: "kp-kaydet" },
                    React.createElement("b", null, "GitHub’da yayında"),
                    React.createElement("p", null, "Güncel Kupon, RULET dahil, senin Pages adresinde. İndirme tuşuna gerek yok."),
                    React.createElement("div", { className: "sira" },
                        React.createElement("a", {
                            className: "kp-dg",
                            href: "https://metoapps.github.io/Kupon/",
                            target: "_blank",
                            rel: "noopener noreferrer",
                        }, "Sayfayı aç"),
                        React.createElement("a", {
                            className: "kp-dg2",
                            href: "/kupon-github.zip",
                            download: "kupon-github.zip",
                            style: { width: "100%" },
                        }, "Zip yedek indir"))),
                React.createElement("div", { className: "kp-giris-gorsel" },
                    React.createElement("img", { src: GIRIS_GORSEL, alt: "Stat ışığında kupon kâğıdı ve altın külçe" })),
                React.createElement("p", { className: "pr-muted", style: { marginTop: 0 } },
                    MISAFIR
                        ? "PIN yok, yazma yok. Kim kupon yatırdı ve klasman görünür; tahminler maç bitene kadar gizli."
                        : ("Her hafta dokuz maça skor yaz, birini banko seç. Tam skor 5, fark 3, sonuç 2 — banko katlar. Sezon başında " + KREDI + " krediyle dört takım al; lig puanları da senin olur.")),
                React.createElement("div", { style: { marginTop: 26 } },
                    React.createElement("div", { className: "kp-et" }, "Grup kodu"),
                    React.createElement("input", { className: "kp-gir kp-mono", value: lig, onChange: e => setLig(e.target.value.toLowerCase().replace(/[^a-z0-9]/g, "")), placeholder: "besikodu", maxLength: 20 }),
                    React.createElement("div", { style: { fontSize: 11.5, color: "var(--sol)", marginTop: 7 } }, "Ayn\u0131 kodu girenler ayn\u0131 ligde. Gruba bu kodu at.")),
                !MISAFIR && React.createElement("div", { style: { marginTop: 18 } },
                    React.createElement("div", { className: "kp-et" }, "Ad\u0131n"),
                    React.createElement("input", { className: "kp-gir", value: isim, onChange: e => setIsim(e.target.value), placeholder: "Meto", maxLength: 16 }),
                    React.createElement("div", { style: { display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" } }, TAKMA_ADLAR.map(n => (React.createElement("button", { key: n, className: "kp-dg2", style: { padding: "6px 12px 6px 6px", fontSize: 12.5, display: "flex", alignItems: "center", gap: 8, borderColor: isim === n ? "var(--aksan)" : "var(--cizgi)", color: isim === n ? "var(--aksan)" : "var(--fg)" }, onClick: () => setIsim(n) },
                        React.createElement(Yuz, { isim: n, boy: 34, vurgu: isim === n }),
                        n))))),
                React.createElement("div", { style: { marginTop: 24 } },
                    MISAFIR
                        ? React.createElement("button", { className: "kp-dg", disabled: !lig.trim() || mesgul, onClick: () => misafirAc(lig).catch(e => setBilgi(e.message || "Grup bulunamadı.")) }, mesgul ? "…" : "İzle")
                        : React.createElement("button", { className: "kp-dg", disabled: !lig.trim() || !isim.trim() || mesgul, onClick: () => girisDene(lig, isim, false) }, mesgul ? "…" : "Devam")),
                React.createElement("p", { style: { fontSize: 11, color: "var(--sol)", marginTop: 20, lineHeight: 1.6 } }, MISAFIR ? "Bu bağlantı salt okunur. Tahmin yazamaz, PIN sorulmaz, kasa işlemi yapamazsın." : "Ad\u0131n\u0131 se\u00E7tikten sonra sana \u00F6zel 4 haneli bir PIN belirleyeceksin. Ayn\u0131 telefondan bir daha sorulmaz."))));
    }
    /* ---------- PIN ---------- */
    if (ekran === "pin" && pinEkrani) {
        const { isim: pIsim, yeni } = pinEkrani;
        return (React.createElement("div", { className: "kp" },
            React.createElement("style", null, stil),
            React.createElement("div", { className: "kp-ic", style: { paddingTop: 40 } },
                React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 14, marginBottom: 22 } },
                    React.createElement(Yuz, { isim: pIsim, boy: 72, vurgu: true }),
                    React.createElement("div", null,
                        React.createElement("div", { className: "kp-h", style: { fontSize: 24 } }, pIsim),
                        React.createElement("div", { className: "kp-mono", style: { fontSize: 11, color: "var(--sol)", marginTop: 4 } }, pinEkrani.lig.toUpperCase()))),
                React.createElement("div", { className: "kp-kat" },
                    React.createElement("div", { className: "kp-et" }, yeni ? "PIN belirle" : "PIN gir"),
                    React.createElement("div", { style: { fontSize: 13.5, color: "var(--sol)", lineHeight: 1.65, marginBottom: 16 } }, yeni
                        ? "Bu isim ilk kez kullanılıyor. 4 rakamlı bir PIN belirle — bundan sonra bu isimle sadece PIN'i bilen girebilir."
                        : "Bu isim daha önce kullanılmış. Devam etmek için PIN'ini gir."),
                    React.createElement("input", { className: "kp-gir kp-mono", inputMode: "numeric", type: "password", autoComplete: "off", style: { textAlign: "center", fontSize: 26, letterSpacing: ".5em", padding: "14px 0" }, value: pin, placeholder: "\u2022\u2022\u2022\u2022", maxLength: 4, onChange: e => { setPin(e.target.value.replace(/\D/g, "").slice(0, 4)); setPinHata(""); } }),
                    yeni && (React.createElement("input", { className: "kp-gir kp-mono", inputMode: "numeric", type: "password", autoComplete: "off", style: { textAlign: "center", fontSize: 26, letterSpacing: ".5em", padding: "14px 0", marginTop: 10 }, value: pin2, placeholder: "tekrar", maxLength: 4, onChange: e => { setPin2(e.target.value.replace(/\D/g, "").slice(0, 4)); setPinHata(""); } })),
                    pinHata && React.createElement("div", { style: { color: "var(--kirmizi)", fontSize: 13, marginTop: 12, fontWeight: 600 } }, pinHata),
                    React.createElement("button", { className: "kp-dg", style: { marginTop: 16 }, disabled: mesgul || pin.length !== 4 || (yeni && pin2.length !== 4), onClick: pinOnayla }, mesgul ? "…" : yeni ? "PIN'i kaydet ve gir" : "Gir"),
                    React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: () => { setPinEkrani(null); setPin(""); setPin2(""); setPinHata(""); setEkran("giris"); } }, "Geri")),
                React.createElement("div", { style: { fontSize: 11.5, color: "var(--sol)", lineHeight: 1.65, padding: "0 4px" } }, "PIN unutulursa grubu kuran ki\u015Fi kayd\u0131 silip yeniden belirletir."))));
    }
    /* ---------- TAKIM LİSTESİ (ilk kurulum) ---------- */
    if (ekran === "takimlar") {
        return (React.createElement("div", { className: "kp" },
            React.createElement("style", null, stil),
            React.createElement("div", { className: "kp-ust" },
                React.createElement("div", { className: "kp-h", style: { fontSize: 19 } }, "Lig kadrosu"),
                React.createElement("div", { className: "kp-mono", style: { fontSize: 11, color: "var(--sol)" } },
                    takimDuzen.length,
                    " tak\u0131m")),
            React.createElement(Bilgi, null),
            React.createElement("div", { className: "kp-ic" },
                React.createElement("p", { style: { color: "var(--sol)", fontSize: 13.5, lineHeight: 1.6, marginTop: 0 } }, "Liste 2026-27 S\u00FCper Lig'i. Sa\u011Fdaki say\u0131 tak\u0131m\u0131n ge\u00E7en sezon toplad\u0131\u011F\u0131 ger\u00E7ek puan \u2014 portf\u00F6y fiyat\u0131 buradan hesaplan\u0131yor. Erzurumspor, Amedspor ve \u00C7orum yeni \u00E7\u0131kt\u0131\u011F\u0131 i\u00E7in onlar\u0131nki tahmin (35/34/33)."),
                takimDuzen.map((t, i) => (React.createElement("div", { key: i, style: { display: "grid", gridTemplateColumns: "1fr 62px 54px", gap: 6, marginBottom: 6 } },
                    React.createElement("input", { className: "kp-gir", style: { padding: 9, fontSize: 13.5 }, value: t.ad, onChange: e => { const y = [...takimDuzen]; y[i] = { ...t, ad: e.target.value }; setTakimDuzen(y); } }),
                    React.createElement("input", { className: "kp-gir kp-mono", style: { padding: 9, fontSize: 13, textAlign: "center" }, value: t.kod, maxLength: 4, onChange: e => { const y = [...takimDuzen]; y[i] = { ...t, kod: e.target.value.toUpperCase() }; setTakimDuzen(y); } }),
                    React.createElement("input", { className: "kp-gir kp-mono", style: { padding: 9, fontSize: 13, textAlign: "center" }, value: t.gp, onChange: e => { const y = [...takimDuzen]; y[i] = { ...t, gp: Math.max(0, Math.min(102, +e.target.value || 0)) }; setTakimDuzen(y); } })))),
                React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: () => setTakimDuzen([...takimDuzen, { ad: "", kod: "", gp: 35 }]) }, "Tak\u0131m ekle"),
                React.createElement("div", { style: { marginTop: 16 } },
                    React.createElement("div", { className: "kp-et" }, "Gruptaki oyuncu sayısı"),
                    React.createElement("input", { className: "kp-gir kp-mono", inputMode: "numeric", type: "number", min: 2, max: 18, value: beklenenGiris, onChange: e => setBeklenenGiris(e.target.value.replace(/\D/g, "").slice(0, 2)), style: { marginBottom: 8 } }),
                    React.createElement("div", { style: { fontSize: 12, color: "var(--sol)", lineHeight: 1.55, marginBottom: 14 } }, "Portföyler bu sayıya ulaşıp herkes kilitleyince açılır. Sonra ayarlardan değiştirebilirsin."),
                    React.createElement("button", { className: "kp-dg", onClick: () => guvenliIslem(kurulumBitir) }, "Ligi kur")))));
    }
    /* ---------- PORTFÖY KURULUMU ---------- */
    if (ekran === "portfoyKur") {
        const harcanan = portfoySecim.reduce((s, i) => s + fiyat(takimlar[i]), 0);
        const buyukSecili = portfoySecim.find(x => { var _a; return BUYUK4.includes((_a = takimlar[x]) === null || _a === void 0 ? void 0 : _a.kod); });
        // Bu takımı alırsam portföyü 4'e tamamlamak hâlâ mümkün mü?
        const uygunMu = (i) => {
            const f = fiyat(takimlar[i]);
            const kalanButce = KREDI - harcanan - f;
            if (kalanButce < 0)
                return false;
            const kalanSlot = PORTFOY_ADET - portfoySecim.length - 1;
            if (kalanSlot === 0)
                return true;
            const buyukVar = buyukSecili !== undefined || BUYUK4.includes(takimlar[i].kod);
            const enUcuz = takimlar
                .map((t, j) => ({ j, f: fiyat(t), b: BUYUK4.includes(t.kod) }))
                .filter(x => x.j !== i && !portfoySecim.includes(x.j) && !(buyukVar && x.b))
                .sort((a, b) => a.f - b.f)
                .slice(0, kalanSlot);
            if (enUcuz.length < kalanSlot)
                return false;
            return enUcuz.reduce((s, x) => s + x.f, 0) <= kalanButce;
        };
        const cikmaz = portfoySecim.length > 0 && portfoySecim.length < PORTFOY_ADET &&
            !takimlar.some((_, i) => !portfoySecim.includes(i) && uygunMu(i) &&
                !(BUYUK4.includes(takimlar[i].kod) && buyukSecili !== undefined));
        /* Fiyat kuşakları: piyasayı bir bakışta okunur kılar */
        const KUSAKLAR = [
            { ad: "Elit", alt: 31, ust: 99, t: "t1" },
            { ad: "\u00dcst s\u0131n\u0131f", alt: 20, ust: 30, t: "t2" },
            { ad: "Orta", alt: 13, ust: 19, t: "t3" },
            { ad: "Ucuz", alt: 0, ust: 12, t: "t4" },
        ];
        const kusakOf = (f) => KUSAKLAR.find(k => f >= k.alt && f <= k.ust) || KUSAKLAR[3];
        /* Bir takım neden alınamıyor? Sessizce soluklaştırmak yerine sebebini söyle. */
        const kapaliSebep = (i) => {
            const t = takimlar[i];
            if (portfoySecim.length >= PORTFOY_ADET) return "portf\u00f6y dolu";
            if (BUYUK4.includes(t.kod) && buyukSecili !== undefined && buyukSecili !== i) return "b\u00fcy\u00fck 4 dolu";
            if (!uygunMu(i)) return "b\u00fct\u00e7e yetmez";
            return "";
        };
        const oran = Math.min(100, Math.round(harcanan / KREDI * 100));
        const kalan = KREDI - harcanan;
        const durum = kalan < 0 ? "tas" : (kalan <= 10 && portfoySecim.length < PORTFOY_ADET) ? "dar" : "";
        const sec = (i) => {
            if (portfoySecim.includes(i)) setPortfoySecim(portfoySecim.filter(x => x !== i));
            else if (!kapaliSebep(i)) setPortfoySecim([...portfoySecim, i]);
        };
        return (React.createElement("div", { className: "kp" },
            React.createElement("style", null, stil),
            React.createElement("div", { className: "pf-ust" },
                React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 9 } },
                    React.createElement("div", { className: "kp-h", style: { fontSize: 17 } }, "Portf\u00F6y\u00FCn\u00FC kur"),
                    React.createElement("div", { className: "kp-mono", style: { fontSize: 11, color: "var(--sol)" } }, portfoySecim.length + "/" + PORTFOY_ADET + " tak\u0131m")),
                React.createElement("div", { className: "pf-slotlar" },
                    Array.from({ length: PORTFOY_ADET }).map((_, n) => {
                        const idx = portfoySecim[n];
                        const t = idx === undefined ? null : takimlar[idx];
                        return React.createElement("div", { key: n, className: "pf-slot" + (t ? " dolu" : ""),
                            onClick: () => t && sec(idx), title: t ? t.ad : "" },
                            t ? React.createElement(React.Fragment, null,
                                React.createElement("span", { className: "pf-slot-kod" }, t.kod),
                                React.createElement("span", { className: "pf-slot-f" }, fiyat(t)))
                              : React.createElement("span", { className: "pf-slot-bos" }, "+"));
                    })),
                React.createElement("div", { className: "pf-butce" },
                    React.createElement("div", { className: "pf-cubuk " + durum },
                        React.createElement("i", { style: { width: oran + "%" } })),
                    React.createElement("div", { className: "pf-kalan " + durum }, kalan,
                        React.createElement("span", null, "KRED\u0130")))),
            React.createElement(Bilgi, null),
            React.createElement("div", { className: "kp-ic" },
                React.createElement("details", { style: { background: "var(--kat)", border: "1px solid var(--cizgi)", borderRadius: 12, padding: "11px 14px", marginBottom: 4 } },
                    React.createElement("summary", { style: { cursor: "pointer", fontSize: 13, color: "var(--fg)", fontWeight: 600 } },
                        KREDI + " kredi, " + PORTFOY_ADET + " tak\u0131m \u2014 kurallar"),
                    React.createElement("div", { style: { fontSize: 13, lineHeight: 1.7, color: "var(--sol)", marginTop: 10 } },
                        "B\u00fcy\u00fck 4'ten ",
                        React.createElement("strong", { style: { color: "var(--banko)" } }, "en fazla birini"),
                        " alabilirsin. Bir tak\u0131m\u0131 grupta yaln\u0131z sen ald\u0131ysan puan\u0131 ",
                        React.createElement("strong", { style: { color: "var(--yesil)" } }, "\u00D7" + TEK_SAHIP_CARPAN),
                        " say\u0131l\u0131r. Sezon ba\u015F\u0131nda bir kere se\u00E7iliyor, sonra de\u011Fi\u015Fmiyor.",
                        React.createElement("div", { style: { marginTop: 10, paddingTop: 10, borderTop: "1px solid var(--cizgi)", fontSize: 12.5 } },
                            "Fiyatlar ge\u00E7en sezonun ger\u00E7ek puanlar\u0131ndan t\u00FCretildi. B\u00FCt\u00E7eyi tam harcayan her portf\u00F6y\u00FCn beklentisi e\u015Fit \u2014 kazanmak i\u00E7in bir tak\u0131m\u0131n ge\u00E7en seneki puan\u0131n\u0131 a\u015Faca\u011F\u0131na ya da alt\u0131nda kalaca\u011F\u0131na do\u011Fru bahse girmen gerekiyor."),
                        React.createElement("div", { style: { marginTop: 8, color: "var(--banko)", fontSize: 12.5 } }, "Se\u00E7im k\u00F6r: kimse kimsenin portf\u00F6y\u00FCn\u00FC g\u00F6rm\u00FCyor, hepsi herkes kilitleyince a\u00E7\u0131l\u0131yor."))),
                cikmaz && (React.createElement("div", { className: "kp-kat", style: { borderColor: "var(--kirmizi)", background: "rgba(240,86,74,.08)", marginTop: 12 } },
                    React.createElement("div", { className: "kp-et", style: { color: "var(--kirmizi)", marginBottom: 8 } }, "B\u00FCt\u00E7e t\u0131kand\u0131"),
                    React.createElement("div", { style: { fontSize: 13, lineHeight: 1.65, marginBottom: 12, color: "var(--sol)" } },
                        "Kalan " + kalan + " krediyle portf\u00F6y\u00FC " + PORTFOY_ADET + " tak\u0131ma tamamlayamazs\u0131n. Se\u00E7ti\u011Fin pahal\u0131 tak\u0131mlardan birini \u00E7\u0131kar."),
                    React.createElement("button", { className: "kp-dg2", style: { width: "100%" }, onClick: () => setPortfoySecim([]) }, "Ba\u015Ftan ba\u015Fla"))),
                KUSAKLAR.map(ku => {
                    const grup = takimlar.map((t, i) => ({ t, i })).filter(x => kusakOf(fiyat(x.t)).ad === ku.ad)
                        .sort((a, b) => fiyat(b.t) - fiyat(a.t));
                    if (!grup.length) return null;
                    return React.createElement(React.Fragment, { key: ku.ad },
                        React.createElement("div", { className: "pf-kusak" },
                            React.createElement("b", null, ku.ad),
                            React.createElement("i", null),
                            React.createElement("em", null, (ku.ust > 90 ? fiyat(grup[grup.length - 1].t) + "\u2013" + fiyat(grup[0].t) : ku.alt + "\u2013" + ku.ust) + " kredi")),
                        grup.map(({ t, i }) => {
                            const secili = portfoySecim.includes(i);
                            const sebep = secili ? "" : kapaliSebep(i);
                            const f = fiyat(t);
                            return React.createElement("div", { key: i, onClick: () => sec(i), role: "button", tabIndex: 0,
                                onKeyDown: e => e.key === "Enter" && sec(i),
                                className: "pf-satir" + (secili ? " secili" : "") + (sebep ? " kapali" : "") },
                                React.createElement("div", { className: "pf-kod" }, t.kod),
                                React.createElement("div", null,
                                    React.createElement("div", { className: "pf-ad" }, t.ad,
                                        BUYUK4.includes(t.kod) && React.createElement("span", { className: "pf-b4" }, "B\u00DCY\u00DCK 4")),
                                    sebep ? React.createElement("div", { className: "pf-sebep" }, sebep)
                                          : React.createElement("div", { className: "pf-alt" }, t.yeni ? "yeni \u00e7\u0131kt\u0131 \u00b7 tahmin " + t.gp : "ge\u00e7en sezon " + t.gp + " puan")),
                                React.createElement("div", { className: "pf-fiyat " + kusakOf(f).t }, f));
                        }));
                }),
                React.createElement("div", { style: { marginTop: 18 } },
                    React.createElement("button", { className: "kp-dg", disabled: portfoySecim.length !== PORTFOY_ADET || harcanan > KREDI, onClick: () => guvenliIslem(portfoyKaydet) }, portfoySecim.length === PORTFOY_ADET ? "Portf\u00f6y\u00fc kilitle" : (PORTFOY_ADET - portfoySecim.length) + " tak\u0131m daha se\u00e7"),
                    portfoySecim.length > 0 && (React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: () => setPortfoySecim([]) }, "Se\u00E7imi temizle"))))));
    }
    /* ---------- OYUN ---------- */
    if (!ben) {
        return React.createElement("div", { className: "kp" },
            React.createElement("style", null, stil),
            React.createElement("div", { className: "kp-ic", style: { paddingTop: 40 } }, "Yükleniyor…"));
    }
    const oyuncular = (kurulum === null || kurulum === void 0 ? void 0 : kurulum.oyuncular) || [];
    const veren = Object.keys(kuponlar).length;
    const oyuncuAd = (sl) => ((oyuncular.find(o => o.slug === sl) || {}).isim) || sl;
    function magazaGorunumu() {
        const nakit = nakitHesap(ben.slug);
        const servet = servetHesap(ben.slug);
        const weeks = (tablo && tablo.haftalar) || [];
        const hZ = weeks[weeks.length - 1];
        const sonuncular = hZ ? haftaOdul(hZ).filter(x => x.unvan === "dallama") : [];
        const benSonuncu = sonuncular.some(x => x.slug === ben.slug);
        const zekatVerildi = !!(hZ && (magaza.zekat || []).some(z => z.veren === ben.slug && +z.hafta === +hZ.no));
        const siraliServet = oyuncular.map(o => ({
            slug: o.slug, isim: o.isim,
            nakit: nakitHesap(o.slug), servet: servetHesap(o.slug), mallar: sahipMallar(o.slug),
        })).sort((a, b) => b.servet - a.servet || b.nakit - a.nakit);
        const zekatGecmis = (magaza.zekat || []).slice().sort((a, b) => b.zaman - a.zaman).slice(0, 12);
        const vitrin = MAGAZA_URUNLER.map(u => {
            const stok = kalanStok(u.id);
            const yetmez = nakit < u.fiyat;
            const kapali = MISAFIR || stok <= 0 || yetmez || mesgul;
            const onay = satinOnay === u.id
                ? H("div", { className: "kp-kat mg-onay", style: { margin: "10px 0 0", padding: "12px" } },
                    H("div", { style: { fontSize: 13.5, lineHeight: 1.55, marginBottom: 10 } },
                        u.ad + " için " + paraYaz(u.fiyat) + " nakit düşer. Servetin aynı kalır."),
                    H("button", { className: "kp-dg", disabled: mesgul, onClick: () => guvenliIslem(() => satinAl(u.id)) }, mesgul ? "…" : "Evet, al"),
                    H("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: () => setSatinOnay(null) }, "Vazgeç"))
                : H("button", {
                    className: "kp-dg2" + (stok <= 0 ? " mg-tukendi" : yetmez ? " mg-yetmez" : ""),
                    style: { width: "100%", marginTop: 10 }, disabled: kapali, onClick: () => setSatinOnay(u.id),
                }, stok <= 0 ? "Tükendi" : yetmez ? "Yetersiz bakiye" : "Satın al");
            return H("div", { key: u.id, className: "mg-lej" },
                H("img", { className: "mg-lej-bg", src: LEJYONER_GORSEL, alt: "" }),
                H("div", { className: "mg-lej-ic" },
                    H("div", { className: "kp-odul-bas" }, "SEZONLUK ÖDÜL"),
                    H("div", { className: "mg-ad", style: { fontFamily: "Fraunces,Georgia,serif", fontStyle: "italic", fontSize: 26, fontWeight: 560 } }, u.ad),
                    H("div", { className: "mg-alt" }, u.alt),
                    H("div", { className: "mg-fiyat" }, paraYaz(u.fiyat)),
                    H("div", { className: "mg-stok" + (stok ? "" : " yok") }, stok ? (stok + " adet kaldı") : "tükendi"),
                    onay));
        });
        let zekatForm = H("p", { className: "pr-muted" }, "İlk hafta kapanınca zekât açılır.");
        if (weeks.length) {
            const kisiList = sonuncular.length
                ? H("div", { style: { display: "flex", flexDirection: "column", gap: 8, margin: "4px 0 14px" } },
                    sonuncular.map(x => H("div", { key: x.slug, style: { display: "flex", alignItems: "center", gap: 10 } },
                        H(Yuz, { isim: x.isim, boy: 40, vurgu: false }),
                        H("div", null,
                            H("div", { style: { fontSize: 15, fontWeight: 600 } }, x.isim),
                            H("span", { className: "kp-unvan kotu" }, "BİDON D'OR")))))
                : H("p", { className: "pr-muted" }, "Bu haftada sonuncu yok.");
            let eylem = null;
            if (benSonuncu) {
                eylem = H("p", { style: { fontSize: 13.5, color: "var(--banko)", lineHeight: 1.55 } }, "Bu hafta sonuncusun. Zekât alırsın, gönderemezsin.");
            } else if (zekatVerildi) {
                eylem = H("p", { className: "pr-muted" }, "Bu hafta için zekâtını verdin.");
            } else if (sonuncular.length) {
                eylem = H(React.Fragment, null,
                    H("div", { style: { display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 10 } },
                        [25, 50, 100, 250].map(n => H("button", {
                            key: n, className: "kp-dg2", type: "button",
                            style: { width: "auto", padding: "10px 14px", margin: 0 },
                            onClick: () => { setZekatMiktar(String(n)); setZekatOnay(false); },
                        }, n + " €"))),
                    H("label", { className: "pr-label" }, "Miktar (€)",
                        H("input", {
                            className: "kp-gir kp-mono", inputMode: "decimal",
                            value: zekatMiktar, placeholder: "0,01",
                            onChange: e => {
                                let t = e.target.value.replace(/[^0-9.,]/g, "").replace(/,/g, ".");
                                const p = t.split(".");
                                if (p.length > 2) t = p[0] + "." + p.slice(1).join("");
                                const [t1, t2] = t.split(".");
                                t = t2 != null ? t1 + "." + t2.slice(0, 2) : t1;
                                setZekatMiktar(t.slice(0, 10));
                                setZekatOnay(false);
                            },
                        })),
                    zekatOnay
                        ? H("div", { className: "kp-kat mg-onay", style: { margin: "10px 0 0", padding: "12px" } },
                            H("div", { style: { fontSize: 13.5, lineHeight: 1.55, marginBottom: 10 } }, "Verilen zekat geri alınamaz. Emin misin?"),
                            H("button", { className: "kp-dg", disabled: mesgul, onClick: () => guvenliIslem(zekatGonder) },
                                mesgul ? "…" : "Evet, " + zekatMiktar.replace(".", ",") + " € gönder"),
                            H("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: () => setZekatOnay(false) }, "Vazgeç"))
                        : H("button", {
                            className: "kp-dg",
                            disabled: mesgul || !Number.isFinite(parseFloat(String(zekatMiktar).replace(",", "."))) || parseFloat(String(zekatMiktar).replace(",", ".")) < 0.01,
                            onClick: () => setZekatOnay(true),
                        }, zekatMiktar ? "Zekât gönder · " + zekatMiktar.replace(".", ",") + " €" : "Zekât gönder"));
            }
            zekatForm = H(React.Fragment, null,
                hZ ? H("div", { className: "kp-et", style: { marginBottom: 8 } }, hZ.no + ". haftanın sonuncusu") : null,
                kisiList,
                sonuncular.length > 1 ? H("p", { className: "pr-muted" }, "Beraberlikte miktar eşit bölünür.") : null,
                eylem);
        }
        return H(React.Fragment, null,
            kerizKutusu(),
            H("div", { className: "mg-bakiye" },
                H("div", { className: "mg-bak" },
                    H("b", null, "NAKİT"),
                    H("strong", null, paraYaz(nakit)),
                    H("em", null, "Harcanabilir bakiye")),
                H("div", { className: "mg-bak" },
                    H("b", null, "SERVET"),
                    H("strong", { style: { color: "var(--banko)" } }, paraYaz(servet)),
                    H("em", null, "Nakit + malların bedeli"))),
            H("div", { className: "kp-kat" },
                H("div", { className: "kp-et" }, "Zekât"),
                H("p", { className: "pr-muted", style: { marginTop: 0 } }, "Haftanın fakirine zekat verenin geçmiş günahları affolur"),
                zekatForm,
                zekatGecmis.length ? H("div", { style: { marginTop: 16, paddingTop: 12, borderTop: "1px solid var(--cizgi)" } },
                    H("div", { className: "kp-et" }, "Son zekâtlar"),
                    zekatGecmis.map(z => H("div", { key: z.id, className: "pr-row" },
                        H("span", null, oyuncuAd(z.veren) + " → " + oyuncuAd(z.alan) + " · " + z.hafta + ". hf"),
                        H("strong", { className: "kp-para iyi" }, paraYaz(z.miktar))))) : null),
            (function () {
                const hNo = hZ ? hZ.no : null;
                const hedef = weeks.length ? erzakHedefKisi() : null;
                const verdim = !!(hNo && (magaza.erzak || []).some(z => z.veren === ben.slug && +z.hafta === +hNo));
                const sayilar = oyuncular.map(o => ({
                    slug: o.slug, isim: o.isim,
                    n: (magaza.erzak || []).filter(z => z.alan === o.slug).length,
                })).sort((a, b) => b.n - a.n || a.isim.localeCompare(b.isim, "tr"));
                let erzakEylem = H("p", { className: "pr-muted" }, "Maçlar bitip hafta kapanınca market torbası açılır.");
                if (weeks.length && hedef) {
                    const benHedef = hedef.slug === ben.slug;
                    if (benHedef) {
                        erzakEylem = H("p", { style: { fontSize: 13.5, color: "var(--banko)", lineHeight: 1.55 } }, "Bu hafta para sıralamasında en sondasın. Erzak alırsın, gönderemezsin.");
                    } else if (verdim) {
                        erzakEylem = H("p", { className: "pr-muted" }, hNo + ". hafta için torbanı gönderdin.");
                    } else {
                        erzakEylem = erzakOnay
                            ? H("div", { className: "kp-kat mg-onay", style: { margin: "10px 0 0", padding: "12px" } },
                                H("div", { style: { fontSize: 13.5, lineHeight: 1.55, marginBottom: 10 } }, "Verilen erzak geri alınamaz. Emin misin?"),
                                H("button", { className: "kp-dg", disabled: mesgul || nakit < ERZAK_FIYAT, onClick: () => guvenliIslem(erzakGonder) },
                                    mesgul ? "…" : "Evet, 50 € gönder"),
                                H("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: () => setErzakOnay(false) }, "Vazgeç"))
                            : H("button", {
                                className: "kp-dg2" + (nakit < ERZAK_FIYAT ? " mg-yetmez" : ""),
                                style: { width: "100%", marginTop: 10 },
                                disabled: mesgul || nakit < ERZAK_FIYAT,
                                onClick: () => setErzakOnay(true),
                            }, nakit < ERZAK_FIYAT ? "Yetersiz bakiye" : "50 € market torbası gönder");
                    }
                }
                return H(React.Fragment, null,
                    H("div", { className: "kp-kat" },
                        H("div", { className: "kp-et" }, "Market torbası"),
                        H("p", { className: "pr-muted", style: { marginTop: 0 } }, "İsteğe bağlı — kimse göndermek zorunda değil. Hafta kapanınca para sıralamasının en düşüğüne 50 €’luk erzak. Nakit yazılmaz. Zekât alanla aynı kişi olabilir. Herkes o hafta en fazla bir kez gönderir."),
                        hNo ? H("div", { className: "kp-et", style: { marginBottom: 8 } }, hNo + ". haftanın erzakı") : null,
                        hedef ? H("div", { style: { display: "flex", alignItems: "center", gap: 10, margin: "8px 0 12px" } },
                            H(Yuz, { isim: hedef.isim, boy: 40, vurgu: false }),
                            H("div", null,
                                H("div", { style: { fontSize: 15, fontWeight: 600 } }, hedef.isim),
                                H("span", { className: "kp-unvan kotu" }, "ERZAK"))) : null,
                        erzakEylem),
                    H("div", { className: "kp-kat" },
                        H("div", { className: "kp-et" }, "Evine gelen erzak sayısı"),
                        sayilar.map(o => H("div", { key: o.slug, className: "pr-row" },
                            H("span", { style: { color: o.slug === ben.slug ? "var(--yesil)" : "var(--fg)" } }, o.isim),
                            H("strong", { className: "kp-mono", style: { fontSize: 22, color: o.n ? "var(--banko)" : "var(--sol)" } }, String(o.n))))));
            })(),
            H("div", { className: "kp-kat", style: { padding: "10px 14px 6px" } },
                H("div", { className: "kp-et" }, "Vitrin"),
                H("p", { className: "pr-muted", style: { marginTop: 0 } }, "Stok sınırlı. Alanın malı, nakit düşer — klasmanda servet durur."),
                vitrin),
            H("div", { className: "kp-kat", style: { padding: "12px 10px" } },
                H("div", { className: "kp-et", style: { padding: "0 4px" } }, "Servet sırası"),
                H("p", { className: "pr-muted", style: { padding: "0 4px" } }, "Alışveriş nakit düşürür, serveti düşürmez."),
                siraliServet.map((o, i) => H("div", {
                    key: o.slug, className: "kp-sira",
                    style: { borderTop: i ? "1px solid var(--cizgi)" : "none", background: o.slug === ben.slug ? "color-mix(in oklab, var(--banko) 14%, transparent)" : "transparent" },
                },
                    H("span", { className: "kp-mono", style: { fontSize: 12, color: i === 0 ? "var(--banko)" : "var(--sol)", width: 18, flexShrink: 0, fontWeight: 700 } }, (i + 1) + "."),
                    H(Yuz, { isim: o.isim, boy: 36, vurgu: i === 0 }),
                    H("span", { style: { display: "flex", flexDirection: "column", gap: 3, minWidth: 0, flex: 1 } },
                        H("span", { style: { fontSize: 14, fontWeight: 600, color: o.slug === ben.slug ? "var(--yesil)" : "var(--fg)" } },
                            o.isim,
                            o.mallar.map(u => H("span", { key: u.id, className: "mg-rozet" }, u.kisa))),
                        H("span", { className: "kp-mono", style: { fontSize: 11, color: "var(--sol)" } }, "nakit " + paraYaz(o.nakit))),
                    H("span", { className: "kp-para", style: { color: "var(--banko)" } }, paraYaz(o.servet))))));
    }
    function ayaktaGorunumu() {
        const a = ayakta || AYAKTA_BOS;
        const hf = aktif ? String(aktif.hafta) : "";
        const picks = (hf && a.secimler[hf]) || {};
        const coz = (hf && a.cozulen && a.cozulen[hf]) || {};
        const canli = a.canli || [];
        const giren = a.girenler.indexOf(ben.slug) >= 0;
        const hayatta = canli.indexOf(ben.slug) >= 0;
        const benimPick = picks[ben.slug];
        const benimCoz = coz[ben.slug];
        const kullan = (a.kullanilan && a.kullanilan[ben.slug]) || [];
        const nakit = nakitHesap(ben.slug);
        const girisAcik = ayaktaGirisAcik() && !giren;
        const liste = [];
        if (aktif && aktif.maclar) {
            aktif.maclar.forEach(function (m) {
                liste.push({ idx: m.e, rakip: m.d, ev: true });
                liste.push({ idx: m.d, rakip: m.e, ev: false });
            });
        }
        function nedenYaz(e) {
            return ruletNedenYaz(e.neden, e.takim != null ? T(e.takim).ad : "");
        }
        const kisiSat = function (sl, alt) {
            const o = oyuncular.find(function (x) { return x.slug === sl; });
            const isim = (o && o.isim) || sl;
            return H("div", { key: sl, className: "ay-kisi" },
                H(Yuz, { isim: isim, boy: 36 }),
                H("div", { style: { minWidth: 0, flex: 1 } },
                    H("div", { style: { fontWeight: 600, fontSize: 14 } }, isim),
                    alt ? H("div", { className: "kp-mono", style: { fontSize: 11, color: "var(--sol)", marginTop: 2 } }, alt) : null));
        };
        const buHaftaIlan = Object.keys(coz).map(function (sl) {
            const c = coz[sl];
            const takimAd = c.takim != null ? T(c.takim).ad : "";
            const metin = ruletNedenYaz(c.sonuc, takimAd);
            return { sl: sl, yazi: c.sonuc === "G" ? metin + " · masada kaldı" : metin + " · elendi" };
        });
        let secim = null;
        if (MISAFIR) {
            secim = H("p", { className: "pr-muted" }, "Misafir görünümü: kimin tura girdiği görünür, el maç bitene kadar gizli. Seçim yapılamaz.");
        } else if (!aktif) {
            secim = H("p", { className: "pr-muted" }, "Yeni hafta açılınca seçim başlar.");
        } else if (girisAcik) {
            secim = ayGirisOnay
                ? H("div", { className: "kp-kat mg-onay", style: { margin: 0, padding: 12 } },
                    H("div", { style: { fontSize: 13.5, lineHeight: 1.55, marginBottom: 10 } },
                        "Giriş " + paraYaz(AYAKTA_UCRET) + " nakitten düşer, Keriz Parası kasasına yazılır. Ruleti kazanan bu kasayı alır. Emin misin?"),
                    H("button", { className: "kp-dg", disabled: mesgul, onClick: function () { return guvenliIslem(ayaktaGir); } }, mesgul ? "…" : "Evet, tura gir"),
                    H("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: function () { setAyGirisOnay(false); } }, "Vazgeç"))
                : H(React.Fragment, null,
                    H("p", { className: "pr-muted" }, nakit < AYAKTA_UCRET
                        ? "Giriş " + paraYaz(AYAKTA_UCRET) + ". Bakiyen " + paraYaz(nakit) + "."
                        : "Bu tura girmek " + paraYaz(AYAKTA_UCRET) + " — Keriz Parası kasasına yazılır. Ruleti kazanan kasayı alır. Takımı her turda bir kez seçersin; yalnız galibiyet yaşatır. El maç bitene kadar gizli."),
                    H("button", {
                        className: "kp-dg", disabled: mesgul || nakit < AYAKTA_UCRET || ruletKapali,
                        onClick: function () { setAyGirisOnay(true); },
                    }, nakit < AYAKTA_UCRET ? "Yetersiz bakiye" : "Tura gir · " + paraYaz(AYAKTA_UCRET)));
        } else if (!giren) {
            secim = H("p", { className: "pr-muted" }, ruletKapali || teslimKapali || (a.baslangicHafta != null && aktif && +a.baslangicHafta !== +aktif.hafta) || (a.turBitisHafta != null && +a.turBitisHafta === +aktif.hafta)
                ? "Bu tura yetişemedin. Sonraki turda girersin."
                : "Teslim kapalı. Yeni turda girersin.");
        } else if (!hayatta) {
            const benEle = (a.elenen || []).filter(function (e) { return e.slug === ben.slug; }).pop();
            secim = H("p", { className: "pr-muted" }, "Bu tur senin için bitti." + (benEle ? " " + benEle.hafta + ". hafta · " + nedenYaz(benEle) + "." : ""));
        } else if (benimCoz && benimCoz.sonuc === "G") {
            secim = H("p", { className: "pr-muted" }, T(benimCoz.takim).ad + " kazandı. Masada kaldın. Elin açıldı.");
        } else if (benimPick != null) {
            secim = H("p", { className: "pr-muted" }, T(benimPick).ad + " kilitlendi. Elin gizli — maçın bitince masaya düşer.");
        } else if (ruletKapali) {
            secim = H("p", { className: "pr-muted" }, "Seçmedin. İlk maç başladı, eleneceksin.");
        } else {
            secim = H(React.Fragment, null,
                H("p", { className: "pr-muted" }, "Bu hafta kazanacak takımı seç. Kullandığın takımlar soluk. El maç bitene kadar gizli. Berabere ve mağlubiyet eler."),
                H("div", { className: "ay-grid" }, liste.map(function (x) {
                    const t = T(x.idx), r = T(x.rakip);
                    const kullanildi = kullan.indexOf(x.idx) >= 0;
                    const on = aySec === x.idx;
                    return H("button", {
                        key: x.idx, type: "button",
                        className: "ay-tak" + (on ? " on" : "") + (kullanildi ? " pas" : ""),
                        disabled: kullanildi || mesgul,
                        onClick: function () { if (!kullanildi) setAySec(x.idx); },
                    },
                        H("b", null, t.kod),
                        H("span", null, t.ad),
                        H("span", null, (x.ev ? "ev · " : "dep · ") + r.kod + (kullanildi ? " · kullanıldı" : "")));
                })),
                H("div", { className: "ay-kilit" },
                    aySecOnay
                        ? H("div", { className: "kp-kat mg-onay", style: { margin: 0, padding: 12 } },
                            H("div", { style: { fontSize: 13.5, lineHeight: 1.55, marginBottom: 10 } },
                                T(aySec).ad + " kilitlenir, değiştirilemez. Kazanmazsa elenirsin. Elin maç bitene kadar gizli. Emin misin?"),
                            H("button", { className: "kp-dg", disabled: mesgul, onClick: function () { return guvenliIslem(ayaktaKilitle); } }, mesgul ? "…" : "Evet, kilitle"),
                            H("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: function () { setAySecOnay(false); } }, "Dön"))
                        : H("button", {
                            className: "kp-dg",
                            disabled: aySec == null || ruletKapali || mesgul,
                            onClick: function () { setAySecOnay(true); },
                        }, aySec == null ? "Takım seç" : T(aySec).ad + " · kilitle")));
        }
        return H(React.Fragment, null,
            H("div", { className: "rl-hero" },
                H("div", { className: "rl-ust" },
                    H(RuletFiguru, { don: canli.length > 1 }),
                    H("div", { className: "rl-bas" },
                        H("div", { className: "kp-et", style: { marginBottom: 6 } }, "Tur " + a.tur),
                        H("h1", null, "Rulet"),
                        H("p", null, "Eller kör. Kader, o kişinin maçı bitince düşer."))),
                H("div", { className: "rl-meta" },
                    H("div", null, H("b", null, "KERİZ"), H("strong", null, paraYaz(kerizToplam(magaza, a))), H("em", null, "kazanan alır")),
                    H("div", null, H("b", null, "MASADA"), H("strong", null, String(canli.length)), H("em", null, (a.girenler.length || 0) + " kişi girdi"))),
                canli.length
                    ? H("div", { className: "rl-yuzler" }, canli.map(function (sl) {
                        const o = oyuncular.find(function (x) { return x.slug === sl; });
                        return H(Yuz, { key: sl, isim: (o && o.isim) || sl, boy: 36, vurgu: sl === ben.slug });
                    }))
                    : H("p", { className: "pr-muted", style: { marginBottom: 0 } }, "Kupon ve portföyden ayrı. Masada yalnız kimlerin girdiği görünür.")),
            H("div", { className: "kp-kat" },
                H("div", { className: "kp-et" }, "Masada"),
                canli.length ? canli.map(function (sl) {
                    return kisiSat(sl, "rulete girdi");
                }) : H("p", { className: "pr-muted" }, a.girenler.length ? "Kimse kalmadı." : "Henüz kimse girmedi.")),
            buHaftaIlan.length ? H("div", { className: "kp-kat" },
                H("div", { className: "kp-et" }, aktif ? (aktif.hafta + ". hafta · maç bitimi") : "Maç bitimi"),
                buHaftaIlan.map(function (x) {
                    return H("div", { key: x.sl, className: "pr-row" },
                        H("span", null, oyuncuAd(x.sl)),
                        H("strong", null, x.yazi));
                })) : null,
            (a.elenen || []).length ? H("div", { className: "kp-kat" },
                H("div", { className: "kp-et" }, "Elenen"),
                a.elenen.map(function (e) {
                    return kisiSat(e.slug, e.hafta + ". hf · " + nedenYaz(e));
                })) : null,
            H("div", { className: "kp-kat" },
                H("div", { className: "kp-et" }, aktif ? (aktif.hafta + ". hafta · senin elin") : "Seçim"),
                H("p", { className: "pr-muted" }, "Kimse kimsenin elini görmez. Maç bitince sonuç masaya düşer."),
                secim),
            (a.gecmis || []).length ? H("div", { className: "kp-kat" },
                H("div", { className: "kp-et" }, "Tur hikâyesi"),
                a.gecmis.slice().reverse().map(function (g, i) {
                    return H("div", { key: g.tur + "-" + i, style: { padding: "10px 0", borderBottom: "1px solid var(--cizgi)" } },
                        H("div", { style: { fontWeight: 600, marginBottom: 6 } },
                            g.devir ? (g.tur + ". tur · kazanan yok · Keriz Parası devretti") : (g.tur + ". tur · " + oyuncuAd(g.kazanan) + " kazandı · " + paraYaz(g.kasa))),
                        (g.elenen || []).map(function (e) {
                            return H("div", { key: e.slug, className: "kp-mono", style: { fontSize: 11.5, color: "var(--sol)", marginTop: 3 } },
                                oyuncuAd(e.slug) + " · " + e.hafta + ". hf · " + nedenYaz(e));
                        }));
                })) : null);
    }
    function transferGorunumu() {
        const weeks = (tablo && tablo.haftalar) || [];
        const p = ben && portfoy[ben.slug];
        const kilitler = (transfer && transfer.kilitler) || {};
        const kilitSay = Object.keys(kilitler).length;
        const pfSay = Object.keys(portfoy || {}).length;
        const benimKilit = ben && kilitler[ben.slug];
        const sure = transfer && transfer.kapanis ? Math.max(0, transfer.kapanis - simdi) : 0;
        const gun = Math.floor(sure / 86400000), sa = Math.floor((sure % 86400000) / 3600000), dk = Math.floor((sure % 3600000) / 60000);
        const sureYaz = gun + "g " + sa + "s " + dk + "dk";
        const satF = trSat == null ? 0 : transferFiyat(+trSat);
        const alF = trAl == null ? 0 : transferFiyat(+trAl);
        const komisyon = (trSat != null && trAl != null) ? TRANSFER_KOMISYON : 0;
        const kalan = p ? KREDI - (p.harcanan || 0) + (trSat == null ? 0 : satF) - (trAl == null ? 0 : alF) - komisyon : 0;
        const yasak = ((p && p.yasak) || []).map(Number);
        const benimIdx = ((p && p.takimlar) || []).map(Number);
        const alAday = takimlar.map((_, i) => i).filter(i => !benimIdx.includes(i));
        const acik = transferAcik;
        const uygulandi = !!(transfer && transfer.uygulandi);
        const satirlar = Object.entries(kilitler).map(([sl, k]) => {
            const ad = oyuncuAd(sl);
            if (k.pas) return { sl, ad, yazi: "pas geçti", dip: "bu sezon hak kullanılmadı" };
            return { sl, ad, yazi: T(k.sat).kod + " → " + T(k.al).kod, dip: (k.satF || 0) + "k − " + (k.alF || 0) + "k − " + TRANSFER_KOMISYON + "k komisyon" };
        });
        const manset = satirlar.length
            ? satirlar.map(x => x.ad + " " + (x.yazi === "pas geçti" ? "pas" : x.yazi)).join(" · ")
            : "Kimse kıpırdamadı.";
        if (weeks.length < TRANSFER_SONRA && !transfer)
            return H("div", { className: "kp-kat" },
                H("div", { className: "kp-et" }, "Devre arası transfer"),
                H("p", { className: "pr-muted", style: { marginTop: 0 } },
                    TRANSFER_SONRA + ". hafta kapanınca 3 günlüğüne bir pencere açılır. Sezonda bir kez: bir takım sat, bir al, " + TRANSFER_KOMISYON + " kredi komisyon. Sattığını geri alamazsın. Seçimler kör."));
        if (uygulandi)
            return H("div", { className: "kp-kat" },
                H("div", { className: "kp-et" }, "Devre arası pazar"),
                H("h2", { className: "kp-h", style: { fontSize: 22, margin: "4px 0 12px", color: "#7D2F24" } }, manset),
                satirlar.length ? satirlar.map(x => H("div", { key: x.sl, className: "cr-sat" },
                    H("span", { style: { display: "flex", alignItems: "center", gap: 8 } }, H(Yuz, { isim: x.ad, boy: 32 }), x.ad),
                    H("div", { className: "kp-mono", style: { fontSize: 12, textAlign: "right" } }, x.yazi, H("div", { style: { color: "var(--sol)", fontSize: 10, marginTop: 2 } }, x.dip))
                )) : H("p", { className: "pr-muted" }, "Pencere boş kapandı."));
        if (!acik && transfer && !uygulandi && simdi >= transfer.kapanis)
            return H("div", { className: "kp-kat" },
                H("div", { className: "kp-et" }, "Pencere doldu"),
                H("p", { className: "pr-muted", style: { marginTop: 0 } }, "Süre bitti. Transferler açılıyor."),
                H("button", { className: "kp-dg", disabled: mesgul, onClick: () => guvenliIslem(() => transferUygula(true)) }, "Transferleri aç"));
        if (!acik)
            return H("div", { className: "kp-kat" },
                H("div", { className: "kp-et" }, "Transfer penceresi"),
                H("p", { className: "pr-muted", style: { marginTop: 0 } }, "Pencere henüz açık değil."));
        const kilitList = H("div", { className: "kp-kat", style: { borderColor: "var(--banko)" } },
            H("div", { className: "kp-et", style: { color: "var(--banko)" } }, "Transfer penceresi açık · " + sureYaz),
            H("p", { className: "pr-muted", style: { marginTop: 0 } }, "Seçimler kör. " + kilitSay + "/" + Math.max(pfSay, 1) + " kilitledi. Herkes kilitleyince veya süre bitince açılır. Komisyon " + TRANSFER_KOMISYON + " kredi."),
            oyuncular.map(o => H("div", { key: o.slug, className: "cr-sat" },
                H("span", { style: { display: "flex", alignItems: "center", gap: 8, opacity: kilitler[o.slug] ? 1 : 0.55 } }, H(Yuz, { isim: o.isim, boy: 32, vurgu: !!kilitler[o.slug] }), o.isim),
                H("span", { className: "kp-mono", style: { fontSize: 12, color: kilitler[o.slug] ? "var(--yesil)" : "var(--sol)" } }, kilitler[o.slug] ? "kilitledi" : "bekleniyor"))),
            kilitSay >= pfSay && pfSay > 0 ? H("button", { className: "kp-dg", style: { marginTop: 10 }, disabled: mesgul, onClick: () => guvenliIslem(() => transferUygula(true)) }, "Transferleri aç") : null);
        if (p && p.transfer)
            return H(React.Fragment, null, kilitList, H("div", { className: "kp-kat" }, H("p", { className: "pr-muted", style: { margin: 0 } }, "Bu sezon hakkını kullandın.")));
        if (benimKilit)
            return H(React.Fragment, null, kilitList, H("div", { className: "kp-kat" },
                H("p", { style: { fontSize: 13.5, lineHeight: 1.6, margin: 0 } }, benimKilit.pas ? "Pas geçtin, kilitlendi." : "Transferin kilitli. Pencere kapanınca açılır.")));
        if (!p)
            return H(React.Fragment, null, kilitList, H("div", { className: "kp-kat" }, H("p", { className: "pr-muted", style: { margin: 0 } }, "Portföyün yok, transfer yok.")));
        if (trOnay)
            return H(React.Fragment, null, kilitList, H("div", { className: "kp-kat", style: { borderColor: "var(--banko)" } },
                H("div", { className: "kp-et", style: { color: "var(--banko)" } }, "Emin misin?"),
                H("p", { style: { fontSize: 13.5, lineHeight: 1.6 } }, trOnay === "pas"
                    ? "Bu sezon transfer hakkını kullanmadan kilitlersin. Geri alınamaz."
                    : "Geri alınamaz. Sattığın takımı bir daha alamazsın. " + (trSat != null && trAl != null ? T(trSat).kod + " → " + T(trAl).kod + " · kalan " + kalan + "k." : "")),
                H("button", { className: "kp-dg", disabled: mesgul, onClick: () => guvenliIslem(() => transferKilitle(trOnay === "pas")) }, trOnay === "pas" ? "Evet, pas geç" : "Evet, kilitle"),
                H("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: () => setTrOnay(false) }, "Dön")));
        return H(React.Fragment, null, kilitList, H("div", { className: "kp-kat" },
            H("div", { className: "kp-et" }, "Sat"),
            H("div", { className: "tr-grid" },
                benimIdx.map(i => H("button", { key: i, type: "button", className: "ol-sec" + (trSat === i ? " on" : ""), onClick: () => { setTrSat(i); setTrOnay(false); } },
                    H("b", null, T(i).kod + "  ·  " + transferFiyat(i) + "k"),
                    H("span", null, T(i).ad)))),
            H("div", { className: "kp-et", style: { marginTop: 14 } }, "Al"),
            H("div", { className: "tr-grid" },
                alAday.map(i => H("button", {
                    key: i, type: "button",
                    className: "ol-sec" + (trAl === i ? " on" : ""),
                    disabled: yasak.includes(i),
                    onClick: yasak.includes(i) ? undefined : () => { setTrAl(i); setTrOnay(false); },
                    style: yasak.includes(i) ? { opacity: 0.4 } : undefined,
                }, H("b", null, T(i).kod + "  ·  " + transferFiyat(i) + "k"),
                    H("span", null, T(i).ad + (yasak.includes(i) ? " · sattın, yasak" : ""))))),
            H("div", { className: "kp-mono", style: { fontSize: 12, color: kalan < 0 ? "var(--kirmizi)" : "var(--sol)", marginTop: 10 } },
                "Kalan kredi: " + kalan + "k" + (trSat != null && trAl != null ? "  ·  komisyon " + TRANSFER_KOMISYON + "k  ·  " + T(trSat).kod + " → " + T(trAl).kod : "  ·  sat ve al seç, komisyon " + TRANSFER_KOMISYON + "k")),
            H("button", { className: "kp-dg", style: { marginTop: 12 }, disabled: mesgul || trSat == null || trAl == null || kalan < 0, onClick: () => setTrOnay(true) }, "Transferi kilitle"),
            H("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, disabled: mesgul, onClick: () => setTrOnay("pas") }, "Pas — bu sezon transfer yok")));
    }
    function canliPencere() {
        if (!aktif || !aktif.maclar || !aktif.maclar.length) return false;
        const baslar = aktif.maclar.map(m => Number.isFinite(m.baslangic) ? m.baslangic : null).filter(t => t != null);
        const ilk = baslar.length ? Math.min(...baslar) : (Number.isFinite(aktif.sonTeslim) ? aktif.sonTeslim : null);
        if (ilk == null || simdi < ilk) return false;
        const map = sporDurum.hafta === aktif.hafta ? sporDurum.sonuclar : {};
        const hepsi = aktif.maclar.every(m => map[kodEslesmesi(T(m.e).kod) + ">" + kodEslesmesi(T(m.d).kod)]);
        return !hepsi;
    }
    return (React.createElement("div", { className: "kp" },
        React.createElement("style", null, stil),
        React.createElement("div", { className: "kp-masa-col" },
        React.createElement("div", { className: "kp-ust" },
            React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } },
                MISAFIR
                    ? React.createElement("div", { className: "kp-misafir" }, "Misafir")
                    : React.createElement(Yuz, { isim: ben === null || ben === void 0 ? void 0 : ben.isim, boy: 50, vurgu: true }),
                React.createElement("div", null,
                    React.createElement("div", { className: "kp-h", style: { fontSize: 18 } }, MISAFIR ? "İzleniyor" : (ben === null || ben === void 0 ? void 0 : ben.isim)),
                    React.createElement("div", { className: "kp-mono", style: { fontSize: 10.5, color: "var(--sol)", marginTop: 4 } },
                        lig.toUpperCase(),
                        " \u00B7 ",
                        (tablo === null || tablo === void 0 ? void 0 : tablo.haftalar.length) || 0,
                        " HAFTA OYNANDI"))),
            !MISAFIR && React.createElement("div", { style: { textAlign: "right" } },
                React.createElement("div", { className: "kp-mono", style: { fontSize: 20, fontWeight: 700, color: "var(--fg)" } }, ((tablo === null || tablo === void 0 ? void 0 : tablo.toplam[ben.slug]) || 0) + portfoyPuan(ben.slug)),
                React.createElement("div", { className: "kp-et", style: { marginBottom: 0, fontSize: 9 } }, "PUAN"))),
        React.createElement(Bilgi, null),
        React.createElement("div", { className: "kp-ic" },
            React.createElement("div", { className: "kp-masa" },
            aktif && React.createElement("div", { className: "kp-kat", role: "status" },
                Number.isFinite(aktif.sonTeslim)
                    ? (teslimKapali ? "Kupon teslimi kapandı · " : "Son teslim · ") + new Date(aktif.sonTeslim).toLocaleString("tr-TR", { timeZone: "Europe/Istanbul", dateStyle: "medium", timeStyle: "short" }) + " (Türkiye)"
                    : "Bu haftanın teslim saati belirlenmemiş. Yeni kupon alımı kapalı.",
                !Number.isFinite(aktif.sonTeslim) && kurucuMu && React.createElement(React.Fragment, null,
                    TeslimAlani(), React.createElement("button", { className: "kp-dg2", disabled: mesgul, onClick: () => guvenliIslem(teslimBelirle) }, "Teslim saatini kaydet"))),
            kerizSerit()),
            resmi && resmi.tabloIzi !== KAnaliz.stamp(tablo.haftalar) && React.createElement("div", { className: "kp-kat", role: "status" }, "Resmî puan kaydı eski. Portföy şimdilik girilen maç sonuçlarından hesaplanıyor; eksik maç varsa kurucu resmî puanları güncellemeli."),
            sekme === "merkez" && merkezGorunumu(),
            sekme === "kupon" && aktif && canliPencere() && React.createElement("div",{className:"kp-kat"},
                React.createElement("div",{className:"kp-et"},"Canlı skor"),
                React.createElement("p",{className:"pr-muted"},sporDurum.hafta===aktif.hafta&&sporDurum.zaman?"Son kontrol: "+new Date(sporDurum.zaman).toLocaleTimeString('tr-TR')+(sporDurum.hata?' · Önceki veri gösteriliyor.':''):"Henüz sonuç alınmadı."),
                sporDurum.hata&&React.createElement("p",{className:"pr-muted",role:"status"},sporDurum.hata),
                sporDurum.hafta===aktif.hafta&&aktif.maclar.map((m,i)=>{const sn=sporDurum.sonuclar[kodEslesmesi(T(m.e).kod)+'>'+kodEslesmesi(T(m.d).kod)];return sn?React.createElement("div",{className:"pr-row",key:i},T(m.e).kod+' – '+T(m.d).kod,React.createElement("strong",null,sn.join(' – '))):null;}),
                React.createElement("button",{className:"kp-dg2",disabled:sporDurum.mesgul,onClick:sporYenile},sporDurum.mesgul?'Kontrol ediliyor…':'Sonuçları kontrol et')),
            sekme === "kupon" && (React.createElement(React.Fragment, null, !aktif ? (MISAFIR ? (React.createElement("div", { className: "kp-kat" },
                React.createElement("div", { className: "kp-et" }, "Bu hafta"),
                React.createElement("p", { className: "pr-muted", style: { margin: 0 } }, "Hafta henüz açılmadı. Klasman ve geçmiş sonuçlar duruyor."))) : (React.createElement(React.Fragment, null,
                React.createElement("div", { className: "kp-kat" },
                    React.createElement("div", { className: "kp-et" }, "Yeni hafta"),
                    kurucuMu && React.createElement("button",{className:"kp-dg2",disabled:mesgul,onClick:()=>guvenliIslem(fiksturCek),style:{marginBottom:12}},"Güncel fikstür ve saatleri getir"),
                    hazirCozum && yeniMac.liste.length === 0 && (React.createElement("div", { style: { background: "color-mix(in oklab, var(--yesil) 12%, transparent)", border: "1px solid var(--yesil)", borderRadius: 5, padding: 12, marginBottom: 14 } },
                        React.createElement("div", { style: { fontSize: 13.5, lineHeight: 1.6, marginBottom: 10 } },
                            gelecekHafta,
                            ". haftanın kayıtlı fikstürü — ",
                            hazir.tarih,
                            ", 9 ma\u00E7."),
                        React.createElement("button", { className: "kp-dg", onClick: () => setYeniMac({ liste: hazirCozum, bekleyen: null }) }, "Fikst\u00FCr\u00FC y\u00FCkle"))),
                    React.createElement("p", { style: { fontSize: 13.5, color: "var(--sol)", lineHeight: 1.6, margin: "0 0 14px" } },
                        hazirCozum && yeniMac.liste.length === 0 ? "Ya da maçları kendin ekle: " : "Maçları ekle: ",
                        "\u00F6nce ev sahibine, sonra deplasman tak\u0131m\u0131na dokun."),
                    React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 5 } }, takimlar.map((t, i) => (React.createElement("button", { key: i, className: `kp-cip ${yeniMac.bekleyen === i ? "on" : ""} ${kullanilan.has(i) && yeniMac.bekleyen !== i ? "pas" : ""}`, disabled: kullanilan.has(i) && yeniMac.bekleyen !== i, onClick: () => takimTikla(i) }, t.kod)))),
                    yeniMac.bekleyen !== null && (React.createElement("div", { className: "kp-mono", style: { fontSize: 12, color: "var(--yesil)", marginTop: 12 } },
                        T(yeniMac.bekleyen).kod,
                        " \u2014 \u015Fimdi rakibine dokun"))),
                yeniMac.liste.length > 0 && (React.createElement("div", { className: "kp-kat" },
                    React.createElement("div", { className: "kp-et" },
                        "Hafta ",
                        ((tablo === null || tablo === void 0 ? void 0 : tablo.haftalar.length) || 0) + 1,
                        " fikst\u00FCr\u00FC"),
                    yeniMac.liste.map((m, i) => (React.createElement("div", { key: i, className: "kp-mono", style: { display: "grid", gridTemplateColumns: "1fr 22px 1fr 26px", gap: 6, alignItems: "center", padding: "8px 0", borderBottom: "1px solid var(--cizgi)", fontSize: 13 } },
                        React.createElement("div", { style: { textAlign: "right" } }, T(m.e).ad),
                        React.createElement("div", { style: { textAlign: "center", color: "var(--sol)" } }, "\u2013"),
                        React.createElement("div", null, T(m.d).ad),
                        React.createElement("button", { onClick: () => setYeniMac({ ...yeniMac, liste: yeniMac.liste.filter((_, x) => x !== i) }), style: { background: "none", border: "none", color: "var(--sol)", cursor: "pointer", fontSize: 15 }, "aria-label": "Ma\u00E7\u0131 \u00E7\u0131kar" }, "\u00D7")))),
                    TeslimAlani(), React.createElement("button", { className: "kp-dg", disabled: !kurucuMu || mesgul, style: { marginTop: 14 }, onClick: () => guvenliIslem(haftayiAc) }, "Haftay\u0131 a\u00E7")))))) : MISAFIR ? (React.createElement(React.Fragment, null,
                React.createElement("div", { className: "kp-kat" },
                    React.createElement("div", { className: "kp-et" }, "Hafta " + aktif.hafta),
                    React.createElement("p", { className: "pr-muted", style: { marginTop: 0 } }, "Tahminler maç bitene ve hafta kapanana kadar gizli. Yalnız kim kupon yatırdı görünür.")),
                React.createElement("div", { className: "kp-kat" },
                    React.createElement("div", { className: "kp-et" }, "Fikstür"),
                    aktif.maclar.map((m, i) => React.createElement("div", { key: i, className: "kp-mono", style: { display: "grid", gridTemplateColumns: "1fr 22px 1fr", gap: 6, alignItems: "center", padding: "8px 0", borderBottom: "1px solid var(--cizgi)", fontSize: 13 } },
                        React.createElement("div", { style: { textAlign: "right" } }, T(m.e).ad),
                        React.createElement("div", { style: { textAlign: "center", color: "var(--sol)" } }, "\u2013"),
                        React.createElement("div", null, T(m.d).ad)))),
                React.createElement("div", { className: "kp-kat" },
                    React.createElement("div", { className: "kp-et" }, "Kim yatırdı"),
                    oyuncular.map(o => (React.createElement("div", { key: o.slug, style: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", fontSize: 13.5, borderBottom: "1px solid var(--cizgi)" } },
                        React.createElement("span", { style: { display: "flex", alignItems: "center", gap: 10, opacity: kuponlar[o.slug] ? 1 : .55 } },
                            React.createElement(Yuz, { isim: o.isim, boy: 40, vurgu: !!kuponlar[o.slug] }),
                            o.isim),
                        React.createElement("span", { className: "kp-mono", style: { fontSize: 12, color: kuponlar[o.slug] ? "var(--yesil)" : "var(--sol)" } }, kuponlar[o.slug] ? "yatırdı" : "bekleniyor")))),
                    React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 12 }, onClick: () => kuponlariYukle(lig, aktif.hafta, "").catch(function () {}) }, "Yenile")))) : sonucGiris ? (React.createElement(React.Fragment, null,
                React.createElement("div", { className: "kp-kat" },
                    React.createElement("div", { className: "kp-et" },
                        "Ger\u00E7ek sonu\u00E7lar \u2014 ",
                        aktif.hafta,
                        ". hafta"),
                    React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginBottom: 14 }, disabled: cekiyor, onClick: sonucCek }, cekiyor ? "Çekiliyor…" : "Sonuçları internetten çek"),
                    aktif.maclar.map((m, i) => (React.createElement("div", { key: i, className: "kp-mono", style: { display: "grid", gridTemplateColumns: "1fr auto 1fr", gap: 8, alignItems: "center", padding: "10px 0", borderBottom: "1px solid var(--cizgi)" } },
                        React.createElement("div", { style: { textAlign: "right", fontSize: 13 } }, T(m.e).ad),
                        React.createElement("div", { style: { display: "flex", gap: 5, alignItems: "center" } }, [0, 1].map(j => {
                            var _a;
                            return (React.createElement("input", { key: j, inputMode: "numeric", className: "kp-gir kp-mono", style: { width: 42, padding: "7px 0", textAlign: "center", fontSize: 15 }, value: (_a = sonucGiris[i][j]) !== null && _a !== void 0 ? _a : "", onChange: e => {
                                    const v = e.target.value.replace(/\D/g, "").slice(0, 2);
                                    const y = sonucGiris.map(x => [...x]);
                                    y[i][j] = v === "" ? null : +v;
                                    setSonucGiris(y);
                                } }));
                        })),
                        React.createElement("div", { style: { fontSize: 13 } }, T(m.d).ad)))),
                    React.createElement("button", { className: "kp-dg", style: { marginTop: 14 }, disabled: mesgul, onClick: () => guvenliIslem(haftayiKapat) }, mesgul ? "Hesaplanıyor…" : "Haftayı kapat ve puanla"),
                    React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: () => setSonucGiris(null) }, "Vazge\u00E7"),
                    React.createElement("div", { style: { fontSize: 11.5, color: "var(--sol)", marginTop: 12, lineHeight: 1.6 } },
                        "Kapat\u0131nca ",
                        veren,
                        " kupon puanlan\u0131r. Kuponunu vermeyen o hafta 0 al\u0131r.")))) : (React.createElement(React.Fragment, null,
                React.createElement("div", { className: "kp-kagit" },
                    benimKupon && React.createElement("div", { className: "kp-muhur" }, "KUPON YATIRILDI"),
                    React.createElement("div", { className: "kp-kbas", style: { alignItems: "center" } },
                        React.createElement("span", null,
                            "KUPON \u00B7 HAFTA ",
                            aktif.hafta),
                        React.createElement("span", { style: { display: "flex", alignItems: "center", gap: 7 } },
                            ben.isim.toUpperCase(),
                            React.createElement("img", { src: avatarBul(ben.isim) || "", alt: "", style: { width: 26, height: 26, borderRadius: "50%", objectFit: "cover", border: "1px solid var(--cizgi)", display: avatarBul(ben.isim) ? "block" : "none" } }))),
                    React.createElement("div", { style: { fontSize: 9.5, color: "var(--sol)", letterSpacing: ".1em", paddingBottom: 8, borderBottom: "1px dashed var(--cizgi)", marginBottom: 4 } }, "B = banko  ·  bu maçın puanı ×2"),
                    aktif.maclar.map((m, i) => {
                        const t = (benimKupon || taslak);
                        if (!t)
                            return null;
                        const kilitli = !!benimKupon || teslimKapali || mesgul;
                        const oran = aktifOranlar[i];
                        const kartMac = t.kart && +t.kart.mac === i;
                        const ayar = (j, delta) => {
                            const y = { ...taslak, tahminler: taslak.tahminler.map(x => [...x]), kart: taslak.kart || { tur: null, mac: null } };
                            y.tahminler[i][j] = Math.max(0, Math.min(9, y.tahminler[i][j] + delta));
                            setTaslak(y);
                        };
                        return (React.createElement("div", { key: i, style: { borderBottom: "1px solid color-mix(in oklab, var(--murekkep) 10%, transparent)", background: kartMac ? "color-mix(in oklab, var(--aksan) 10%, transparent)" : "transparent" } },
                            React.createElement("div", { className: "kp-msatir", style: { border: "none", paddingBottom: 2 }, onClick: kilitli || !taslak || !taslak.kart || !taslak.kart.tur ? undefined : () => setTaslak({ ...taslak, kart: { ...taslak.kart, mac: i } }) },
                            React.createElement("button", { className: `kp-joker ${t.joker === i ? "on" : ""}`, disabled: kilitli, onClick: (e) => { e.stopPropagation(); setTaslak({ ...taslak, joker: i }); }, "aria-label": "Banko se\u00E7" }, "B"),
                            React.createElement("div", { className: "kp-ev" }, T(m.e).kod),
                            React.createElement("div", { className: "kp-sayac" },
                                !kilitli && React.createElement("button", { className: "kp-sbtn", onClick: (e) => { e.stopPropagation(); ayar(0, -1); }, "aria-label": "Azalt" }, "\u2212"),
                                React.createElement("span", { className: "kp-skor" }, t.tahminler[i][0]),
                                !kilitli && React.createElement("button", { className: "kp-sbtn", onClick: (e) => { e.stopPropagation(); ayar(0, 1); }, "aria-label": "Art\u0131r" }, "+"),
                                React.createElement("span", { style: { margin: "0 2px", color: "var(--sol)" } }, ":"),
                                !kilitli && React.createElement("button", { className: "kp-sbtn", onClick: (e) => { e.stopPropagation(); ayar(1, -1); }, "aria-label": "Azalt" }, "\u2212"),
                                React.createElement("span", { className: "kp-skor" }, t.tahminler[i][1]),
                                !kilitli && React.createElement("button", { className: "kp-sbtn", onClick: (e) => { e.stopPropagation(); ayar(1, 1); }, "aria-label": "Art\u0131r" }, "+")),
                            React.createElement("div", { className: "kp-dep" }, T(m.d).kod),
                            React.createElement("div", null)),
                            React.createElement("div", { className: "ol-oran" },
                                oran ? (oran.ev + "% ev · " + oran.ber + "% ber · " + oran.dep + "% dep") : "",
                                kartMac && t.kart && t.kart.tur ? "  ·  " + kartEtiket(t.kart.tur) : "")));
                    }),
                    React.createElement("div", { style: { borderTop: "1px dashed var(--cizgi)", marginTop: 10, paddingTop: 9, fontSize: 10, color: "var(--sol)", letterSpacing: ".08em", display: "flex", justifyContent: "space-between" } },
                        React.createElement("span", null, "TAM SKOR 5 \u00B7 FARK 3 \u00B7 SONU\u00C7 2"),
                        React.createElement("span", null,
                            veren,
                            "/",
                            oyuncular.length,
                            " KUPON")),
                    React.createElement("div", { style: { marginTop: 12 } },
                        React.createElement("div", { className: "kp-et", style: { color: "var(--kagit-sol)" } }, "Olay kartı · birini seç, maça dokun"),
                        React.createElement("div", { className: "ol-kart" },
                            KARTLAR.map(k => React.createElement("button", {
                                key: k.id, type: "button",
                                className: "ol-sec" + ((benimKupon || taslak) && (benimKupon || taslak).kart && (benimKupon || taslak).kart.tur === k.id ? " on" : ""),
                                disabled: !!benimKupon || teslimKapali || mesgul,
                                onClick: () => taslak && setTaslak({ ...taslak, kart: { tur: k.id, mac: (taslak.kart && taslak.kart.mac) != null ? taslak.kart.mac : null } }),
                            }, React.createElement("b", null, k.ad + "  ·  +" + k.puan), React.createElement("span", null, k.acik)))),
                        (benimKupon || taslak) && (benimKupon || taslak).kart && (benimKupon || taslak).kart.tur && (benimKupon || taslak).kart.mac == null
                            ? React.createElement("p", { style: { fontSize: 12, color: "var(--aksan)", margin: "8px 0 0" } }, "Kartın maçını yukarıdan seç.")
                            : null)),
                benimKupon ? (React.createElement("div", { className: "kp-kat", style: { textAlign: "center", padding: "14px 16px" } },
                    React.createElement("div", { style: { fontSize: 13.5, color: "var(--sol)", lineHeight: 1.6 } }, "Kuponun kilitli. Hafta kapan\u0131nca herkesin kuponu birlikte a\u00E7\u0131lacak."))) : kuponOnay ? (React.createElement("div", { className: "kp-kat", style: { borderColor: "var(--banko)" } },
                    React.createElement("div", { className: "kp-et", style: { color: "var(--banko)" } }, "Emin misin?"),
                    React.createElement("div", { style: { fontSize: 13.5, lineHeight: 1.7, marginBottom: 14 } },
                        "Kupon yat\u0131r\u0131ld\u0131ktan sonra ",
                        React.createElement("strong", null, "de\u011Fi\u015Ftirilemez"),
                        ". Bankon:",
                        " ",
                        React.createElement("strong", { className: "kp-mono", style: { color: "var(--banko)" } },
                            T(aktif.maclar[taslak.joker].e).kod,
                            " \u2013 ",
                            T(aktif.maclar[taslak.joker].d).kod),
                        taslak.kart && taslak.kart.tur != null && taslak.kart.mac != null
                            ? " · Kart: " + kartEtiket(taslak.kart.tur) + " · " + T(aktif.maclar[taslak.kart.mac].e).kod + "–" + T(aktif.maclar[taslak.kart.mac].d).kod
                            : ""),
                    React.createElement("button", { className: "kp-dg", disabled: teslimKapali || mesgul, onClick: () => guvenliIslem(kuponVer) }, "Evet, kuponu yat\u0131r"),
                    React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: () => setKuponOnay(false) }, "D\u00F6n, bir daha bakay\u0131m"))) : (React.createElement("button", { className: "kp-dg", onClick: () => setKuponOnay(true), disabled: !taslak || teslimKapali || mesgul || !taslak.kart || !taslak.kart.tur || taslak.kart.mac == null }, "Kuponu yat\u0131r")),
                React.createElement("div", { className: "kp-kat", style: { marginTop: 12 } },
                    React.createElement("div", { className: "kp-et" }, "Kim yat\u0131rd\u0131"),
                    oyuncular.map(o => (React.createElement("div", { key: o.slug, style: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", fontSize: 13.5, borderBottom: "1px solid var(--cizgi)" } },
                        React.createElement("span", { style: { display: "flex", alignItems: "center", gap: 10, color: o.slug === ben.slug ? "var(--yesil)" : "var(--fg)", opacity: kuponlar[o.slug] ? 1 : .55 } },
                            React.createElement(Yuz, { isim: o.isim, boy: 40, vurgu: !!kuponlar[o.slug] }),
                            o.isim),
                        React.createElement("span", { className: "kp-mono", style: { fontSize: 12, color: kuponlar[o.slug] ? "var(--yesil)" : "var(--sol)" } }, kuponlar[o.slug] ? "yatırdı" : "bekleniyor")))),
                    React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 12 }, onClick: () => guvenliIslem(() => kuponlariYukle(lig, aktif.hafta, ben.slug)) }, "Yenile")),
                React.createElement("div", { className: "kp-kat" },
                    React.createElement("div", { className: "kp-et" }, "Hafta bitti mi?"),
                    kurucuMu
                        ? React.createElement(React.Fragment, null,
                            React.createElement("p", { style: { fontSize: 13, color: "var(--sol)", lineHeight: 1.6, margin: "0 0 12px" } }, "Ma\u00E7lar oynand\u0131ysa sonu\u00E7lar\u0131 gir, herkesin kuponu otomatik puanlan\u0131r."),
                            React.createElement("button", { className: "kp-dg2", style: { width: "100%" }, onClick: () => setSonucGiris(aktif.maclar.map(() => [null, null])) }, "Sonu\u00E7lar\u0131 gir"))
                        : React.createElement("p", { style: { fontSize: 13, color: "var(--sol)", lineHeight: 1.6, margin: 0 } },
                            "Sonu\u00E7lar\u0131 ", React.createElement("b", { style: { color: "var(--fg)" } }, kurucuAdi), " giriyor. Ma\u00E7lar bitince hafta kapan\u0131r ve puanlar burada g\u00f6r\u00fcn\u00fcr.")))))),
            sekme === "klasman" && (React.createElement(React.Fragment, null,
                React.createElement("div", { className: "kp-odul" },
                    React.createElement("img", { className: "kp-odul-bg", src: GIRIS_GORSEL, alt: "" }),
                    React.createElement("div", { className: "kp-odul-ic" },
                        React.createElement("div", { className: "kp-odul-bas" }, "SEZONUN KASASI"),
                        React.createElement("div", { className: "kp-odul-mal" },
                            paraYaz(dagitilan),
                            React.createElement("span", { className: "kp-odul-hedef" }, " / " + SEZON_KASA.toLocaleString("tr-TR") + " \u20AC")),
                        React.createElement("div", { className: "kp-odul-alt", style: { marginTop: 2 } },
                            "Her hafta " + HAFTALIK_KASA + " \u20AC da\u011F\u0131t\u0131l\u0131yor \u2014 " + ODULLER.join(" / ") + " \u20AC."),
                        React.createElement("div", { className: "kp-odul-cizgi" }),
                        React.createElement("div", { className: "kp-odul-yildiz" }, "Sezon \u00f6d\u00fcl\u00fc · 10 kg k\u00fcl\u00e7e alt\u0131n"),
                        React.createElement("div", { className: "kp-odul-dip" }, "G\u00f6rseldeki k\u00fcl\u00e7e temsilidir."),
                        React.createElement("div", { className: "kp-odul-cizgi" }),
                        (function () {
                            const bitti = ((tablo && tablo.haftalar) || []).length >= 34;
                            const lider = klasman[0];
                            const berabere = lider && klasman.filter(x => x.genel === lider.genel).length > 1;
                            if (!lider || !klasman.length)
                                return React.createElement("div", { className: "kp-odul-alt" }, "Sezon ba\u015Flad\u0131\u011F\u0131nda burada lider g\u00f6r\u00fcn\u00fcr.");
                            if (!portfoyAcik)
                                return React.createElement(React.Fragment, null,
                                    React.createElement("div", { className: "kp-odul-ad" }, "?"),
                                    React.createElement("div", { className: "kp-odul-alt" }, "Portf\u00f6yler a\u00e7\u0131lana kadar genel lider gizli."));
                            return React.createElement(React.Fragment, null,
                                React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 9, marginTop: 2 } },
                                    React.createElement(Yuz, { isim: lider.isim, boy: 34, vurgu: true }),
                                    React.createElement("span", { className: "kp-odul-ad" }, berabere ? "Ba\u015Fa ba\u015F" : lider.isim)),
                                React.createElement("div", { className: "kp-odul-alt" },
                                    bitti ? "Sezon bitti. 1000 g alt\u0131n k\u00fcl\u00e7enin sahibi belli."
                                          : "\u015Eu an \u00f6nde \u2014 " + lider.genel + " puan. Kupon + portf\u00f6y toplam\u0131nda sezonu 1. bitiren kazan\u0131r."))
                        })())),
                sezonSerisi && React.createElement("div", { className: "gr-kut" },
                    React.createElement("div", { className: "gr-bas" }, "SEZON \u2014 B\u0130R\u0130KEN KUPON PUANI"),
                    (function () {
                        const G = sezonSerisi, W = 320, H = 130, sol = 4, sag = 4, ust = 6, alt = 16;
                        const n = G.haftalar.length;
                        const x = (i) => sol + (n === 1 ? (W - sol - sag) / 2 : i * (W - sol - sag) / (n - 1));
                        const y = (v) => ust + (H - ust - alt) * (1 - v / G.enYuksek);
                        return React.createElement("svg", { className: "gr-svg", viewBox: "0 0 " + W + " " + H, preserveAspectRatio: "none", role: "img" },
                            [0.5, 1].map((f, k) => React.createElement("line", { key: "g" + k, x1: sol, x2: W - sag, y1: y(G.enYuksek * f), y2: y(G.enYuksek * f), stroke: "var(--cizgi)", strokeWidth: 1 })),
                            G.seriler.map(se => React.createElement("polyline", {
                                key: se.slug, fill: "none", stroke: se.renk, strokeWidth: 2,
                                strokeLinejoin: "round", strokeLinecap: "round",
                                points: se.nokta.map((v, i) => x(i) + "," + y(v)).join(" ")
                            })),
                            G.seriler.map(se => React.createElement("circle", {
                                key: "s" + se.slug, cx: x(n - 1), cy: y(se.son), r: 3, fill: se.renk
                            })));
                    })(),
                    React.createElement("div", { className: "gr-ef" },
                        sezonSerisi.seriler.slice().sort((a, b) => b.son - a.son).map(se =>
                            React.createElement("span", { key: se.slug },
                                React.createElement("i", { style: { background: se.renk } }),
                                se.isim, React.createElement("b", null, se.son))))),

                portfoyAcik && ben && portfoyKarne(ben.slug) && React.createElement("div", { className: "kp-kat", style: { padding: "12px 14px" } },
                    React.createElement("div", { className: "kp-et", style: { padding: 0 } }, "Portf\u00f6y karnen"),
                    React.createElement("p", { style: { fontSize: 12, color: "var(--sol)", lineHeight: 1.55, margin: "0 0 6px" } },
                        "Her tak\u0131m\u0131n fiyat\u0131 bir beklenti demek. Sa\u011Fdaki say\u0131, o tak\u0131m\u0131n \u015Fu ana kadar beklentisinin ne kadar \u00fcst\u00fcnde ya da alt\u0131nda oldu\u011Funu g\u00f6sterir."),
                    portfoyKarne(ben.slug).map(k => React.createElement("div", { key: k.idx, className: "kn-sat" },
                        React.createElement("span", { className: "kn-kod" }, k.kod),
                        React.createElement("div", { className: "kn-orta" },
                            React.createElement("div", { className: "kn-ad" }, k.ad,
                                k.tekSahip && React.createElement("span", { className: "kn-tek" }, "TEK SAH\u0130P")),
                            React.createElement("div", { className: "kn-alt" }, k.fiyat + " kredi \u00b7 " + k.oynanan + " ma\u00e7")),
                        React.createElement("span", { className: "kn-sag" },
                            React.createElement("div", { className: "kn-fark " + (k.fark > 1.5 ? "iyi" : k.fark < -1.5 ? "kotu" : "orta") },
                                (k.fark >= 0 ? "+" : "\u2212") + Math.abs(k.fark).toFixed(1)),
                            React.createElement("div", { className: "kn-puan" }, k.gercek + " / bekl. " + k.simdiBeklenen.toFixed(0)))))),

                React.createElement("div", { className: "kp-kat", style: { padding: "12px 10px" } },
                    React.createElement("div", { className: "kp-et", style: { padding: "0 4px" } }, "Genel klasman"),
                    React.createElement("div", { className: "kp-mono", style: { display: "grid", gridTemplateColumns: "20px 1fr 46px 46px 44px", gap: 6, fontSize: 9.5, color: "var(--sol)", padding: "0 4px 8px", borderBottom: "1px solid var(--cizgi)", letterSpacing: ".08em" } },
                        React.createElement("div", null, "#"),
                        React.createElement("div", null, "OYUNCU"),
                        React.createElement("div", { style: { textAlign: "right" } }, "KUPON"),
                        React.createElement("div", { style: { textAlign: "right" } }, "PORTF\u00D6Y"),
                        React.createElement("div", { style: { textAlign: "right" } }, "TOPLAM")),
                    klasman.map((k, i) => {
                        const roz = koleksiyon(k.slug).rozet;
                        return React.createElement("div", { key: k.slug, className: "kp-mono", style: { display: "grid", gridTemplateColumns: "20px 1fr 46px 46px 44px", gap: 6, alignItems: "center", padding: "10px 4px", borderBottom: i < klasman.length - 1 ? "1px solid var(--cizgi)" : "none", background: k.slug === ben.slug ? "color-mix(in oklab, var(--banko) 14%, transparent)" : "transparent" } },
                            React.createElement("div", { style: { color: i === 0 ? "var(--yesil)" : "var(--sol)", fontWeight: 700, fontSize: 13 } }, i + 1),
                            React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 9, minWidth: 0 } },
                                React.createElement(Yuz, { isim: k.isim, boy: 40, vurgu: i === 0 }),
                                React.createElement("div", { style: { minWidth: 0 } },
                                    React.createElement("div", { style: { fontFamily: "Figtree,sans-serif", fontSize: 14, fontWeight: 600, color: k.slug === ben.slug ? "var(--yesil)" : "var(--fg)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } },
                                        k.isim,
                                        sahipMallar(k.slug).map(u => React.createElement("span", { key: u.id, className: "mg-rozet" }, u.kisa)),
                                        servetHesap(k.slug) > 0 && React.createElement("span", { className: "kp-mono", style: { fontSize: 11, marginLeft: 6, color: "var(--banko)", fontWeight: 700 } }, paraYaz(servetHesap(k.slug)))),
                                    roz.length ? React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 3, marginTop: 4, marginLeft: -4 } },
                                        roz.map(r => React.createElement("span", { key: r.id || r.ad, className: "rz-cip", title: rozetAcik(r.id) }, r.ad))) : null)),
                            React.createElement("div", { style: { textAlign: "right", fontSize: 13, color: "var(--sol)" } }, k.kupon),
                            React.createElement("div", { style: { textAlign: "right", fontSize: 13, color: "var(--sol)" } }, (portfoyAcik || k.slug === ben.slug) ? k.portfoy : "–"),
                            React.createElement("div", { style: { textAlign: "right", fontSize: 16, fontWeight: 700 } }, (portfoyAcik || k.slug === ben.slug) ? k.genel : k.kupon));
                    })),
                React.createElement("div", { className: "kp-kat" },
                    React.createElement("div", { className: "kp-et" }, "Hafta hafta"),
                    (!tablo || tablo.haftalar.length === 0) ? (React.createElement("div", { style: { fontSize: 13.5, color: "var(--sol)" } }, "Hen\u00FCz kapanm\u0131\u015F hafta yok.")) : [...tablo.haftalar].reverse().map((h) => {
                        const idx = tablo.haftalar.indexOf(h);
                        const acik = acikHafta === idx;
                        const rezMac = acik ? rezaletListesi(h) : [];
                        return (React.createElement("div", { key: h.no, style: { borderBottom: "1px solid var(--cizgi)" } },
                            React.createElement("div", { onClick: () => setAcikHafta(acik ? null : idx), role: "button", tabIndex: 0, onKeyDown: e => e.key === "Enter" && setAcikHafta(acik ? null : idx), className: "kp-haftabas", style: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 } },
                                React.createElement("div", null,
                                    React.createElement("div", { style: { fontSize: 14, fontWeight: 600 } },
                                        h.no,
                                        ". hafta"),
                                    React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 5, marginTop: 6 } },
                                        haftaOdul(h).filter(x => x.unvan).map(x => React.createElement("div", { key: x.slug, style: { display: "flex", alignItems: "center", gap: 8 } },
                                            React.createElement(Yuz, { isim: x.isim, boy: 30, vurgu: x.unvan === "alim" }),
                                            React.createElement("span", { className: "kp-unvan " + (x.unvan === "alim" ? "iyi" : "kotu") },
                                                x.unvan === "alim" ? "AL\u0130M ULEMA" : "B\u0130DON D'OR"),
                                            x.patlican && React.createElement("img", { src: PATLICAN_GORSEL, alt: "patl\u0131can \u00f6d\u00fcl\u00fc", className: "kp-patlican" }),
                                            x.bankoBonus && React.createElement("span", { className: "kp-banko2x" }, "\u00D72 BANKO"),
                                            React.createElement("span", { style: { flex: 1 } }),
                                            React.createElement("span", { className: "kp-para " + (x.unvan === "alim" ? "iyi" : "kotu") }, paraYaz(x.odul)))))),
                                React.createElement("div", { className: "kp-ac" + (acik ? " acik" : "") }, "▾")),
                            acik && (React.createElement("div", { style: { paddingBottom: 14 } },
                                (duzeltHafta && duzeltHafta.idx === idx) ? React.createElement("div", { style: { background: "var(--kat)", border: "1px solid var(--banko)", borderRadius: 10, padding: "12px", marginBottom: 10 } },
                                    React.createElement("div", { className: "kp-mono", style: { fontSize: 10, color: "var(--banko)", letterSpacing: ".08em", marginBottom: 4 } }, "SKORU D\u00dcZELT"),
                                    React.createElement("div", { style: { fontSize: 12, color: "var(--sol)", marginBottom: 11, lineHeight: 1.5 } },
                                        "Skoru de\u011Fi\u015Ftirince o haftan\u0131n puanlar\u0131, klasman ve lig tablosu ba\u015Ftan hesaplan\u0131r."),
                                    h.maclar.map((m, i) => React.createElement("div", { key: i, style: { display: "grid", gridTemplateColumns: "1fr 46px 10px 46px 1fr", gap: 5, alignItems: "center", marginBottom: 7 } },
                                        React.createElement("span", { className: "kp-mono", style: { fontSize: 11.5, textAlign: "right", color: "var(--fg)" } }, T(m.e).kod),
                                        React.createElement("input", { type: "number", inputMode: "numeric", min: 0, max: 20, value: duzeltHafta.s[i][0] === null ? "" : duzeltHafta.s[i][0],
                                            onChange: e => { const v = e.target.value; const y = duzeltHafta.s.map(x => [...x]); y[i][0] = v === "" ? null : +v; setDuzeltHafta({ idx, s: y }); },
                                            style: { textAlign: "center", padding: "7px 2px" } }),
                                        React.createElement("span", { style: { textAlign: "center", color: "var(--sol)" } }, ":"),
                                        React.createElement("input", { type: "number", inputMode: "numeric", min: 0, max: 20, value: duzeltHafta.s[i][1] === null ? "" : duzeltHafta.s[i][1],
                                            onChange: e => { const v = e.target.value; const y = duzeltHafta.s.map(x => [...x]); y[i][1] = v === "" ? null : +v; setDuzeltHafta({ idx, s: y }); },
                                            style: { textAlign: "center", padding: "7px 2px" } }),
                                        React.createElement("span", { className: "kp-mono", style: { fontSize: 11.5, color: "var(--fg)" } }, T(m.d).kod))),
                                    React.createElement("label",{className:"pr-label"},"Düzeltme nedeni",React.createElement("input",{className:"kp-gir",value:duzeltNeden,maxLength:200,onChange:e=>setDuzeltNeden(e.target.value),placeholder:"Örn. Ev sahibi skoru yanlış girilmiş"})),
                                    React.createElement("button", { className: "kp-dg", style: { marginTop: 6 }, disabled: mesgul, onClick: () => guvenliIslem(() => haftaSkorDuzelt(idx, duzeltHafta.s)) }, mesgul ? "Hesaplan\u0131yor\u2026" : "Kaydet ve yeniden hesapla"),
                                    React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 7 }, onClick: () => setDuzeltHafta(null) }, "Vazge\u00e7"))
                                : (kurucuMu ? React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginBottom: 10 }, onClick: () => {setDuzeltNeden("");setDuzeltHafta({ idx, s: h.sonuclar.map(x => [...x]) });} }, "Skoru d\u00fczelt") : null),
                                React.createElement("div", { style: { background: "var(--kat)", borderRadius: 10, padding: "10px 12px", marginBottom: 10 } },
                                    React.createElement("div", { className: "kp-mono", style: { fontSize: 10, color: "var(--sol)", letterSpacing: ".08em", marginBottom: 8 } }, "HAFTANIN KASASI"),
                                    haftaOdul(h).map(x => React.createElement("div", { key: x.slug, className: "kp-sira", style: { borderTop: "1px solid var(--cizgi)" } },
                                        React.createElement("span", { className: "kp-mono", style: { fontSize: 12, color: "var(--sol)", width: 18, flexShrink: 0 } }, x.sira + "."),
                                        React.createElement(Yuz, { isim: x.isim, boy: 30, vurgu: x.unvan === "alim" }),
                                        React.createElement("span", { style: { display: "flex", flexDirection: "column", gap: 3, minWidth: 0, flex: 1 } },
                                            React.createElement("span", { style: { fontSize: 13.5, color: "var(--fg)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } },
                                                x.isim,
                                                x.esit && React.createElement("span", { style: { fontSize: 10, color: "var(--sol)", marginLeft: 6 } }, "e\u015Fit")),
                                            x.unvan && React.createElement("span", { style: { display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" } },
                                                React.createElement("span", { className: "kp-unvan " + (x.unvan === "alim" ? "iyi" : "kotu") },
                                                    x.unvan === "alim" ? "AL\u0130M ULEMA" : "B\u0130DON D'OR"),
                                                x.patlican && React.createElement("img", { src: PATLICAN_GORSEL, alt: "patl\u0131can \u00f6d\u00fcl\u00fc", className: "kp-patlican" }),
                                                x.bankoBonus && React.createElement("span", { className: "kp-banko2x" }, "\u00D72 BANKO"))),
                                        React.createElement("span", { className: "kp-mono", style: { fontSize: 12, color: "var(--sol)", marginRight: 10, whiteSpace: "nowrap" } }, x.puan + "p"),
                                        React.createElement("span", { className: "kp-para " + (x.unvan === "alim" ? "iyi" : x.unvan === "dallama" ? "kotu" : "") }, paraYaz(x.odul))))),
                                h.maclar.map((m, i) => (React.createElement("div", { key: i, className: "kp-mono", style: { fontSize: 12, padding: "6px 0", borderTop: "1px dotted var(--cizgi)" } },
                                    React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 54px 1fr", gap: 6, alignItems: "center", marginBottom: 5 } },
                                        React.createElement("div", { style: { textAlign: "right", color: "var(--fg)" } }, T(m.e).kod),
                                        React.createElement("div", { style: { textAlign: "center", fontWeight: 700, fontSize: 14, color: "var(--yesil)" } },
                                            h.sonuclar[i][0],
                                            " : ",
                                            h.sonuclar[i][1]),
                                        React.createElement("div", { style: { color: "var(--fg)" } }, T(m.d).kod)),
                                    h.oranlar && h.oranlar[i] ? React.createElement("div", { className: "ol-oran", style: { marginBottom: 4 } },
                                        h.oranlar[i].ev + "% ev · " + h.oranlar[i].ber + "% ber · " + h.oranlar[i].dep + "% dep") : null,
                                    (function () {
                                        const tk = tekBilen(h, i);
                                        return tk ? React.createElement("div", { style: { textAlign: "center", marginBottom: 6 } },
                                            React.createElement("span", { className: "tk-roz" }, "TEK B\u0130LEN \u00b7 " + tk)) : null;
                                    })(),
                                    React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 5, justifyContent: "center" } }, Object.entries(h.tahminler || {}).map(([s, tah]) => {
                                        var _a, _b, _c, _d, _e;
                                        const p = (_c = (_b = (_a = h.detay) === null || _a === void 0 ? void 0 : _a[s]) === null || _b === void 0 ? void 0 : _b[i]) !== null && _c !== void 0 ? _c : 0;
                                        const rz = rezMac.some(z => z.slug === s && z.i === i);
                                        return (React.createElement("span", { key: s, className: rz ? "kp-rz-cip" : "", style: { fontSize: 10, padding: "3px 6px", borderRadius: 2, background: rz ? "transparent" : p >= 5 ? "rgba(47,191,113,.28)" : p > 0 ? "var(--cizgi)" : "transparent", border: `1px solid ${rz ? "var(--kirmizi)" : p >= 5 ? "var(--yesil)" : "var(--cizgi)"}`, color: rz ? "var(--kirmizi)" : p > 0 ? "var(--fg)" : "var(--sol)" } },
                                            (((_d = h.isimler) === null || _d === void 0 ? void 0 : _d[s]) || s).slice(0, 4),
                                            " ",
                                            tah[i][0],
                                            "-",
                                            tah[i][1],
                                            ((_e = h.jokerler) === null || _e === void 0 ? void 0 : _e[s]) === i ? " ★" : "",
                                            " ",
                                            React.createElement("b", { style: { color: rz ? "var(--kirmizi)" : p > 0 ? "var(--yesil)" : "var(--sol)" } }, p),
                                            rz ? React.createElement("span", { className: "kp-rz-muhur", style: { marginLeft: 4, fontSize: 8, padding: "2px 4px" } }, RZ_MUHUR) : null));
                                    }))))),
                                h.kartlar && Object.keys(h.kartlar).length ? React.createElement("div", { style: { background: "var(--kat)", borderRadius: 10, padding: "10px 12px", margin: "10px 0" } },
                                    React.createElement("div", { className: "kp-mono", style: { fontSize: 10, color: "var(--sol)", letterSpacing: ".08em", marginBottom: 8 } }, "OLAY KARTLARI"),
                                    Object.keys(h.isimler || h.kartlar).map(s => {
                                        const kart = (h.kartlar || {})[s];
                                        const kp = (h.kartPuan && h.kartPuan[s] != null) ? h.kartPuan[s] : kartPuan(kart, h.sonuclar, h.oranlar);
                                        const ad = (h.isimler && h.isimler[s]) || s;
                                        if (!kart) return React.createElement("div", { key: s, className: "cr-sat" },
                                            React.createElement("span", null, ad),
                                            React.createElement("span", { style: { color: "var(--sol)" } }, "kart yok"));
                                        const m = h.maclar[kart.mac];
                                        return React.createElement("div", { key: s, className: "cr-sat" },
                                            React.createElement("span", null, ad + " · " + kartEtiket(kart.tur)),
                                            React.createElement("span", { className: "kp-mono" },
                                                m ? T(m.e).kod + "–" + T(m.d).kod : "?",
                                                " ",
                                                React.createElement("b", { style: { color: kp > 0 ? "var(--yesil)" : "var(--sol)" } }, kp > 0 ? "+" + kp : "0")));
                                    }),
                                    (function () {
                                        const s = haftaninSurprizi(h.sonuclar, h.oranlar);
                                        if (s == null) return React.createElement("div", { style: { fontSize: 12, color: "var(--sol)", marginTop: 8 } }, "Bu hafta sürpriz yok.");
                                        const m = h.maclar[s];
                                        return React.createElement("div", { style: { fontSize: 12, color: "var(--sol)", marginTop: 8 } },
                                            "Haftanın sürprizi: " + T(m.e).kod + "–" + T(m.d).kod + " (" + gercekYuzde(h.oranlar && h.oranlar[s], h.sonuclar[s]) + "%)");
                                    })()) : null,
                                React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 6, marginTop: 12, paddingTop: 10, borderTop: "1px solid var(--cizgi)" } }, Object.entries(h.puanlar).sort((a, b) => b[1] - a[1]).map(([s, p]) => {
                                    var _a;
                                    const kp = (h.kartPuan && h.kartPuan[s]) || 0;
                                    return (React.createElement("span", { key: s, className: "kp-mono", style: { fontSize: 12, padding: "5px 9px", borderRadius: 3, background: "var(--kat2)", border: "1px solid var(--cizgi)" } },
                                        ((_a = h.isimler) === null || _a === void 0 ? void 0 : _a[s]) || s,
                                        " ",
                                        React.createElement("b", { style: { color: "var(--yesil)" } }, p),
                                        kp > 0 ? React.createElement("span", { style: { color: "var(--sol)", fontSize: 10 } }, " · kart +" + kp) : null));
                                }))))));
                    })))),
            sekme === "magaza" && magazaGorunumu(),
            sekme === "ayakta" && ayaktaGorunumu(),
            sekme === "portfoy" && (React.createElement(React.Fragment, null,
                transferGorunumu(),
                !portfoyAcik && (React.createElement("div", { className: "kp-kat", style: { borderColor: "var(--banko)", background: "rgba(245,165,36,.07)" } },
                    React.createElement("div", { className: "kp-et", style: { color: "var(--banko)" } }, "K\u00F6r se\u00E7im \u00B7 portf\u00F6yler kapal\u0131"),
                    React.createElement("div", { style: { fontSize: 13.5, lineHeight: 1.7, marginBottom: 14 } }, "Kimse birbirinin portf\u00F6y\u00FCn\u00FC g\u00F6remiyor. Kay\u0131tl\u0131 herkes portf\u00F6y\u00FCn\u00FC kilitleyince hepsi ayn\u0131 anda a\u00E7\u0131lacak."),
                    React.createElement("div", { className: "kp-mono", style: { fontSize: 12, marginBottom: 10, color: "var(--sol)" } },
                        kilitleyen, "/", beklenenOyuncu,
                        " kilitledi"),
                    oyuncular.map(o => (React.createElement("div", { key: o.slug, style: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", fontSize: 13.5, borderTop: "1px solid var(--cizgi)" } },
                        React.createElement("span", { style: { display: "flex", alignItems: "center", gap: 10, color: o.slug === ben.slug ? "var(--yesil)" : "var(--fg)", opacity: portfoy[o.slug] ? 1 : .55 } },
                            React.createElement(Yuz, { isim: o.isim, boy: 40, vurgu: !!portfoy[o.slug] }),
                            o.isim),
                        React.createElement("span", { className: "kp-mono", style: { fontSize: 12, color: portfoy[o.slug] ? "var(--yesil)" : "var(--sol)" } }, portfoy[o.slug] ? "kilitledi" : "bekleniyor")))),
                    toplamOyuncu < 2 && (React.createElement("div", { style: { fontSize: 12, color: "var(--sol)", marginTop: 12, lineHeight: 1.6 } },
                        "Gruba hen\u00FCz ba\u015Fka kimse kat\u0131lmad\u0131. Arkada\u015Flar\u0131n ",
                        React.createElement("strong", { className: "kp-mono", style: { color: "var(--yesil)" } }, lig),
                        " koduyla girsin.")),
                    React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 14 }, onClick: () => veriYukle(lig, ben.slug) }, "Yenile"))),
                oyuncular.filter(o => portfoyAcik || o.slug === ben.slug).map(o => {
                    const p = portfoy[o.slug];
                    if (!p)
                        return (React.createElement("div", { key: o.slug, className: "kp-kat" },
                            React.createElement("div", { style: { fontSize: 15, fontWeight: 600 } }, o.isim),
                            React.createElement("div", { style: { fontSize: 13, color: "var(--sol)", marginTop: 6 } }, "Hen\u00FCz portf\u00F6y kurmad\u0131.")));
                    return (React.createElement("div", { key: o.slug, className: "kp-kat", style: { borderColor: o.slug === ben.slug ? "var(--yesil)" : "var(--cizgi)" } },
                        React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 } },
                            React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } },
                                React.createElement(Yuz, { isim: o.isim, boy: 48, vurgu: o.slug === ben.slug }),
                                React.createElement("span", { style: { fontSize: 16, fontWeight: 700, color: o.slug === ben.slug ? "var(--yesil)" : "var(--fg)" } }, o.isim)),
                            React.createElement("div", { className: "kp-mono", style: { fontSize: 19, fontWeight: 700 } }, portfoyPuan(o.slug))),
                        p.takimlar.map(i => (React.createElement("div", { key: i, className: "kp-mono", style: { display: "grid", gridTemplateColumns: "42px 1fr 34px 34px", gap: 8, alignItems: "center", padding: "8px 0", borderTop: "1px solid var(--cizgi)", fontSize: 12.5 } },
                            React.createElement("div", { style: { color: "var(--sol)", fontWeight: 600 } }, T(i).kod),
                            React.createElement("div", { style: { fontFamily: "Figtree,sans-serif", fontSize: 13.5 } },
                                T(i).ad,
                                sahipSayisi(i) === 1 && React.createElement("span", { style: { color: "var(--yesil)", fontSize: 10, marginLeft: 6, fontWeight: 700 } },
                                    "x",
                                    TEK_SAHIP_CARPAN)),
                            React.createElement("div", { style: { textAlign: "right", color: "var(--sol)" } },
                                fiyat(T(i)),
                                "k"),
                            React.createElement("div", { style: { textAlign: "right", fontWeight: 700, color: "var(--yesil)" } }, takimKatki(i))))),
                        React.createElement("div", { className: "kp-mono", style: { fontSize: 10.5, color: "var(--sol)", marginTop: 9 } },
                            p.harcanan,
                            "/",
                            KREDI,
                            " kredi harcand\u0131 \u00B7 puan kayna\u011F\u0131: ",
                            resmi ? "resmi tablo" : "kupon sonuçları"),
                        p.transfer ? React.createElement("div", { className: "kp-mono", style: { fontSize: 11, color: "var(--sol)", marginTop: 6 } },
                            "Devre arası: " + T(p.transfer.sat).kod + " → " + T(p.transfer.al).kod) : null));
                }))),
            sekme === "lig" && (React.createElement("div", { className: "kp-kat", style: { padding: "12px 8px" } },
                React.createElement("div", { className: "kp-et", style: { padding: "0 6px" } },
                    "Lig tablosu \u2014 girilen kupon sonu\u00E7lar\u0131ndan",
                    resmi ? " (portföy resmi puanları kullanıyor)" : ""),
                ligSirali.length === 0 ? (React.createElement("div", { style: { fontSize: 13.5, color: "var(--sol)", padding: "0 6px" } }, "Hen\u00FCz sonu\u00E7 girilmedi.")) : (React.createElement(React.Fragment, null,
                    React.createElement("div", { className: "kp-mono", style: { display: "grid", gridTemplateColumns: "20px 1fr 24px 24px 24px 24px 32px 28px", gap: 4, fontSize: 9.5, color: "var(--sol)", padding: "0 6px 8px", borderBottom: "1px solid var(--cizgi)" } },
                        React.createElement("div", null, "#"),
                        React.createElement("div", null, "TAKIM"),
                        React.createElement("div", { style: { textAlign: "center" } }, "O"),
                        React.createElement("div", { style: { textAlign: "center" } }, "G"),
                        React.createElement("div", { style: { textAlign: "center" } }, "B"),
                        React.createElement("div", { style: { textAlign: "center" } }, "M"),
                        React.createElement("div", { style: { textAlign: "center" } }, "AV"),
                        React.createElement("div", { style: { textAlign: "right" } }, "P")),
                    ligSirali.map((s, i) => {
                        var _a;
                        const sahip = portfoyAcik
                            ? Object.entries(portfoy).filter(([, p]) => p.takimlar.includes(s.i)).map(([sl]) => { var _a; return ((_a = oyuncular.find(o => o.slug === sl)) === null || _a === void 0 ? void 0 : _a.isim) || sl; })
                            : (((_a = portfoy[ben.slug]) === null || _a === void 0 ? void 0 : _a.takimlar.includes(s.i)) ? [ben.isim] : []);
                        return (React.createElement("div", { key: s.i, className: "kp-mono", style: { display: "grid", gridTemplateColumns: "20px 1fr 24px 24px 24px 24px 32px 28px", gap: 4, alignItems: "center", padding: "9px 6px", borderBottom: "1px solid var(--cizgi)", fontSize: 12 } },
                            React.createElement("div", { style: { color: "var(--sol)" } }, i + 1),
                            React.createElement("div", { style: { fontFamily: "Figtree,sans-serif", fontSize: 12.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } },
                                T(s.i).ad,
                                sahip.length > 0 && React.createElement("span", { style: { color: "var(--yesil)", fontSize: 10.5 } },
                                    " \u00B7 ",
                                    sahip.join(", "))),
                            React.createElement("div", { style: { textAlign: "center", color: "var(--sol)" } }, s.o),
                            React.createElement("div", { style: { textAlign: "center", color: "var(--sol)" } }, s.g),
                            React.createElement("div", { style: { textAlign: "center", color: "var(--sol)" } }, s.b),
                            React.createElement("div", { style: { textAlign: "center", color: "var(--sol)" } }, s.m),
                            React.createElement("div", { style: { textAlign: "center", color: "var(--sol)" } },
                                s.av > 0 ? "+" : "",
                                s.av),
                            React.createElement("div", { style: { textAlign: "right", fontWeight: 700 } }, s.p)));
                    }))),
                React.createElement("div", { style: { fontSize: 11, color: "var(--sol)", marginTop: 14, padding: "0 6px", lineHeight: 1.6 } }, "Bu tablo sadece kupona koydu\u011Funuz ma\u00E7lardan olu\u015Fuyor. Bir haftan\u0131n t\u00FCm ma\u00E7lar\u0131n\u0131 eklemezseniz eksik kal\u0131r."),
                React.createElement("div", { style: { borderTop: "1px solid var(--cizgi)", marginTop: 16, paddingTop: 16 } },
                    React.createElement("div", { className: "kp-et", style: { padding: "0 6px" } }, "Resmi puanlar"),
                    kurucuMu && resmiTaslak ? (React.createElement(React.Fragment, null,
                        React.createElement("div", { style: { fontSize: 12.5, color: "var(--sol)", padding: "0 6px 12px", lineHeight: 1.6 } }, "TFF'nin tablosuna bak\u0131p her tak\u0131m\u0131n puan\u0131n\u0131 yaz. Bo\u015F b\u0131rakt\u0131\u011F\u0131n tak\u0131m i\u00E7in kupon sonu\u00E7lar\u0131 kullan\u0131lmaya devam eder."),
                        takimlar.map((t, i) => {
                            var _a, _b, _c;
                            return (React.createElement("div", { key: i, style: { display: "grid", gridTemplateColumns: "42px 1fr 62px", gap: 8, alignItems: "center", padding: "6px 6px" } },
                                React.createElement("div", { className: "kp-mono", style: { fontSize: 12, color: "var(--sol)", fontWeight: 600 } }, t.kod),
                                React.createElement("div", { style: { fontSize: 13.5 } }, t.ad),
                                React.createElement("input", { inputMode: "numeric", className: "kp-gir kp-mono", style: { padding: "8px 0", textAlign: "center", fontSize: 14 }, value: (_a = resmiTaslak[i]) !== null && _a !== void 0 ? _a : "", placeholder: String((_c = (_b = tablo === null || tablo === void 0 ? void 0 : tablo.ligTablo[i]) === null || _b === void 0 ? void 0 : _b.p) !== null && _c !== void 0 ? _c : 0), onChange: e => setResmiTaslak({ ...resmiTaslak, [i]: e.target.value.replace(/\D/g, "").slice(0, 3) }) })));
                        }),
                        React.createElement("button", { className: "kp-dg", style: { marginTop: 14 }, onClick: () => guvenliIslem(resmiKaydet) }, "Resmi puanlar\u0131 kaydet"),
                        React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, onClick: () => setResmiTaslak(null) }, "Vazge\u00E7"))) : resmi ? (React.createElement(React.Fragment, null,
                        React.createElement("div", { style: { fontSize: 12.5, color: "var(--sol)", padding: "0 6px 12px", lineHeight: 1.6 } },
                            "Portf\u00F6y puanlar\u0131 resmi tablodan hesaplan\u0131yor. Son g\u00FCncelleyen: ",
                            React.createElement("strong", { style: { color: "var(--fg)" } }, resmi.guncelleyen),
                            " \u00B7 ",
                            new Date(resmi.zaman).toLocaleDateString("tr-TR")),
                        takimlar.map((t, i) => {
                            var _a, _b, _c;
                            const r = (_a = resmi.puanlar) === null || _a === void 0 ? void 0 : _a[i];
                            if (r === undefined)
                                return null;
                            const k = (_c = (_b = tablo === null || tablo === void 0 ? void 0 : tablo.ligTablo[i]) === null || _b === void 0 ? void 0 : _b.p) !== null && _c !== void 0 ? _c : 0;
                            return (React.createElement("div", { key: i, className: "kp-mono", style: { display: "grid", gridTemplateColumns: "42px 1fr 46px 46px", gap: 8, alignItems: "center", padding: "7px 6px", borderTop: "1px solid var(--cizgi)", fontSize: 12.5 } },
                                React.createElement("div", { style: { color: "var(--sol)", fontWeight: 600 } }, t.kod),
                                React.createElement("div", { style: { fontFamily: "Figtree,sans-serif", fontSize: 13 } }, t.ad),
                                React.createElement("div", { style: { textAlign: "right", color: r !== k ? "var(--kirmizi)" : "var(--sol)" } }, k),
                                React.createElement("div", { style: { textAlign: "right", fontWeight: 700, color: "var(--yesil)" } }, r)));
                        }),
                        React.createElement("div", { className: "kp-mono", style: { fontSize: 10, color: "var(--sol)", padding: "10px 6px 0", display: "flex", justifyContent: "flex-end", gap: 12 } },
                            React.createElement("span", null, "KUPONDAN"),
                            React.createElement("span", { style: { color: "var(--yesil)" } }, "RESM\u0130")),
                        React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 14 }, disabled: !kurucuMu || mesgul, onClick: () => setResmiTaslak({ ...resmi.puanlar }) }, "Puanlar\u0131 g\u00FCncelle"),
                        React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 8 }, disabled: !kurucuMu || mesgul, onClick: () => guvenliIslem(resmiSil) }, "Resmi puanlar\u0131 sil"))) : (React.createElement(React.Fragment, null,
                        React.createElement("div", { style: { fontSize: 12.5, color: "var(--sol)", padding: "0 6px 12px", lineHeight: 1.6 } }, "Erteleme ma\u00E7lar\u0131 ve atlanan haftalar y\u00FCz\u00FCnden yukar\u0131daki tablo ger\u00E7ek puanlardan sapabilir. Ayda bir TFF'nin tablosuna bak\u0131p 18 tak\u0131m\u0131n puan\u0131n\u0131 buraya yaz\u0131n \u2014 portf\u00F6y puanlar\u0131 o andan itibaren buradan hesaplan\u0131r. Kupon puanlar\u0131 etkilenmez."),
                        React.createElement("button", { className: "kp-dg2", style: { width: "100%" }, disabled: !kurucuMu || mesgul, onClick: () => setResmiTaslak({}) }, "Resmi puanlar\u0131 gir")))),
                React.createElement("button", { className: "kp-dg2", style: { width: "100%", marginTop: 20 }, onClick: () => { setEkran("giris"); setBen(null); setKurulum(null); setAktif(null); setTablo(null); setResmi(null); setMagaza(MAGAZA_BOS); setSatinOnay(null); setZekatMiktar(""); setZekatOnay(false); setErzakOnay(false); setAnket({}); setMansetKapali(false); setTransfer(null); setTrSat(null); setTrAl(null); setTrOnay(false); setAyakta(AYAKTA_BOS); setAySec(null); setAyGirisOnay(false); setAySecOnay(false); } }, "Ba\u015Fka gruba ge\u00E7")))),
        React.createElement("div", { className: "kp-surum", style: { textAlign: "center", padding: "8px 0 6px", fontSize: 10.5, color: "var(--sol)", fontFamily: "'JetBrains Mono',monospace", flexShrink: 0 } }, "sürüm " + SURUM)),
        React.createElement("nav", { className: "kp-alt", "aria-label": "Bölümler" }, [["merkez", "Çatışma"], ["kupon", "Kupon"], ["ayakta", "RULET"], ["klasman", "Klasman"], ["magaza", "Mağaza"], ["portfoy", "Portföy"], ["lig", "Lig"]].map(([k, l]) => (React.createElement("button", { key: k, className: sekme === k ? "on" : "", onClick: () => setSekme(k) }, l))))));
}

